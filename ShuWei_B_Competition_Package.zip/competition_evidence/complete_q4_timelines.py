"""New deterministic model replay, not a claim that old unlogged events were recorded.
AI-assisted OpenAI Codex GPT-6 family, OpenAI, 2026-11-23; build/release unavailable.
"""
from rebuild_q4_spatial import *

def subpath(path,lo,hi):
    if hi<=lo:return (along(path,lo),along(path,lo))
    ans=[along(path,lo)];walk=0.
    for a,b in zip(path,path[1:]):
        walk+=dist(a,b)
        if lo+1e-10<walk<hi-1e-10:ans.append(b)
    ans.append(along(path,hi));return tuple(ans)
def phase(e,kind,a,b,path=None):
    if b-a<1e-10:return None
    p=path if path else (e['position'],e['position'])
    return dict(phase=kind,task=e.get('task',''),t0=a,t1=b,path=p)
def mission(e,executed=True):
    return [z for z in [phase(e,'travel',e['depart'],e['arrive'],e['path']),
          phase(e,'slew',e['arrive'],e['ready']),phase(e,'wait_ready',e['ready'],e['start']),
          phase(e,'observe' if executed else 'cancelled_pair_hold',e['start'],e['end']),
          phase(e,'reset',e['end'],e['reset'])] if z]
def clip(z,a,b):
    lo=max(z['t0'],a);hi=min(z['t1'],b)
    if hi<=lo+1e-10:return None
    out=dict(z,t0=lo,t1=hi)
    if z['phase']=='travel':out['path']=subpath(z['path'],3*(lo-z['t0']),3*(hi-z['t0']))
    return out
def actual_prefix(v,command,frozen):
    ans=[]
    for e in BASE_BY[v]:
        if e['depart']>=command:break
        pp=mission(e)
        if e['task'] not in frozen:
            pp=[z for z in pp if z['phase'] in ['travel','slew','wait_ready']]
            if e['ready']<command:pp.append(phase(e,'wait_for_partner',e['ready'],command))
        for z in pp:
            if z:
                c=clip(z,0,command)
                if c:ans.append(c)
        if e['task'] not in frozen:break
    # The normal ready-to-start wait is replaced by wait_for_partner, not duplicated.
    cleaned=[]
    for z in ans:
        if z['phase']=='wait_ready' and z['task'] not in frozen:continue
        cleaned.append(z)
    return cleaned
def fill_gaps(v,parts,H):
    parts=sorted(parts,key=lambda z:(z['t0'],z['t1']))
    ans=[];clock=0.;p=INITIAL[v]
    for z in parts:
        if z['t0']>clock+1e-8:
            ans.append(dict(phase='idle',task='',t0=clock,t1=z['t0'],path=(p,p)))
        assert z['t0']>=clock-1e-7,(v,clock,z)
        assert dist(p,z['path'][0])<1e-7,(v,p,z)
        ans.append(z);clock=z['t1'];p=z['path'][-1]
    if clock<H:ans.append(dict(phase='idle',task='',t0=clock,t1=H,path=(p,p)))
    return ans

plans=json.loads((OUT/'spatial_reconstruction.json').read_text())
full=[];score=[];max_len_err=0.;stop_count=0;observation_vehicle_rows=0
for plan in plans:
    sid=plan['scenario'];pol=plan['policy'];cmd=plan['command'];frozen=set(plan['frozen']);failed=plan['failure']
    H=max(60.,max(e['reset'] for e in plan['events']))
    isretain=pol=='A' or sid in ['S01','S08','S09','S10','S11']
    allv={}
    for v in INITIAL:
        assigned=sorted([e for e in plan['events'] if e['vehicle']==v],key=lambda e:e['depart'])
        parts=[]
        if v==failed:
            parts=actual_prefix(v,5.,set())
            p=along(BASE_BY[v][0]['path'],15.)
            parts.append(dict(phase='withdrawn',task='',t0=5.,t1=H,path=(p,p)))
            stop_count+=1
        elif isretain:
            valid={e['task'] for e in assigned}
            for base in BASE_BY[v]:parts.extend(mission(base,base['task'] in valid))
        else:
            parts=actual_prefix(v,cmd,frozen)
            for e in assigned:
                if e['task'] in frozen:
                    for z in mission(e):
                        c=clip(z,cmd,H)
                        if c:parts.append(c)
            active=next((e for e in BASE_BY[v] if e['depart']<=cmd and (e['task'] not in frozen or cmd<e['reset'])),None)
            # Freeze continuation above includes its observation and reset. Otherwise
            # cancel at the current position, finish the existing slew, then reset.
            if active and active['task'] not in frozen and cmd>=active['arrive']:
                finish=max(cmd,active['ready']);p=active['position'];turntime=active['ready']-active['arrive']
                if finish>cmd:parts.append(dict(phase='finish_cancelled_slew',task=active['task'],t0=cmd,t1=finish,path=(p,p)))
                parts.append(dict(phase='reset_cancelled',task=active['task'],t0=finish,t1=finish+turntime,path=(p,p)))
            for e in assigned:
                if e['task'] not in frozen:parts.extend(mission(e))
        timeline=fill_gaps(v,parts,H)
        for z in timeline:
            assert z['t1']>=z['t0'] and all(1.5-1e-8<=x<=98.5+1e-8 for p in z['path'] for x in p)
            if z['phase']=='travel':
                assert all(clear(tuple(a),tuple(b)) for a,b in zip(z['path'],z['path'][1:])),(sid,pol,v,z)
                err=abs(length(z['path'])-3*(z['t1']-z['t0']));max_len_err=max(max_len_err,err)
                assert err<1e-6,(sid,pol,v,err,z)
            else:assert dist(z['path'][0],z['path'][-1])<1e-8
        allv[v]=timeline
    # Validate every reconstructed assigned task, including planned post-horizon starts.
    bytask=defaultdict(list)
    for e in plan['events']:
        assert visible(e['task'],e['position'])
        assert abs(turn(e['task'],e['position'])-(e['ready']-e['arrive']))<1e-7
        assert abs(length(e['path'])/3-(e['arrive']-e['depart']))<1e-7
        seen=[z for z in allv[e['vehicle']] if z['phase']=='observe' and z['task']==e['task']]
        assert abs(sum(z['t1']-z['t0'] for z in seen)-5)<1e-7
        assert abs(min(z['t0'] for z in seen)-e['start'])<1e-7
        bytask[e['task']].append(e);observation_vehicle_rows+=1
    starts=[]
    for task,pair in bytask.items():
        assert len(pair)==2 and pair[0]['vehicle']!=pair[1]['vehicle']
        assert abs(pair[0]['start']-pair[1]['start'])<1e-8
        assert abs(pair[0]['start']-max(e['ready'] for e in pair))<1e-8
        if pair[0]['start']<=60:starts.append(pair[0]['start'])
    ss=next(s for s in INDEX if s['scenario_id']==sid)
    N=4 if sid in ['S02','S12','S13','S14','S17','S18','S19','S20'] else 3
    assert len(starts)==int(ss['k'+pol])
    metric=max(starts) if len(starts)==N else 60.
    assert abs(metric-float(ss['t'+pol]))<1e-8
    score.append(dict(scenario=sid,policy=pol,N=N,k=len(starts),eta=len(starts)/N,t_last=metric))
    full.append(dict(scenario=sid,policy=pol,command=cmd,failure=failed,horizon=H,vehicles=allv))
(OUT/'complete_vehicle_timelines.json').write_text(json.dumps(full,indent=2),encoding='utf-8')
rows=[]
for p in full:
    for v,tl in p['vehicles'].items():
        for z in tl:rows.append(dict(scenario=p['scenario'],policy=p['policy'],vehicle=v,phase=z['phase'],task=z['task'],start_s=z['t0'],end_s=z['t1'],start_x=z['path'][0][0],start_y=z['path'][0][1],end_x=z['path'][-1][0],end_y=z['path'][-1][1],path_json=json.dumps(z['path'])))
for name,rr in [('complete_vehicle_events.csv',rows),('replayed_scores.csv',score)]:
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]));w.writeheader();w.writerows(rr)
report=dict(scenarios=20,policy_plans=40,continuous_vehicle_histories=200,vehicle_phase_events=len(rows),assigned_vehicle_task_rows=observation_vehicle_rows,failure_withdrawal_intervals=stop_count,max_travel_length_residual_m=max_len_err,route_vertex_offset_m=EPS,provenance='New model-based geometric reconstruction from original problem inputs, finite station menu and supplied task times; these are newly computed traces, not claims of formerly recorded original traces.',policy_A_completion_rule='Keep original mission slots; an unexecutable paired observation is replaced by a stationary hold, then the original reset and later departure. It is not counted as observation.',policy_B_cancellation_rule='Execute received commands until command time; unfinished observations are released under the stated conservative slew/reset rule; started observations complete and reset.')
(OUT/'replay_validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
