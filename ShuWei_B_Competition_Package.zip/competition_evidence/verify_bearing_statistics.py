# AI-assisted statistical audit using OpenAI Codex (GPT-6 family, OpenAI).
# The specific model build and release date were not available.
import csv
from functools import lru_cache
import math
from pathlib import Path
from statistics import NormalDist
import sys
import numpy as np

BASE=Path(__file__).resolve().parent
N=NormalDist()
SEED=20261122

def phi(x):
    return np.fromiter((.5*math.erfc(-float(t)/math.sqrt(2)) for t in x),dtype=float,count=len(x))

@lru_cache(maxsize=None)
def grid(panels,order):
    nodes,weights=np.polynomial.legendre.leggauss(order)
    edges=np.linspace(-math.pi,math.pi,panels+1)
    theta=np.concatenate([(a+b)/2+(b-a)/2*nodes for a,b in zip(edges,edges[1:])])
    mass=np.concatenate([(b-a)/2*weights for a,b in zip(edges,edges[1:])])
    deg=np.degrees(theta)
    g=sum(phi(5+360*j-deg)-phi(-5+360*j-deg) for j in (-1,0,1))
    return np.cos(theta),np.sin(theta),mass,g

def quadratic(sigma,panels=24,order=96):
    if sigma==0:
        return 2*N.cdf(5)-1
    c,s,w,g=grid(panels,order)
    k=40/sigma
    x=k*c
    density=np.exp(-k*k/2)/(2*math.pi)+x*np.exp(-(k*s)**2/2)*phi(x)/math.sqrt(2*math.pi)
    assert abs(float(w@density)-1)<1e-9
    return float(w@(density*g))

def root(panels,order):
    lo,hi=1.5,1.9
    for _ in range(44):
        mid=(lo+hi)/2
        if quadratic(mid,panels,order)>=.95:
            lo=mid
        else:
            hi=mid
    return (hi+lo)/2

def write(name, rows):
    with (BASE/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def mc():
    rows=[]
    for distance,seed in zip((0,40,66.92,80),np.random.SeedSequence(SEED).spawn(4)):
        n=1_000_000
        sigma=.3+.02*distance
        rng=np.random.Generator(np.random.PCG64(seed))
        dx=rng.normal(0,sigma,n)
        dy=rng.normal(0,sigma,n)
        error=np.degrees(np.arctan2(-dy,40-dx))+rng.normal(0,.8,n)+rng.normal(0,.6,n)
        successes=int(np.count_nonzero(np.abs((error+180)%360-180)<=5))
        phat=successes/n
        z=N.inv_cdf(.975)
        denom=1+z*z/n
        center=(phat+z*z/(2*n))/denom
        radius=z*math.sqrt((phat*(1-phat)+z*z/(4*n))/n)/denom
        row=dict(s=distance,seed=SEED,stream=seed.spawn_key[0],draws=n,successes=successes,
                 first_order=2*N.cdf(5/math.hypot(1,math.degrees(sigma/40)))-1,
                 quadrature=quadratic(sigma),simulation=phat,wilson_low=center-radius,wilson_high=center+radius)
        rows.append(row)
    return rows

def main():
    cap=root(24,96)
    other=root(48,144)
    assert abs(cap-other)<1e-10
    print('Python',sys.version.split()[0], 'NumPy',np.__version__)
    print('nonlinear position-SD limit', cap, 'cutoff', (cap-.3)/.02, 'other grid', other)
    print('a-axis',cap,'b-axis',cap/80)
    rows=[]
    distances=[0,40,60,66.7,66.77,66.78,66.79,66.80,66.83,66.84,66.9,66.92,80]
    for s in distances:
        sd=.3+.02*s
        rows.append(dict(distance=s,sigma_position=sd,coarse=quadratic(sd,24,96),fine=quadratic(sd,48,144)))
    assert max(abs(r['coarse']-r['fine']) for r in rows)<1e-10
    write('Q3_Nonlinear_Coverage_Checks.csv',rows)
    samples=mc()
    write('Q3_Monte_Carlo_Reproduced.csv',samples)
    for r in rows: print(r)
    for r in samples: print(r)

if __name__=='__main__':
    main()

