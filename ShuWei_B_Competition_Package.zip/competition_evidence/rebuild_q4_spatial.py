"""Model-based geometric reconstruction from original problem inputs and task times.
AI-assisted: OpenAI Codex, GPT-6 family, OpenAI, 2026-11-23; build/release unavailable.
Reconstructed paths are new computations, not previously recorded original paths.
"""
from pathlib import Path
from math import sin,cos,tan,radians,degrees,atan2,hypot,dist,isfinite
from functools import lru_cache
from collections import defaultdict
import csv,json,heapq

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OUT=HERE
OUT.mkdir(parents=True,exist_ok=True)
OLD=HERE/'input_times'
BOXES=[(22,34,16,26,20),(63,79,59,71,28),(10,24,65,76,12),(72,86,22,34,24),(41,51,38,46,32)]
RECT=[(a-1.5,b+1.5,c-1.5,d+1.5) for a,b,c,d,h in BOXES]
INITIAL={'V1':(15.,14.),'V2':(88.,10.),'V3':(14.,86.),'V4':(88.,68.),'V5':(50.,93.)}
TARGET={k:(50+r*cos(radians(a)),50+r*sin(radians(a)),h) for k,a,r,h in [('T1',30,40,45),('T2',150,45,35),('T3',285,38,55),('T4',30,45,50)]}
EPS=1e-4
def boxhit(p,q,b):
    lo,hi=0.,1.
    for x,y,a,c in [(p[0],q[0],b[0],b[1]),(p[1],q[1],b[2],b[3])]:
        d=y-x
        if abs(d)<1e-13:
            if not a<=x<=c:return False
        else:
            u,v=sorted(((a-x)/d,(c-x)/d));lo=max(lo,u);hi=min(hi,v)
            if lo>hi:return False
    return True
def clear(p,q):return all(not boxhit(p,q,b) for b in RECT)
VERT=[]
for a,b,c,d in RECT:VERT.extend([(a-EPS,c-EPS),(a-EPS,d+EPS),(b+EPS,c-EPS),(b+EPS,d+EPS)])
GRAPH=[[] for _ in VERT]
for i,p in enumerate(VERT):
    for j in range(i):
        if clear(p,VERT[j]):
            length=dist(p,VERT[j]);GRAPH[i].append((j,length));GRAPH[j].append((i,length))
@lru_cache(maxsize=None)
def route(p,q):
    if clear(p,q):return (p,q)
    if any(a<=p[0]<=b and c<=p[1]<=d or a<=q[0]<=b and c<=q[1]<=d for a,b,c,d in RECT):return None
    n=len(VERT);dd=[float('inf')]*n;prev=[-1]*n;heap=[]
    for i,v in enumerate(VERT):
        if clear(p,v):dd[i]=dist(p,v);heapq.heappush(heap,(dd[i],i))
    best=float('inf');end=-1
    while heap:
        cost,i=heapq.heappop(heap)
        if cost!=dd[i]:continue
        if cost>=best:break
        if clear(VERT[i],q):
            z=cost+dist(VERT[i],q)
            if z<best:best=z;end=i
        for j,w in GRAPH[i]:
            z=cost+w
            if z<dd[j]:dd[j]=z;prev[j]=i;heapq.heappush(heap,(z,j))
    if end<0:return None
    mids=[]
    while end>=0:mids.append(VERT[end]);end=prev[end]
    return (p,*reversed(mids),q)
def length(path):return sum(dist(a,b) for a,b in zip(path,path[1:]))
def station(task,a):
    x,y,h=TARGET[task];rr=(h-2)/tan(radians(80))
    return (x+rr*cos(radians(a)),y+rr*sin(radians(a)))
def turn(task,p):
    x,y,h=TARGET[task];pan=abs(degrees(atan2(y-p[1],x-p[0])));tilt=degrees(atan2(h-2,hypot(x-p[0],y-p[1])))
    return max(pan,tilt)/30
def visible(task,p):
    q=TARGET[task]
    for a,b,c,d,h in BOXES:
        lo,hi=0.,1.
        for o,delta,low,high in [(p[0],q[0]-p[0],a,b),(p[1],q[1]-p[1],c,d),(2.,q[2]-2,0.,h)]:
            if abs(delta)<1e-13:
                if not low<=o<=high:lo=1.;hi=0.;break
            else:
                u,v=sorted(((low-o)/delta,(high-o)/delta));lo=max(lo,u);hi=min(hi,v)
                if lo>hi:break
        if lo<=hi:return False
    return 1.5<=p[0]<=98.5 and 1.5<=p[1]<=98.5
def along(path,s):
    if s<=0:return path[0]
    for a,b in zip(path,path[1:]):
        z=dist(a,b)
        if s<=z:
            f=s/z if z else 0.;return tuple(a[i]+f*(b[i]-a[i]) for i in range(2))
        s-=z
    return path[-1]
def read(name):
    with (OLD/name).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
RAW=read('supplied_Archived_Event_Times.csv');INDEX=read('supplied_Scenario_Timeline_Index.csv')
for e in RAW:
    for k in ['depart','arrive','ready','start','end','reset']:e[k]=float(e[k])
ANGLES={('T1','V2'):350,('T1','V4'):260,('T2','V3'):190,('T2','V5'):100,('T3','V1'):190,('T3','V4'):100}
BASE=[]
last={v:INITIAL[v] for v in INITIAL}
for row in sorted([e for e in RAW if e['scenario']=='S01' and e['policy']=='A'],key=lambda e:(e['depart'],e['task'],e['vehicle'])):
    e=dict(row);p=station(e['task'],ANGLES[e['task'],e['vehicle']]);path=route(last[e['vehicle']],p)
    assert path and abs(length(path)/3-(e['arrive']-e['depart']))<1e-8,(e,length(path)/3)
    assert abs(turn(e['task'],p)-(e['ready']-e['arrive']))<1e-8
    e.update(position=p,path=path,angle=ANGLES[e['task'],e['vehicle']]);BASE.append(e);last[e['vehicle']]=p
BASE_BY={v:sorted([e for e in BASE if e['vehicle']==v],key=lambda e:e['depart']) for v in INITIAL}
BASE_TASK={(e['task'],e['vehicle']):e for e in BASE}
def state(v,command,frozen):
    missions=BASE_BY[v]
    prev=None
    for e in missions:
        if e['depart']>command:break
        prev=e
        if command<e['arrive']:return along(e['path'],3*(command-e['depart'])),command
        if e['task'] in frozen:
            if command<e['reset']:return e['position'],max(command,e['reset'])
        else:
            return e['position'],max(command,e['ready'])+(e['ready']-e['arrive'])
    return (prev['position'] if prev else INITIAL[v]),command

def recover(rows,command,frozen):
    order=sorted(rows,key=lambda e:(e['depart'],e['vehicle']))
    solved=[];lastpos={};lastreset={}
    def dfs(j):
        if j==len(order):return list(solved)
        row=order[j];v=row['vehicle'];task=row['task'];opts=[]
        if task in frozen or row['depart']<command-1e-8:
            base=BASE_TASK.get((task,v))
            if base is None:return None
            opts=[dict(row,position=base['position'],path=base['path'],angle=base['angle'])]
        else:
            if v in lastpos:p0=lastpos[v];release=lastreset[v]
            else:p0,release=state(v,command,frozen)
            if row['depart']<release-1e-7:return None
            for a in range(0,360,10):
                p=station(task,a)
                if abs(turn(task,p)-(row['ready']-row['arrive']))>1e-7 or not visible(task,p):continue
                path=route(tuple(p0),p)
                if path and abs(length(path)/3-(row['arrive']-row['depart']))<1e-7:
                    opts.append(dict(row,position=p,path=path,angle=a))
        for e in opts:
            mate=next((z for z in solved if z['task']==task),None)
            if mate and abs(((e['angle']-mate['angle'])%180)-90)>1e-8:continue
            oldpos=lastpos.get(v);oldreset=lastreset.get(v)
            lastpos[v]=e['position'];lastreset[v]=e['reset'];solved.append(e)
            answer=dfs(j+1)
            if answer is not None:return answer
            solved.pop()
            if oldpos is None:lastpos.pop(v);lastreset.pop(v)
            else:lastpos[v]=oldpos;lastreset[v]=oldreset
        return None
    return dfs(0)

if __name__=='__main__':
    plans=[];fail=[]
    for s in INDEX:
        sid=s['scenario_id'];command=float(s['recovery_s']) if s['recovery_s'] else 5.
        frozen=set(filter(None,s['frozen'].split(',')))
        for pol in ['A','B']:
            rows=[e for e in RAW if e['scenario']==sid and e['policy']==pol]
            if pol=='A' or sid in ['S01','S08','S09','S10','S11']:
                resolved=[dict(e,position=BASE_TASK[e['task'],e['vehicle']]['position'],path=BASE_TASK[e['task'],e['vehicle']]['path'],angle=BASE_TASK[e['task'],e['vehicle']]['angle']) for e in rows]
            else:resolved=recover(rows,command,frozen)
            if resolved is None:fail.append((sid,pol));print('UNRESOLVED',sid,pol,flush=True)
            else:
                plans.append(dict(scenario=sid,policy=pol,command=command,failure=s['failure'],frozen=sorted(frozen),events=resolved))
                print('REBUILT',sid,pol,len(resolved),flush=True)
    (OUT/'spatial_reconstruction.json').write_text(json.dumps(plans,indent=2),encoding='utf-8')
    print('Reconstructed plans',len(plans),'unresolved',fail,flush=True)
