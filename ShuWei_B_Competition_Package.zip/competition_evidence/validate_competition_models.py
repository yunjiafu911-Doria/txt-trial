"""Independent numerical checks for the model-based competition replay.
AI-assisted OpenAI Codex GPT-6 family, OpenAI, 2026-11-23; build unavailable.
"""
from rebuild_q4_spatial import *
import numpy as np

rows=[];rng=np.random.default_rng(20261123);z=rng.standard_normal((100000,2))
sigma=.01
for gdeg in [30,60,90,120,150]:
    g=radians(gdeg);r1,r2=3.,5.
    anchors=np.array([[-r1,0.],[-r2*cos(g),-r2*sin(g)]])
    def intersect(delta):
        a=np.array([0.,g])+delta
        n=np.column_stack((-np.sin(a),np.cos(a)))
        return np.linalg.solve(n,np.sum(n*anchors,axis=1))
    N=np.array([[0.,1.],[-sin(g),cos(g)]])
    J=np.linalg.solve(N,np.diag([r1,r2]));h=1e-6
    fd=np.column_stack([(intersect(np.eye(2)[j]*h)-intersect(-np.eye(2)[j]*h))/(2*h) for j in range(2)])
    theory=sigma*hypot(r1,r2)/abs(sin(g));cov=sigma**2*J@J.T
    lin=z*sigma@J.T
    mc=float(np.sqrt(np.mean(np.sum(lin**2,axis=1))))
    rows.append(dict(angle_deg=gdeg,fd_max_abs_error=float(np.max(np.abs(J-fd))),rms_formula=theory,rms_covariance=float(np.sqrt(np.trace(cov))),mc_linear_rms=mc,mc_relative_deviation=abs(mc/theory-1)))

near=json.loads((OUT/'nearest_assignment_recomputed.json').read_text())
max_travel_error=0.;last={};times={}
for e in sorted(near['events'],key=lambda e:e['depart']):
    v=e['vehicle'];p=last.get(v,INITIAL[v]);clock=times.get(v,0.)
    assert dist(e['path'][0],p)<1e-9 and abs(e['depart']-clock)<1e-9
    assert all(clear(tuple(a),tuple(b)) for a,b in zip(e['path'],e['path'][1:]))
    assert visible(e['task'],e['position'])
    max_travel_error=max(max_travel_error,abs(length(e['path'])/3-(e['arrive']-e['depart'])))
    assert abs(turn(e['task'],e['position'])-e['turn'])<1e-9
    assert abs(e['ready']-e['arrive']-e['turn'])<1e-9
    assert abs(e['end']-e['start']-5)<1e-9
    assert abs(e['reset']-e['end']-e['turn'])<1e-9
    last[v]=e['position'];times[v]=e['reset']
for task in ['T1','T2','T3']:
    pair=[e for e in near['events'] if e['task']==task]
    assert len(pair)==2 and pair[0]['vehicle']!=pair[1]['vehicle']
    assert abs(pair[0]['start']-pair[1]['start'])<1e-9
    assert abs(pair[0]['start']-max(e['ready'] for e in pair))<1e-9
    assert abs(((pair[0]['angle']-pair[1]['angle'])%180)-90)<1e-9
result=dict(fd_max_abs_error=max(r['fd_max_abs_error'] for r in rows),monte_carlo_draws=100000,monte_carlo_sigma_rad=sigma,mc_max_relative_deviation=max(r['mc_relative_deviation'] for r in rows),fresh_nearest_latest_s=near['latest_start'],baseline_latest_s=max(e['start'] for e in BASE),improvement_s=near['latest_start']-max(e['start'] for e in BASE),fresh_nearest_max_travel_error_s=max_travel_error,single_T2_travel_s={v:length(route(INITIAL[v],station('T2',a)))/3 for v,a in [('V3',224.5),('V5',134.5)]})
with (OUT/'covariance_checks.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
(OUT/'numerical_validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps(result,indent=2))
