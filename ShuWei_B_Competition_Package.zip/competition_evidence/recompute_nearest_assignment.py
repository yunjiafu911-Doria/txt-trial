"""Fresh nearest-assignment comparison from the original contest geometry.
AI-assisted OpenAI Codex GPT-6 family, OpenAI, 2026-11-23; exact build unavailable.
"""
from rebuild_q4_spatial import *
import time

def feasible_point(task,a):
    p=station(task,a)
    return visible(task,p) and all(not (x<=p[0]<=y and z<=p[1]<=w) for x,y,z,w in RECT)

if __name__=='__main__':
    clocks={v:0. for v in INITIAL};positions=dict(INITIAL);records=[];log=[]
    for task in ['T1','T2','T3']:
        t=time.time();angles=[i*.25 for i in range(1440) if feasible_point(task,i*.25)]
        aset=set(angles)
        pairs=[(a,(a+shift)%360) for a in angles for shift in [90,270] if (a+shift)%360 in aset]
        allowed=sorted(set(a for pair in pairs for a in pair))
        rank=[]
        for v in INITIAL:
            best=min((length(route(INITIAL[v],station(task,a)))/3,a) for a in allowed if route(INITIAL[v],station(task,a)))
            rank.append((best[0],v,best[1]))
        rank.sort();v1,v2=rank[0][1],rank[1][1]
        best=None
        for a,b in pairs:
            points=[station(task,a),station(task,b)];vehicles=[v1,v2];ee=[]
            for v,p,angle in zip(vehicles,points,[a,b]):
                path=route(positions[v],p)
                if not path:break
                travel=length(path)/3;turntime=turn(task,p);arrive=clocks[v]+travel
                ee.append(dict(vehicle=v,task=task,position=p,angle=angle,path=path,depart=clocks[v],arrive=arrive,turn=turntime,ready=arrive+turntime,length=travel*3))
            if len(ee)!=2:continue
            start=max(e['ready'] for e in ee);key=(start,a,b)
            if best is None or key<best[0]:best=(key,ee)
        start=best[0][0]
        for e in best[1]:
            e.update(start=start,end=start+5,reset=start+5+e['turn'])
            clocks[e['vehicle']]=e['reset'];positions[e['vehicle']]=e['position'];records.append(e)
        log.append(dict(task=task,initial_distance_ranking=rank,selected=[v1,v2],feasible_station_angles=len(angles),ordered_orthogonal_pairs=len(pairs),chosen_angles=list(best[0][1:]),start=start,elapsed_s=time.time()-t))
        print(task,start,v1,v2,best[0][1:],len(pairs),flush=True)
    result=dict(rule='Process T1,T2,T3 in input order; rank each vehicle by its minimum obstacle-feasible travel time from its initial position to the valid 0.25-degree orthogonal station menu, break ties by vehicle ID, choose the nearest two, then minimize their current paired readiness over both ordered orthogonal orientations.',events=records,selection_log=log,latest_start=max(e['start'] for e in records))
    (OUT/'nearest_assignment_recomputed.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print('Latest start',result['latest_start'],flush=True)
