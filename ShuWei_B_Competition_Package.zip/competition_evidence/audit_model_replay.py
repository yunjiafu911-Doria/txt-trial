"""Audit of newly computed model trajectories from original contest inputs.
AI-assisted OpenAI Codex GPT-6 family, OpenAI, 2026-11-23; exact build unavailable.
"""
from rebuild_q4_spatial import *

def check_vehicle_trace(events, initial, horizon):
    clock, position = 0.0, initial
    for event in events:
        assert abs(event['t0'] - clock) < 1e-7
        path = event['path']
        assert dist(position, path[0]) < 1e-7
        duration = event['t1'] - event['t0']
        assert duration >= 0
        if event['phase'] == 'travel':
            assert all(clear(tuple(a), tuple(b)) for a, b in zip(path, path[1:]))
            assert abs(length(path) - 3 * duration) < 1e-6
        else:
            assert dist(path[0], path[-1]) < 1e-8
        clock, position = event['t1'], path[-1]
    assert abs(clock - horizon) < 1e-7

if __name__=='__main__':
    traces=json.loads((OUT/'complete_vehicle_timelines.json').read_text())
    plans=json.loads((OUT/'spatial_reconstruction.json').read_text())
    observations=0;withdrawals=0
    for trace,plan in zip(traces,plans):
        assert trace['scenario']==plan['scenario'] and trace['policy']==plan['policy']
        for v,events in trace['vehicles'].items():
            check_vehicle_trace(events,INITIAL[v],trace['horizon'])
            if v==trace['failure']:
                after=[e for e in events if e['t1']>5+1e-8]
                assert len(after)==1 and after[0]['phase']=='withdrawn' and abs(after[0]['t0']-5)<1e-8
                assert dist(after[0]['path'][0],along(BASE_BY[v][0]['path'],15))<1e-8
                withdrawals+=1
        for e in plan['events']:
            assert abs(e['end']-e['start']-5)<1e-8
            assert abs(e['reset']-e['end']-(e['ready']-e['arrive']))<1e-8
            assert visible(e['task'],e['position'])
            obs=[p for p in trace['vehicles'][e['vehicle']] if p['phase']=='observe' and p['task']==e['task']]
            assert abs(sum(p['t1']-p['t0'] for p in obs)-5)<1e-8
            assert all(dist(p['path'][0],e['position'])<1e-8 for p in obs)
            observations+=1
    result=dict(policy_plans=len(traces),continuous_histories=5*len(traces),assigned_observation_rows=observations,failure_withdrawals=withdrawals,status='PASS')
    (OUT/'independent_event_audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(result)
