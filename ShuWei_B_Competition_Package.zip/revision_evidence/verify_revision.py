"""AI-assisted independent checking of the team's supplied model; not team authorship evidence.
Tool: OpenAI Codex, GPT-6 family, OpenAI, used 2026-11-22.
Exact deployed build/release date unavailable. Team review and independent rewrite required.
"""
import sys, json, math, csv, time, hashlib
from pathlib import Path
SCRIPT=Path(__file__).resolve().parent
ROOT=SCRIPT.parent if SCRIPT.name=='work' else SCRIPT.parent.parent
sys.path.insert(0, str(ROOT/'work/python_packages'))
import numpy as np
from scipy.special import ndtr
from scipy.integrate import quad
from scipy.optimize import brentq, minimize_scalar

OUT=ROOT/'outputs'/'revision_evidence' if SCRIPT.name=='work' else SCRIPT
OUT.mkdir(exist_ok=True, parents=True)
B=np.array([[22,34,16,26,20],[63,79,59,71,28],[10,24,65,76,12],[72,86,22,34,24],[41,51,38,46,32]],float)
T=np.array([50+40*math.cos(math.pi/6),70.,45.])
R=43/math.tan(math.radians(80))

def masks(x,y):
    veh=(x>=1.5)&(x<=98.5)&(y>=1.5)&(y<=98.5)
    visible=np.ones(x.shape,bool)
    for xl,xh,yl,yh,h in B:
        dx=np.maximum(np.maximum(xl-x,0),x-xh)
        dy=np.maximum(np.maximum(yl-y,0),y-yh)
        veh &= dx*dx+dy*dy>=2.25
        lo=np.zeros(x.shape); hi=np.ones(x.shape)
        for p,d,l,u in [(x,T[0]-x,xl,xh),(y,T[1]-y,yl,yh),(np.full_like(x,2),np.full_like(x,43),0,h)]:
            nz=np.abs(d)>1e-14
            a=np.divide(l-p,d,out=np.full_like(x,-np.inf),where=nz)
            b=np.divide(u-p,d,out=np.full_like(x,np.inf),where=nz)
            lo=np.maximum(lo,np.minimum(a,b)); hi=np.minimum(hi,np.maximum(a,b))
            lo=np.where(~nz&((p<l)|(p>u)),np.inf,lo)
        visible &= lo>hi
    pitch=np.hypot(x-T[0],y-T[1])>=R
    return veh,pitch,visible

def q1_grid():
    rows=[]
    for step in [1.,.5,.2,.1,.05]:
        axis=(np.arange(round(100/step))+.5)*step
        x,y=np.meshgrid(axis,axis)
        v,p,l=masks(x,y)
        counts=[int(v.sum()),int((v&p).sum()),int((v&p&l).sum())]
        rows.append(dict(step_m=step,n_cells=x.size,vehicle_cells=counts[0],vehicle_pitch_cells=counts[1],final_cells=counts[2],vehicle_area=counts[0]*step**2,vehicle_pitch_area=counts[1]*step**2,final_area=counts[2]*step**2))
        if step==.05:
            np.savez_compressed(OUT/'q1_grid_masks_005m.npz',axis_m=axis,vehicle=v,pitch=p,los=l,final=v&p&l,buildings=B,target=T,grid_step=step)
    write_csv('q1_grid_summary.csv',rows)
    return rows

def clearances(theta):
    a=np.atleast_1d(theta)
    pts=np.column_stack([T[0]+R*np.cos(a),T[1]+R*np.sin(a),np.full(a.shape,2.)])
    veh=np.min(np.column_stack([pts[:,0]-1.5,98.5-pts[:,0],pts[:,1]-1.5,98.5-pts[:,1]]),axis=1)
    los=np.full(len(a),np.inf)
    d=T-pts
    for xl,xh,yl,yh,h in B:
        bl=np.array([xl,yl,0]); bh=np.array([xh,yh,h])
        dx=np.maximum(np.maximum(bl[:2]-pts[:,:2],0),pts[:,:2]-bh[:2])
        veh=np.minimum(veh,np.linalg.norm(dx,axis=1)-1.5)
        lo=np.zeros(len(a)); hi=np.ones(len(a))
        for _ in range(46):
            u=(lo+hi)/2; z=pts+u[:,None]*d
            deriv=np.sum((z-np.clip(z,bl,bh))*d,axis=1)
            lo=np.where(deriv<0,u,lo); hi=np.where(deriv<0,hi,u)
        z=pts+((lo+hi)/2)[:,None]*d
        los=np.minimum(los,np.linalg.norm(z-np.clip(z,bl,bh),axis=1))
    return veh,los

def q1_clearance():
    step=.001
    theta=np.deg2rad(np.arange(0,360,step))
    v,l=clearances(theta); g=np.minimum(v,l)
    j=int(np.argmax(g)); half=np.deg2rad(.01)
    res=minimize_scalar(lambda a:-float(min(x[0] for x in clearances(a))),bounds=(theta[j]-half,theta[j]+half),method='bounded',options={'xatol':1e-14})
    a=res.x; cv,cl=clearances(a)
    upper=float(g[j]+R*np.deg2rad(step)/2)
    result=dict(angle_deg=math.degrees(a),position_m=[T[0]+R*math.cos(a),T[1]+R*math.sin(a)],vehicle_clearance_m=float(cv[0]),los_clearance_m=float(cl[0]),lower_m=float(min(cv[0],cl[0])),continuous_upper_m=upper,gap_m=upper-float(min(cv[0],cl[0])),grid_step_deg=step,argument='Both distance clearances are 1-Lipschitz in station position. Circle displacement <= r*angular displacement. Every circle point lies within half a grid step of a sampled point. Bound covers the full circle, hence its feasible arc. This is a numerical epsilon-global bound, not an exact symbolic lexicographic certificate.')
    np.savez_compressed(OUT/'q1_full_circle_clearances.npz',theta_deg=np.rad2deg(theta),vehicle_m=v,los_m=l,objective_m=g)
    (OUT/'q1_clearance_certificate.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def coverage(sigma,tol=1e-11):
    # Condition on longitudinal standard normal X. Away from the negligible X>40/sigma
    # tail, alpha is monotone in transverse normal Y. Integrate exact conditional
    # Gaussian interval mass over independent gimbal error g (radians).
    # The alternative angular-density integral below includes all X,Y directions.
    k=40/sigma; sg=math.pi/180; tau=5*sg
    def f(angle):
        z=k*math.cos(angle)
        # projected-normal directional density, cancellation-free in the rear half.
        if z>=0:
            density=math.exp(-k*k*math.sin(angle)**2/2)*(math.exp(-z*z/2)/(2*math.pi)+z*ndtr(z)/math.sqrt(2*math.pi))
        else:
            density=0.0 if k>10 else math.exp(-k*k/2)/(2*math.pi)*(1+z*math.sqrt(2*math.pi)*math.exp(z*z/2)*ndtr(z))
        c=sum(ndtr((tau-angle+2*math.pi*j)/sg)-ndtr((-tau-angle+2*math.pi*j)/sg) for j in [-1,0,1])
        return density*c
    points=[-math.pi,-.4,-.2,-.1,-.05,0,.05,.1,.2,.4,math.pi]
    vals=[quad(f,a,b,epsabs=tol/10,epsrel=tol,limit=200) for a,b in zip(points,points[1:])]
    return sum(x[0] for x in vals),sum(x[1] for x in vals)

def coverage_conditional(sigma):
    # Independent check: condition on X and g, integrate the admissible Y interval.
    # Bounds |X|, |g/sg|<=10 omit probability <3.1e-23; backward direction X>k
    # is negligible here (k>20). Integrates a different two-dimensional expression.
    k=40/sigma; sg=math.pi/180; tau=5*sg; norm=math.sqrt(2*math.pi)
    def outer(x):
        def inner(z):
            u=tau-sg*z; l=-tau-sg*z
            mass=ndtr((k-x)*math.tan(u))-ndtr((k-x)*math.tan(l))
            return mass*math.exp(-z*z/2)/norm
        return quad(inner,-10,10,epsabs=2e-11,epsrel=2e-11)[0]*math.exp(-x*x/2)/norm
    return quad(outer,-10,10,epsabs=2e-10,epsrel=2e-10)[0]

def q3():
    root=brentq(lambda s:coverage(.3+.02*s)[0]-.95,66.8,66.9,xtol=1e-10)
    rows=[]
    for s in [0,20,40,60,66.83,root,66.84,66.92,80]:
        c,e=coverage(.3+.02*s); c2,e2=coverage(.3+.02*s,2e-12)
        independent=coverage_conditional(.3+.02*s)
        rows.append(dict(distance_m=s,sigma_position_m=.3+.02*s,coverage=c,quad_error_est=e,refined_coverage=c2,independent_conditional=independent,difference=abs(c-independent)))
    write_csv('q3_probability_checks.csv',rows)
    result=dict(root_m=root,root_bracket_m=[66.83,66.84],safe_centimetre_m=66.83,sigma_root_m=.3+.02*root,safe_sigma_80m_m=1.6367,coverage_at_safe_sigma=coverage(1.6367)[0],max_independent_difference=max(x['difference'] for x in rows),domain='Isotropic independent Gaussian position error, centered independent Gaussian gimbal errors, target range 40 m. Numerical integration evidence is not a field-performance guarantee. Rear-half density and omitted Gaussian tails contribute <1e-90 at these parameters; quadrature errors are estimates.')
    (OUT/'q3_threshold.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return result

def write_csv(name,rows):
    with (OUT/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

if __name__=='__main__':
    all_results={}
    for name,fun in [('q1_grid',q1_grid),('q1_clearance',q1_clearance),('q3',q3)]:
        t=time.time(); all_results[name]=fun(); print(name,json.dumps(all_results[name]),'seconds',round(time.time()-t,2),flush=True)
    (OUT/'verification_results.json').write_text(json.dumps(all_results,indent=2),encoding='utf-8')
