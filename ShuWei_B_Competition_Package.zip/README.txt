﻿数维杯 B 题论文与程序

论文：BSWBMCM2635689.pdf
可编辑稿：BSWBMCM2635689.docx
论文与 Word 均为 24 页，Summary、正文、图表、结论已同步。

本版计算要点
1. 第一问面积 5608.5275 平方米；完整格网、连续净空样本和数值界位于 revision_evidence。
2. 第二问统一使用原题几何和障碍绕行。V4 复用计划最晚启动 46.883934657 秒；重新执行最近分配规则得到 47.133600551 秒，差 0.249665894 秒。选车排名、站点角和完整事件见 competition_evidence/nearest_assignment_recomputed.json。
3. 第三问保留非线性概率阈值和 66.83 米的厘米级可行取值；原概率程序与蒙特卡洛子流已重跑，日志见 competition_evidence/Q3_Run_Log.txt。
4. 第四问补算了 20 情景、40 策略方案的 200 条连续逐车模型时间线，共 1,378 条阶段事件。完整路线、被改派前缀、复位、等待和故障退出记录均在 competition_evidence。表 9 的 40 个评分由这些轨迹重新计算。
5. 图 8 展示 S20 的完整五车模型时间线，含 60 秒以后才启动的 T3。五种等概率单故障下，平均启动率为 A=0.60、B=1.00。

计算复现
先安装 requirements.txt，然后依次运行：
python revision_evidence/verify_revision.py
python competition_evidence/rebuild_q4_spatial.py
python competition_evidence/complete_q4_timelines.py
python competition_evidence/recompute_nearest_assignment.py
python competition_evidence/validate_competition_models.py
python competition_evidence/audit_model_replay.py
python competition_evidence/verify_bearing_statistics.py

competition_evidence/input_times 保留队伍提供的任务时刻输入；problem_geometry.json 保留原题几何常量。完整事件文件是据这些输入计算的模型轨迹，数据来源与计算环境记录在 Input_Provenance.json。
original_code 保留最初交接包中的 Python 源程序和依赖说明；其目录结构保持一致。新补算入口见上列脚本。

Final_Quality_Checks.json 记录最后的数值、公式、目录、页码和版式检查。SHA256SUMS.txt 用于核对文件完整性。
