"""Generate and plot a seeded, synthetic geometry example."""

import argparse
from pathlib import Path
from random import Random

import matplotlib
from matplotlib.axes import Axes
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle as RectanglePatch

from geometry import (
    Point2D,
    PointLocation,
    Rectangle,
    SegmentRectangleRelation,
    Workspace,
    segment_rectangle_relation,
)

Segment = tuple[Point2D, Point2D]

POINT_STYLES = {
    PointLocation.OUTSIDE: ("Outside", "#697586", "o"),
    PointLocation.BOUNDARY: ("Boundary", "#ab4c00", "D"),
    PointLocation.INSIDE: ("Inside", "#08695f", "o"),
}

SEGMENT_STYLES = {
    SegmentRectangleRelation.DISJOINT: ("Disjoint", "#697586", "--"),
    SegmentRectangleRelation.TOUCH: ("Touch", "#ab4c00", ":"),
    SegmentRectangleRelation.CROSS: ("Cross", "#205ab6", "-"),
    SegmentRectangleRelation.OVERLAP: ("Overlap", "#a01370", "-."),
    SegmentRectangleRelation.INSIDE: ("Inside", "#08695f", "-"),
}


def generate_scene(seed: int) -> tuple[Workspace, tuple[Point2D, ...], tuple[Segment, ...]]:
    """Vary the rectangle and samples by seed, while covering every relation."""
    rng = Random(seed)
    x, y = rng.randint(3, 5), rng.randint(3, 5)
    width, height = rng.randint(5, 7), rng.randint(5, 7)
    right, top = x + width, y + height
    rectangle = Rectangle(x, y, right, top)
    workspace = Workspace(Rectangle(0, 0, 16, 16), (rectangle,))

    points = tuple(Point2D(rng.uniform(0, 16), rng.uniform(0, 16)) for _ in range(32))
    points += (
        Point2D(1, 1),
        Point2D(x, y),
        Point2D(rng.uniform(x + 1, right - 1), top),
        Point2D(rng.uniform(x + 1, right - 1), rng.uniform(y + 1, top - 1)),
    )
    crossing_y = y + rng.uniform(0.8, 1.5)
    segments = (
        (Point2D(x, y - rng.uniform(1, 2)), Point2D(right, y - 1)),
        (Point2D(right, top), Point2D(right + 2, top + rng.uniform(1, 2))),
        (Point2D(x - 1, crossing_y), Point2D(right + 1, crossing_y)),
        (Point2D(x - 1, top), Point2D(x + rng.uniform(2, 3), top)),
        (Point2D(x + 1, y + 2), Point2D(right - 1, top - rng.uniform(1, 2))),
    )
    return workspace, points, segments


def _draw_workspace(ax: Axes, workspace: Workspace) -> None:
    bounds = workspace.bounds
    ax.set(xlim=(bounds.xmin, bounds.xmax), ylim=(bounds.ymin, bounds.ymax), xlabel="x", ylabel="y")
    ax.set_aspect("equal")
    ax.set_axisbelow(True)
    ax.grid(color="#e5e9ee", linewidth=0.7)
    for rectangle in workspace.rectangles:
        ax.add_patch(
            RectanglePatch(
                (rectangle.xmin, rectangle.ymin),
                rectangle.xmax - rectangle.xmin,
                rectangle.ymax - rectangle.ymin,
                facecolor="#eef3f7",
                edgecolor="#35475a",
                linewidth=1.3,
            )
        )


def plot_scene(seed: int) -> Figure:
    from matplotlib import pyplot as plt

    workspace, points, segments = generate_scene(seed)
    (rectangle,) = workspace.rectangles
    fig, (point_ax, segment_ax) = plt.subplots(1, 2, figsize=(11, 5.6), layout="constrained")
    for ax in (point_ax, segment_ax):
        _draw_workspace(ax, workspace)

    for location, (label, color, marker) in POINT_STYLES.items():
        matching = [point for point in points if rectangle.locate(point) is location]
        point_ax.scatter(
            [point.x for point in matching], [point.y for point in matching],
            label=label, color=color, marker=marker, zorder=3,
        )
    point_ax.set_title("Points relative to the rectangle")
    point_ax.legend(loc="upper left")

    for start, end in segments:
        relation = segment_rectangle_relation(start, end, rectangle)
        label, color, linestyle = SEGMENT_STYLES[relation]
        segment_ax.plot(
            (start.x, end.x), (start.y, end.y), label=label, color=color,
            linestyle=linestyle, marker="o", markersize=4, linewidth=2, zorder=3,
        )
    segment_ax.set_title("Segments relative to the rectangle")
    segment_ax.legend(loc="upper left")
    fig.suptitle(f"2D geometry classification · seed {seed}")
    return fig


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42, help="Random seed (default: 42).")
    parser.add_argument("--output", type=Path, help="Save the figure instead of opening a window.")
    args = parser.parse_args()

    if args.output is not None:
        matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    fig = plot_scene(args.seed)
    if args.output is None:
        plt.show()
    else:
        fig.savefig(args.output, dpi=160)
    plt.close(fig)


if __name__ == "__main__":
    main()
