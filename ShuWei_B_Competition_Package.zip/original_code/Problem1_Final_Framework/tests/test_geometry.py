from math import inf, nan, nextafter

import pytest

from geometry import (
    Point2D,
    PointLocation,
    Rectangle,
    SegmentIntersection,
    SegmentRectangleRelation,
    Workspace,
    point_on_segment,
    segment_intersection,
    segment_rectangle_relation,
)


RECTANGLE = Rectangle(0, 0, 4, 3)


@pytest.mark.parametrize(
    ("coordinates", "expected"),
    [
        ((2, 1), PointLocation.INSIDE),
        ((0, 1), PointLocation.BOUNDARY),
        ((4, 1), PointLocation.BOUNDARY),
        ((2, 0), PointLocation.BOUNDARY),
        ((2, 3), PointLocation.BOUNDARY),
        ((0, 0), PointLocation.BOUNDARY),
        ((4, 3), PointLocation.BOUNDARY),
        ((0, 4), PointLocation.OUTSIDE),
        ((5, 3), PointLocation.OUTSIDE),
        ((nextafter(0, -inf), 1), PointLocation.OUTSIDE),
        ((nextafter(0, inf), 1), PointLocation.INSIDE),
    ],
)
def test_point_location(coordinates, expected):
    point = Point2D(*coordinates)
    assert RECTANGLE.locate(point) is expected
    assert RECTANGLE.is_on_boundary(point) == (expected is PointLocation.BOUNDARY)


@pytest.mark.parametrize("invalid", [inf, -inf, nan])
def test_nonfinite_coordinates(invalid):
    with pytest.raises(ValueError):
        Point2D(invalid, 0)
    with pytest.raises(ValueError):
        Rectangle(0, 0, 4, invalid)


@pytest.mark.parametrize("corners", [(0, 0, 0, 3), (0, 2, 4, 2), (2, 0, 1, 3)])
def test_invalid_rectangle_extent(corners):
    with pytest.raises(ValueError, match="positive width and height"):
        Rectangle(*corners)


def test_workspace_includes_rectangles_on_its_bounds():
    rectangle = Rectangle(0, 1, 2, 2)
    workspace = Workspace(RECTANGLE, (rectangle,))
    assert workspace.rectangles == (rectangle,)
    assert workspace.bounds.is_on_boundary(Point2D(0, 1))


def test_workspace_rejects_protruding_rectangle():
    with pytest.raises(ValueError, match="within the workspace"):
        Workspace(RECTANGLE, (Rectangle(1, 1, 5, 2),))


@pytest.mark.parametrize(
    ("coordinates", "expected"),
    [
        ((2, 2), True),
        ((0, 0), True),
        ((4, 4), True),
        ((5, 5), False),
        ((2, nextafter(2, inf)), False),
    ],
)
def test_point_on_closed_segment(coordinates, expected):
    assert point_on_segment(Point2D(*coordinates), Point2D(0, 0), Point2D(4, 4)) == expected


def test_point_on_zero_length_segment():
    point = Point2D(2, 3)
    assert point_on_segment(point, point, point)
    assert not point_on_segment(Point2D(2, 4), point, point)


@pytest.mark.parametrize(
    ("coordinates", "expected"),
    [
        (((0, 0), (4, 4), (0, 4), (4, 0)), SegmentIntersection.CROSS),
        (((0, 0), (4, 0), (2, 0), (2, 2)), SegmentIntersection.TOUCH),
        (((0, 0), (4, 0), (4, 0), (5, 1)), SegmentIntersection.TOUCH),
        (((0, 0), (4, 0), (4, 0), (5, 0)), SegmentIntersection.TOUCH),
        (((0, 0), (4, 0), (2, 0), (5, 0)), SegmentIntersection.OVERLAP),
        (((2, 0), (2, 4), (2, 4), (2, 0)), SegmentIntersection.OVERLAP),
        (((0, 0), (4, 0), (5, 0), (6, 0)), SegmentIntersection.DISJOINT),
        (((0, 0), (4, 0), (0, 1), (4, 1)), SegmentIntersection.DISJOINT),
        (((2, 0), (2, 0), (0, 0), (4, 0)), SegmentIntersection.TOUCH),
        (((2, 2), (2, 2), (2, 2), (2, 2)), SegmentIntersection.TOUCH),
        (((2, 2), (2, 2), (3, 2), (3, 2)), SegmentIntersection.DISJOINT),
        (((0, 0), (4, 0), (2, 1), (2, 1)), SegmentIntersection.DISJOINT),
    ],
)
def test_segment_intersection(coordinates, expected):
    a, b, c, d = (Point2D(*xy) for xy in coordinates)
    assert segment_intersection(a, b, c, d) is expected
    assert segment_intersection(d, c, b, a) is expected


@pytest.mark.parametrize(
    ("coordinates", "expected"),
    [
        (((-1, 0), (-0.5, 0)), SegmentRectangleRelation.DISJOINT),
        (((-1, 4), (5, 4)), SegmentRectangleRelation.DISJOINT),
        (((-1, 1), (1, -1)), SegmentRectangleRelation.TOUCH),
        (((1, 4), (1, 3)), SegmentRectangleRelation.TOUCH),
        (((-1, 0), (2, 0)), SegmentRectangleRelation.OVERLAP),
        (((4, 0), (4, 3)), SegmentRectangleRelation.OVERLAP),
        (((-1, 1), (5, 1)), SegmentRectangleRelation.CROSS),
        (((0, 0), (4, 3)), SegmentRectangleRelation.CROSS),
        (((0, 1), (2, 1)), SegmentRectangleRelation.CROSS),
        (((1, 1), (2, 2)), SegmentRectangleRelation.INSIDE),
        (((2, 1), (2, 1)), SegmentRectangleRelation.INSIDE),
        (((0, 1), (0, 1)), SegmentRectangleRelation.TOUCH),
        (((-1, -1), (-1, -1)), SegmentRectangleRelation.DISJOINT),
    ],
)
def test_segment_rectangle_relation(coordinates, expected):
    start, end = (Point2D(*xy) for xy in coordinates)
    assert segment_rectangle_relation(start, end, RECTANGLE) is expected
    assert segment_rectangle_relation(end, start, RECTANGLE) is expected


def test_coordinates_with_large_offsets():
    offset = 10**30
    assert segment_intersection(
        Point2D(offset, offset),
        Point2D(offset + 2, offset + 2),
        Point2D(offset, offset + 2),
        Point2D(offset + 2, offset),
    ) is SegmentIntersection.CROSS
