"""Run the three integrated models on synthetic geometry examples."""

import argparse
from collections.abc import Sequence
from pathlib import Path

from feasible_region.validation import run_full
from feasible_region.workflow import run_examples


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42, help="Seed for the 3D scene.")
    parser.add_argument("--output-dir", type=Path, help="Custom output directory. Default: outputs.")
    parser.add_argument("--full", action="store_true", help="Include validation when specifying a custom directory.")
    args = parser.parse_args(argv)

    import matplotlib

    matplotlib.use("Agg")
    full = args.full or args.output_dir is None
    destination = args.output_dir if args.output_dir is not None else Path("outputs")
    run = run_full if full else run_examples
    outputs = run(destination, seed=args.seed)
    for path in outputs.values():
        print(path.resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
