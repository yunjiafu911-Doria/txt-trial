import csv
from pathlib import Path

import main


def test_default_main_targets_outputs_and_enables_validation(monkeypatch, tmp_path):
    called = []
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(main, "run_full", lambda directory, *, seed: called.append((directory, seed)) or {})
    assert main.main([]) == 0
    assert called == [(Path("outputs"), 42)]


def test_full_entrypoint_writes_validated_plots_data_and_report(tmp_path):
    destination = tmp_path / "full results"
    assert main.main(["--full", "--output-dir", str(destination), "--seed", "42"]) == 0
    expected = {
        "constraints_2d.csv", "geometry_3d.csv", "scene_2d.png", "scene_3d.png",
        "resolution_experiment.csv", "boundary_probes.csv", "grid_comparison.csv",
        "constraint_comparison.png", "constraint_comparison.pdf", "VALIDATION.md",
    }
    assert {path.name for path in destination.iterdir()} == expected

    def csv_rows(name):
        with (destination / name).open(encoding="utf-8", newline="") as stream:
            return list(csv.DictReader(stream))

    planar = csv_rows("constraints_2d.csv")
    assert {row["sample_id"] for row in planar if row["included"] == "1"} == {"interior", "closed_cut"}
    assert [row["segment_box_state"] for row in csv_rows("geometry_3d.csv")] == ["disjoint", "interior", "touch"]
    assert len(csv_rows("boundary_probes.csv")) == 45
    assert len(csv_rows("grid_comparison.csv")) == 48**2
    runs = csv_rows("resolution_experiment.csv")
    assert len(runs) == 45 and all(int(row["sample_disagreements"]) == 0 for row in runs)
    report = (destination / "VALIDATION.md").read_text(encoding="utf-8")
    assert "681,280" in report and "分歧数为 0" in report and "67.3574358897" in report
    for plot in ("scene_2d.png", "scene_3d.png", "constraint_comparison.png"):
        assert (destination / plot).read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
    assert (destination / "constraint_comparison.pdf").read_bytes().startswith(b"%PDF-")
