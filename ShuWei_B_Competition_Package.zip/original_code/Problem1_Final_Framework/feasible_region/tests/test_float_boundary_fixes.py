from fractions import Fraction as F
from math import inf, nextafter, sqrt

import numpy as np
import pytest

from geometry import Point2D, Rectangle, Workspace
from feasible_region import CenterState, Disk, FeasibleRegion
from feasible_region.api import center_constraint
from feasible_region.constraint_analysis import BoxConstraint, ConstraintSet, DiskConstraint, Interval, Membership


def region(tolerance=0):
    return FeasibleRegion(
        Workspace(Rectangle(-3, -3, 4, 4), (Rectangle(0, 0, 1, 1),)), Disk(1), tolerance
    )


def test_minkowski_reproduction_agrees_in_scalar_batch_and_slice():
    model = region()
    height = 1 + 2.0**-30
    point = Point2D(2, height)
    assert (F(point.x) - 1)**2 + (F(height) - 1)**2 - 1 == F(1, 2**60)
    assert model.classify(point) is CenterState.FREE
    assert model.classify_exact(point) is CenterState.FREE
    assert model.inflated_obstacles[0].signed_clearance(point) == pytest.approx(2.0**-61, abs=0)
    np.testing.assert_array_equal(model.classify_points([2, 2], [height, 1]), [CenterState.FREE, CenterState.CONTACT])
    assert any(a < point.x < b for a, b in model.horizontal_free_intervals(height))
    assert region(2.0**-45).classify_exact(point) is CenterState.CONTACT


def test_projected_marker_is_diagnosed_and_exact_contact_policy_is_available():
    model = region()
    height = 1 + 2.0**-30
    edge = model.inflated_obstacles[0].horizontal_span(height)[1]
    point = Point2D(edge, height)
    assert edge == nextafter(2, -inf)
    comparison = model.boundary_diagnostic(point)
    assert comparison.state is CenterState.CONTACT
    assert comparison.exact_state is CenterState.OBSTACLE_OVERLAP
    assert comparison.rounding_sensitive
    assert not model.is_legal(point, allow_contact=True, exact=True)
    assert not model.is_legal(point, allow_contact=True)
    assert not ConstraintSet((center_constraint(model, allow_contact=True),)).contains(point)
    assert model.boundary_diagnostic(Point2D(2, 1)).rounding_sensitive is False


def test_legacy_decimal_cap_remains_queryable_with_exact_disagreement_flag():
    model = FeasibleRegion(
        Workspace(Rectangle(0, 0, 5, 5), (Rectangle(1, 1, 2, 2),)), Disk(0.1), tolerance=0
    )
    point = Point2D(1.5, 2.0 + 0.1)
    assert model.boundary_diagnostic(point).rounding_sensitive
    assert model.classify(point) is CenterState.CONTACT
    assert model.classify_exact(point) is CenterState.FREE


@pytest.mark.parametrize("closed", [False, True])
def test_disk_slice_membership_matches_exact_neighbors(closed):
    domain = ConstraintSet((DiskConstraint((0, 0), 1, closed=closed),))
    section = domain.horizontal_section(0.5)
    endpoint = sqrt(0.75)
    assert F(endpoint)**2 + F(1, 4) < 1
    for x in (endpoint, -endpoint, nextafter(endpoint, inf), nextafter(-endpoint, -inf)):
        expected = F(x)**2 + F(1, 4) < 1
        assert section.contains(x) == domain.contains((x, 0.5)) == expected
    exact = domain.horizontal_section(0)
    assert exact.contains(1) is closed
    assert domain.classify((1, 0)) is (Membership.CLOSED_BOUNDARY if closed else Membership.OPEN_BOUNDARY)


def test_open_disk_slice_resolves_translated_cancellation_and_tiny_chord():
    translated = ConstraintSet((DiskConstraint((1, 0), 1, closed=False),))
    y = 2.0**-30
    section = translated.horizontal_section(y)
    assert not section.contains(0)
    assert section.lower > 0
    assert section.contains(section.lower) and translated.contains((section.lower, y))
    assert not translated.contains((nextafter(section.lower, -inf), y))

    tiny = ConstraintSet((DiskConstraint((1, 0), 2.0**-60, closed=False),))
    assert tiny.horizontal_section(0) == Interval(1, 1)
    assert tiny.horizontal_section(2.0**-60) is None


def test_exact_disk_slice_rejects_rounded_vertical_tangent_and_intersects_box():
    disk = DiskConstraint((0, 2), 0.1)
    assert disk.horizontal_slice(2.0 + 0.1) is None
    radius = DiskConstraint((0, 0), 1, closed=False)
    x = sqrt(0.75)
    intersection = ConstraintSet((radius, BoxConstraint((Interval(-2, x, True, False), Interval(0, 1)))))
    section = intersection.horizontal_section(0.5)
    assert not section.contains(x)
    assert section.contains(nextafter(x, -inf))


def test_sub_ulp_disk_tolerance_is_not_lost_to_radius_rounding():
    point = (1, 2.0**-30)
    tolerance = 2.0**-60
    assert 1 + tolerance == 1
    closed = ConstraintSet((DiskConstraint((0, 0), 1),))
    opened = ConstraintSet((DiskConstraint((0, 0), 1, closed=False),))
    assert closed.classify(point) is Membership.OUTSIDE
    assert closed.classify(point, tolerance=tolerance) is Membership.CLOSED_BOUNDARY
    assert opened.classify(point, tolerance=tolerance) is Membership.OPEN_BOUNDARY
