import csv
import os
from pathlib import Path
import subprocess
import sys

import matplotlib

from geometry import Point2D, Rectangle, Workspace
from feasible_region import Disk, FeasibleRegion
from feasible_region import api
from feasible_region.constraint_analysis import ConstraintSet
from feasible_region.geometry3d import AxisAlignedBox, Point3D, Segment3D
from feasible_region.workflow import run_examples


def _read_csv(path):
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def test_api_reexports_the_existing_geometry_types_by_identity():
    original_types = (Point2D, Rectangle, Workspace, Disk, FeasibleRegion, Point3D, Segment3D, AxisAlignedBox, ConstraintSet)
    public_types = (api.Point2D, api.Rectangle, api.Workspace, api.Disk, api.FeasibleRegion,
                    api.Point3D, api.Segment3D, api.AxisAlignedBox, api.ConstraintSet)
    assert all(public is original for public, original in zip(public_types, original_types))
    assert api.coordinates(api.Point3D(2, 3, 4)) == (2, 3, 4)


def test_center_adapter_preserves_contact_policy_and_forwards_tolerance():
    domain = Workspace(Rectangle(0, 0, 12, 8), (Rectangle(3, 2, 5, 4),))
    region = FeasibleRegion(domain, Disk(0.75), tolerance=0.0)
    blocking = ConstraintSet((api.center_constraint(region),))
    allowing = ConstraintSet((api.center_constraint(region, allow_contact=True),))
    tangent = Point2D(2.25, 3)
    assert blocking.classify(tangent) is api.Membership.OPEN_BOUNDARY
    assert not blocking.contains(tangent)
    assert allowing.classify(tangent) is api.Membership.CLOSED_BOUNDARY
    assert allowing.contains(tangent)
    slight_overlap = Point2D(2.25001, 3)
    assert not allowing.contains(slight_overlap)
    assert allowing.contains(slight_overlap, tolerance=0.001)


def test_example_workflow_connects_existing_models_and_writes_data(tmp_path):
    matplotlib.use("Agg")
    files = run_examples(tmp_path, seed=42)
    assert set(files) == {"constraints_2d.csv", "geometry_3d.csv", "scene_2d.png", "scene_3d.png"}
    planar = {row["sample_id"]: row for row in _read_csv(files["constraints_2d.csv"])}
    assert planar["interior"]["intersection_state"] == "interior"
    assert planar["obstacle"]["footprint_state"] == "obstacle_overlap"
    assert planar["obstacle"]["included"] == "0"
    assert planar["obstacle_touch"]["intersection_state"] == "open_boundary"
    assert planar["workspace_touch"]["footprint_state"] == "contact"
    assert planar["open_cut"]["footprint_state"] == "free"
    assert planar["open_cut"]["intersection_state"] == "open_boundary"
    assert planar["closed_cut"]["intersection_state"] == "closed_boundary"
    assert planar["closed_cut"]["included"] == "1"

    spatial = _read_csv(files["geometry_3d.csv"])
    assert [r["segment_box_state"] for r in spatial] == ["disjoint", "interior", "touch"]
    assert [r["midpoint_intersection_state"] for r in spatial] == ["outside", "interior", "closed_boundary"]
    assert [r["midpoint_included"] for r in spatial] == ["0", "1", "1"]
    for row in spatial:
        start = Point3D(*(float(row[f"start_{axis}"]) for axis in ("x", "y", "z")))
        end = Point3D(*(float(row[f"end_{axis}"]) for axis in ("x", "y", "z")))
        assert float(row["horizontal_distance"]) == api.horizontal_distance(start, end)
        assert float(row["azimuth_deg"]) == api.azimuth(start, end)
        assert float(row["elevation_deg"]) == api.elevation(start, end)
        assert int(row["azimuth_in_band"]) == api.angle_in_interval(api.azimuth(start, end), 350, 8, period=360)
    for name in ("scene_2d.png", "scene_3d.png"):
        assert files[name].read_bytes().startswith(b"\x89PNG\r\n\x1a\n")


def test_main_cli_uses_requested_seed_and_output_directory(tmp_path):
    root = Path(__file__).resolve().parents[2]
    output = tmp_path / "cli output"
    completed = subprocess.run(
        [sys.executable, "-B", "-W", "error", str(root / "main.py"), "--seed", "13", "--output-dir", str(output)],
        cwd=tmp_path, check=True, capture_output=True, text=True, encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    assert {file.name for file in output.iterdir()} == {
        "constraints_2d.csv", "geometry_3d.csv", "scene_2d.png", "scene_3d.png",
    }
    assert all(str(file.resolve()) in completed.stdout for file in output.iterdir())
    from feasible_region.geometry3d.demo import generate_scene

    _, segments = generate_scene(13)
    rows = _read_csv(output / "geometry_3d.csv")
    assert [float(row["start_x"]) for row in rows] == [segment.start.x for segment in segments]
