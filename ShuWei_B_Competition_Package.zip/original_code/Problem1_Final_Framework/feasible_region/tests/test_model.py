import numpy as np
import pytest

from feasible_region import CenterState, Disk, FeasibleRegion, Point, Rectangle, Workspace, minkowski_sum


OBSTACLE = Rectangle(12, 12, 17, 17)
WORKSPACE = Workspace(Rectangle(0, 0, 30, 30), (OBSTACLE,))


@pytest.mark.parametrize(
    ("point", "expected"),
    [
        (Point(9, 8), CenterState.CONTACT),
        (Point(9.1, 8), CenterState.OBSTACLE_OVERLAP),
        (Point(8, 8), CenterState.FREE),
        (Point(7, 14), CenterState.CONTACT),
        (Point(5, 8), CenterState.CONTACT),
        (Point(4.9, 8), CenterState.OUTSIDE_WORKSPACE),
        (Point(25, 25), CenterState.CONTACT),
        (Point(15, 15), CenterState.OBSTACLE_OVERLAP),
    ],
)
def test_point_classification_for_edges_and_circular_corners(point, expected):
    region = FeasibleRegion(WORKSPACE, Disk(5), tolerance=0)
    assert region.classify(point) is expected
    assert region.is_legal(point) == (expected is CenterState.FREE)
    assert region.is_legal(point, allow_contact=True) == (expected in (CenterState.FREE, CenterState.CONTACT))


def test_minkowski_spans_and_signed_clearances():
    shape = minkowski_sum(OBSTACLE, Disk(5))
    assert shape.horizontal_span(14) == (7, 22)
    assert shape.horizontal_span(8) == (9, 20)
    assert shape.horizontal_span(7) == (12, 17)
    assert shape.horizontal_span(6.999) is None
    assert shape.signed_clearance(Point(9, 8)) == 0
    assert shape.signed_clearance(Point(8, 8)) == pytest.approx(np.sqrt(32) - 5)
    assert shape.signed_clearance(Point(14, 14)) == -7


@pytest.mark.parametrize(
    ("x", "expected"),
    [
        (1.94, CenterState.OUTSIDE_WORKSPACE),
        (1.96, CenterState.CONTACT),
        (2.04, CenterState.CONTACT),
        (2.06, CenterState.FREE),
        (9.94, CenterState.FREE),
        (9.96, CenterState.CONTACT),
        (10.04, CenterState.CONTACT),
        (10.06, CenterState.OBSTACLE_OVERLAP),
    ],
)
def test_absolute_tolerance_is_symmetric_for_wall_and_obstacle(x, expected):
    region = FeasibleRegion(WORKSPACE, Disk(2), tolerance=0.05)
    assert region.classify(Point(x, 14)) is expected
    from_sections = any(left < x < right for left, right in region.horizontal_free_intervals(14))
    assert from_sections == (expected is CenterState.FREE)


def test_collision_has_priority_over_contact_and_workspace_violation_over_collision():
    workspace = Workspace(Rectangle(0, 0, 10, 10), (Rectangle(0, 3, 3, 7),))
    region = FeasibleRegion(workspace, Disk(1), tolerance=0)
    assert region.classify(Point(1, 5)) is CenterState.OBSTACLE_OVERLAP
    assert region.classify(Point(0, 5)) is CenterState.OUTSIDE_WORKSPACE


def test_zero_radius_preserves_rectangle_as_a_closed_obstacle():
    region = FeasibleRegion(WORKSPACE, Disk(0), tolerance=0)
    assert region.classify(Point(14, 14)) is CenterState.OBSTACLE_OVERLAP
    assert region.classify(Point(12, 12)) is CenterState.CONTACT
    assert region.classify(Point(0, 8)) is CenterState.CONTACT
    assert region.horizontal_free_intervals(12) == ((0, 12), (17, 30))
    assert region.horizontal_free_intervals(11) == ((0, 30),)
    assert minkowski_sum(OBSTACLE, Disk(0)).horizontal_span(11) is None


def test_empty_strict_workspace_and_degenerate_contact_line():
    workspace = Workspace(Rectangle(0, 0, 6, 8))
    exact_fit = FeasibleRegion(workspace, Disk(3), tolerance=0)
    assert exact_fit.strict_bounds is None
    assert exact_fit.horizontal_free_intervals(4) == ()
    assert exact_fit.classify(Point(3, 4)) is CenterState.CONTACT
    assert exact_fit.is_legal(Point(3, 4), allow_contact=True)
    oversized = FeasibleRegion(workspace, Disk(3.1), tolerance=0)
    assert not oversized.is_legal(Point(3, 4), allow_contact=True)


def test_analytic_sections_subtract_merged_and_clipped_spans():
    bounds = Rectangle(0, 0, 25, 20)
    workspace = Workspace(bounds, (
        Rectangle(4, 8, 9, 12), Rectangle(10, 8, 13, 12), Rectangle(0, 8, 1, 12),
    ))
    region = FeasibleRegion(workspace, Disk(1), tolerance=0)
    assert region.horizontal_free_intervals(10) == ((2, 3), (14, 24))
    assert region.horizontal_free_intervals(4) == ((1, 24),)
    assert region.horizontal_free_intervals(1) == ()
    assert region.horizontal_free_intervals(19) == ()


def test_corner_sections_have_open_endpoints():
    region = FeasibleRegion(WORKSPACE, Disk(5), tolerance=0)
    assert region.horizontal_free_intervals(8) == ((5, 9), (20, 25))
    assert region.classify(Point(9, 8)) is CenterState.CONTACT
    assert region.classify(Point(20, 8)) is CenterState.CONTACT


@pytest.mark.parametrize("value", [-1, np.nan, np.inf])
def test_invalid_radius_or_tolerance(value):
    with pytest.raises(ValueError, match="radius"):
        Disk(value)
    with pytest.raises(ValueError, match="tolerance"):
        FeasibleRegion(WORKSPACE, Disk(1), tolerance=value)


def test_rejects_nonfinite_evaluation_coordinates():
    region = FeasibleRegion(WORKSPACE, Disk(1))
    with pytest.raises(ValueError, match="finite"):
        region.classify_points([0, np.nan], 1)
    with pytest.raises(ValueError, match="finite"):
        region.horizontal_free_intervals(np.inf)


def test_decimal_workspace_contact_matches_open_interval_endpoint():
    region = FeasibleRegion(Workspace(Rectangle(0.1, 0.1, 10, 8)), Disk(0.2), tolerance=0)
    (left, right), = region.horizontal_free_intervals(3)
    assert region.classify(Point(left, 3)) is CenterState.CONTACT
    assert region.classify(Point(right, 3)) is CenterState.CONTACT
    assert not region.is_legal(Point(left, 3))
    assert region.is_legal(Point(left, 3), allow_contact=True)
    assert region.classify(Point(float(np.nextafter(left, right)), 3)) is CenterState.FREE


@pytest.mark.parametrize("height", [1.5, 0.96])
def test_decimal_obstacle_edge_and_arc_use_same_endpoints_as_sections(height):
    obstacle = Rectangle(0.4, 1, 1, 2)
    region = FeasibleRegion(Workspace(Rectangle(0, 0, 5, 5), (obstacle,)), Disk(0.1), tolerance=0)
    (_, left), (right, _) = region.horizontal_free_intervals(height)
    assert region.inflated_obstacles[0].horizontal_span(height) == (left, right)
    assert region.classify(Point(left, height)) is CenterState.CONTACT
    assert region.classify(Point(right, height)) is CenterState.CONTACT
    assert region.classify(Point(float(np.nextafter(left, right)), height)) is CenterState.OBSTACLE_OVERLAP
    assert region.classify(Point(float(np.nextafter(left, -np.inf)), height)) is CenterState.FREE


@pytest.mark.parametrize("top", [2.0, 2.5])
def test_decimal_tangent_cap_remains_closed(top):
    obstacle = Rectangle(1, 1, 2, top)
    region = FeasibleRegion(Workspace(Rectangle(0, 0, 5, 5), (obstacle,)), Disk(0.1), tolerance=0)
    y = top + 0.1
    assert region.inflated_obstacles[0].horizontal_span(y) == (1, 2)
    assert region.horizontal_free_intervals(y) == ((0.1, 1), (2, 4.9))
    assert region.classify(Point(1.5, y)) is CenterState.CONTACT
    assert region.classify(Point(1.5, float(np.nextafter(y, np.inf)))) is CenterState.FREE


def test_negative_lower_tolerance_threshold_detects_only_deep_obstacle_overlap():
    obstacle = Rectangle(1, 1, 3, 3)
    region = FeasibleRegion(Workspace(Rectangle(0, 0, 5, 5), (obstacle,)), Disk(0.1), tolerance=0.3)
    assert region.classify(Point(1.1, 2)) is CenterState.CONTACT
    assert region.classify(Point(1.25, 2)) is CenterState.OBSTACLE_OVERLAP


def test_complex_arrays_are_rejected_instead_of_discarding_imaginary_parts():
    region = FeasibleRegion(WORKSPACE, Disk(1))
    with pytest.raises(ValueError, match="real"):
        region.classify_points(np.array([8 + 2j]), 10)
