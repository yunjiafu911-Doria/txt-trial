import csv
import struct
from math import pi

import matplotlib
import numpy as np
import pytest

from feasible_region import CenterState, Disk, FeasibleRegion, Rectangle, Workspace, sample_grid
from feasible_region.demo import generate_workspace
from feasible_region.reporting import plot_comparison, write_grid_csv, write_sections_csv


@pytest.mark.parametrize("seed", [0, 42, 999])
def test_synthetic_workspaces_reproduce_and_grid_agrees_with_analytic_sections(seed):
    scene = generate_workspace(seed)
    assert scene == generate_workspace(seed)
    assert scene != generate_workspace(seed + 1)
    region = FeasibleRegion(scene, Disk(1.15), tolerance=0.02)
    grid = sample_grid(region, 40, 32)
    x = grid.x_centers
    for row, y in enumerate(grid.y_centers):
        strict_from_sections = np.zeros(x.shape, dtype=bool)
        for left, right in region.horizontal_free_intervals(y):
            strict_from_sections |= (left < x) & (x < right)
        np.testing.assert_array_equal(strict_from_sections, grid.states[row] == CenterState.FREE)


def test_grid_counts_cells_by_center_and_estimates_area():
    region = FeasibleRegion(Workspace(Rectangle(0, 0, 4, 4)), Disk(0.5), tolerance=0)
    grid = sample_grid(region, 4, 4)
    np.testing.assert_array_equal(grid.x_centers, [0.5, 1.5, 2.5, 3.5])
    assert grid.states.shape == (4, 4)
    assert np.count_nonzero(grid.states == CenterState.CONTACT) == 12
    assert grid.estimated_free_area == 4


def test_grid_refinement_approaches_known_continuous_area():
    radius = 1.3
    workspace = Workspace(Rectangle(0, 0, 20, 16), (Rectangle(8, 7, 12, 10),))
    region = FeasibleRegion(workspace, Disk(radius), tolerance=0)
    expected = (20 - 2 * radius) * (16 - 2 * radius) - (12 + 14 * radius + pi * radius**2)
    coarse = sample_grid(region, 8, 7).estimated_free_area
    fine = sample_grid(region, 200, 160).estimated_free_area
    assert abs(fine - expected) < abs(coarse - expected)
    assert fine == pytest.approx(expected, abs=0.8)


@pytest.mark.parametrize("cells", [0, -1, 2.5, True])
def test_invalid_cell_counts(cells):
    region = FeasibleRegion(Workspace(Rectangle(0, 0, 4, 4)), Disk(0.5))
    with pytest.raises(ValueError, match="nx"):
        sample_grid(region, cells, 2)


def test_outputs_include_grid_states_open_intervals_and_vector_pdf(tmp_path):
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    workspace = Workspace(Rectangle(0, 0, 6, 6), (Rectangle(2, 2, 4, 4),))
    region = FeasibleRegion(workspace, Disk(0.5), tolerance=0)
    grid = sample_grid(region, 6, 6)
    grid_path = tmp_path / "grid.csv"
    sections_path = tmp_path / "sections.csv"
    write_grid_csv(grid, grid_path)
    write_sections_csv(region, [0.5, 3], sections_path)
    with grid_path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    assert len(rows) == 36
    assert rows[0]["state"] == "contact"
    assert rows[0]["strictly_legal"] == "0"
    assert any(row["state"] == "obstacle_overlap" for row in rows)
    with sections_path.open(newline="", encoding="utf-8") as stream:
        sections = list(csv.DictReader(stream))
    assert sections[0]["x_lower_open"] == ""
    assert [(float(row["x_lower_open"]), float(row["x_upper_open"])) for row in sections[1:]] == [
        (0.5, 1.5), (4.5, 5.5),
    ]

    figure = plot_comparison(region, grid)
    try:
        png_path = tmp_path / "plot.png"
        pdf_path = tmp_path / "plot.pdf"
        figure.savefig(png_path, dpi=320)
        figure.savefig(pdf_path)
        png = png_path.read_bytes()
        assert png.startswith(b"\x89PNG\r\n\x1a\n")
        assert struct.unpack(">II", png[16:24]) == (3520, 1632)
        pdf = pdf_path.read_bytes()
        assert pdf.startswith(b"%PDF-")
        assert b"/Subtype /Image" not in pdf
    finally:
        plt.close(figure)


@pytest.mark.parametrize("cells", [4, 8])
def test_grid_rejects_centers_or_edges_that_cannot_be_represented(cells):
    offset = 1e16
    workspace = Workspace(Rectangle(offset, offset, offset + 8, offset + 8))
    with pytest.raises(ValueError, match="coordinate precision"):
        sample_grid(FeasibleRegion(workspace, Disk(0)), cells, 2)
