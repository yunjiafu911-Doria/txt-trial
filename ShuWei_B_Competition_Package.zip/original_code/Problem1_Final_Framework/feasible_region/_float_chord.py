"""Representable endpoints for circular chords on binary64 inputs."""

from fractions import Fraction
from math import inf, isfinite, nextafter
from struct import pack, unpack
from sys import float_info


_SIGN = 1 << 63
_MASK = (1 << 64) - 1


def _rank(value: float) -> int:
    bits, = unpack(">Q", pack(">d", value))
    return bits ^ _MASK if bits & _SIGN else bits ^ _SIGN


def _from_rank(rank: int) -> float:
    bits = rank ^ _SIGN if rank & _SIGN else rank ^ _MASK
    return unpack(">d", pack(">Q", bits))[0]


def inward_endpoint(
    center: float, approximate: float, width_squared: Fraction, direction: int
) -> tuple[float, bool]:
    """Return the last float inside a closed half-chord and whether it is exact."""
    if width_squared == 0:
        return center, True
    origin = Fraction(center)

    def difference(x: float) -> Fraction:
        return (Fraction(x) - origin) ** 2 - width_squared

    edge = direction * float_info.max
    outward = direction * inf
    guess = approximate if isfinite(approximate) else edge
    guess = max(center, guess) if direction > 0 else min(center, guess)
    gap = difference(guess)
    if gap <= 0:
        neighbor = nextafter(guess, outward)
        if not isfinite(neighbor) or difference(neighbor) > 0:
            return guess, gap == 0
    else:
        neighbor = nextafter(guess, center)
        gap = difference(neighbor)
        if gap <= 0:
            return neighbor, gap == 0

    # Translation or a near-tangent slice can invalidate a one-ULP adjustment.
    # Search ordered float ranks instead of walking every intervening float.
    edge_gap = difference(edge)
    if edge_gap <= 0:
        return edge, edge_gap == 0
    inside, outside = _rank(center), _rank(edge)
    while abs(inside - outside) > 1:
        middle = (inside + outside) // 2
        if difference(_from_rank(middle)) <= 0:
            inside = middle
        else:
            outside = middle
    endpoint = _from_rank(inside)
    return endpoint, difference(endpoint) == 0
