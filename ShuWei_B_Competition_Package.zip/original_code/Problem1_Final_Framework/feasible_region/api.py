"""Unified imports for the existing two-dimensional, three-dimensional, and constraint models."""

from geometry import (
    Point2D,
    PointLocation,
    Rectangle,
    SegmentIntersection,
    SegmentRectangleRelation,
    Workspace,
    point_on_segment,
    segment_intersection,
    segment_rectangle_relation,
)

from .constraint_analysis import (
    BoxConstraint,
    ConstraintSet,
    DiskConstraint,
    Interval,
    Membership,
    PredicateConstraint,
    coordinates,
)
from .constraint_analysis.sampling import analytic_membership, sample_grid as sample_constraint_grid
from .geometry3d import (
    AxisAlignedBox,
    BoxIntersection,
    Point3D,
    Segment3D,
    angle_in_interval,
    azimuth,
    elevation,
    horizontal_distance,
    segment_box_intersection,
)
from .model import CenterState, Disk, FeasibleRegion, RoundedRectangle, minkowski_sum
from .sampling import sample_grid as sample_feasible_grid


__all__ = [
    "Point2D", "PointLocation", "Rectangle", "SegmentIntersection", "SegmentRectangleRelation",
    "Workspace", "point_on_segment", "segment_intersection", "segment_rectangle_relation",
    "Disk", "RoundedRectangle", "CenterState", "FeasibleRegion", "minkowski_sum", "sample_feasible_grid",
    "Point3D", "Segment3D", "AxisAlignedBox", "BoxIntersection", "segment_box_intersection",
    "horizontal_distance", "azimuth", "elevation", "angle_in_interval",
    "Interval", "BoxConstraint", "DiskConstraint", "PredicateConstraint", "ConstraintSet",
    "Membership", "coordinates", "sample_constraint_grid", "analytic_membership", "center_constraint",
]


def center_constraint(region: FeasibleRegion, *, allow_contact: bool = False) -> PredicateConstraint:
    """Adapt the 2D footprint model to a boundary-aware Boolean constraint.

    The parent constraint set supplies the tolerance. An existing region can be
    reused when its tolerance equals that value.
    """
    boundary = Membership.CLOSED_BOUNDARY if allow_contact else Membership.OPEN_BOUNDARY
    memberships = {
        CenterState.OUTSIDE_WORKSPACE: Membership.OUTSIDE,
        CenterState.OBSTACLE_OVERLAP: Membership.OUTSIDE,
        CenterState.CONTACT: boundary,
        CenterState.FREE: Membership.INTERIOR,
    }

    def classify(point: tuple[float, ...], tolerance: float) -> Membership:
        active = region if tolerance == region.tolerance else FeasibleRegion(region.workspace, region.disk, tolerance)
        center = Point2D(*point)
        state = active.classify(center)
        if allow_contact and state is CenterState.CONTACT:
            state = active.classify_exact(center)
        return memberships[state]

    return PredicateConstraint(2, classify)
