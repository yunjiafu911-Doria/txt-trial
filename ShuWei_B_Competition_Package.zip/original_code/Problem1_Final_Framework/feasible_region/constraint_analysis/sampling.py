"""Cell-based sampling and pointwise checks against continuous horizontal slices."""

from dataclasses import dataclass
from operator import index

import numpy as np
from numpy.typing import NDArray

from geometry import Rectangle

from .model import ConstraintSet, Membership, _finite, _tolerance


@dataclass(frozen=True, slots=True)
class GridSample:
    x_edges: NDArray[np.float64]
    y_edges: NDArray[np.float64]
    x: NDArray[np.float64]
    y: NDArray[np.float64]
    states: NDArray[np.uint8]

    @property
    def feasible(self) -> NDArray[np.bool_]:
        return self.states >= Membership.CLOSED_BOUNDARY

    @property
    def area(self) -> float:
        cell_areas = np.diff(self.y_edges)[:, None] * np.diff(self.x_edges)[None, :]
        return float(cell_areas[self.feasible].sum())


def _axis(lower: float, upper: float, n: int, phase: float):
    edges = np.linspace(lower, upper, n + 1)
    samples = (1 - phase) * edges[:-1] + phase * edges[1:]
    if not np.all((edges[:-1] < samples) & (samples < edges[1:])):
        raise ValueError("grid phase or resolution exceeds coordinate precision.")
    return edges, samples


def sample_grid(
    constraints: ConstraintSet,
    bounds: Rectangle,
    resolution: int,
    *,
    phase: tuple[float, float] = (0.5, 0.5),
    tolerance: float = 0.0,
) -> GridSample:
    """Sample one point within each cell, with phase in (0, 1) on each axis."""
    if constraints.dimension != 2:
        raise ValueError("grid sampling requires two-dimensional constraints.")
    if isinstance(resolution, (bool, np.bool_)):
        raise ValueError("resolution must be a positive integer.")
    try:
        n = index(resolution)
    except TypeError as error:
        raise ValueError("resolution must be a positive integer.") from error
    if n < 1:
        raise ValueError("resolution must be a positive integer.")

    x_phase, y_phase = (_finite(value, "phase") for value in phase)
    if not (0 < x_phase < 1 and 0 < y_phase < 1):
        raise ValueError("both phase values must lie within (0, 1).")
    tolerance = _tolerance(tolerance)
    x_edges, x = _axis(bounds.xmin, bounds.xmax, n, x_phase)
    y_edges, y = _axis(bounds.ymin, bounds.ymax, n, y_phase)
    x_values, y_values = x.tolist(), y.tolist()
    values = np.fromiter(
        (constraints._classify_coordinates((abscissa, ordinate), tolerance)
         for ordinate in y_values for abscissa in x_values),
        dtype=np.uint8,
        count=n * n,
    )
    return GridSample(x_edges, y_edges, x, y, values.reshape(n, n))


def analytic_membership(constraints: ConstraintSet, grid: GridSample) -> NDArray[np.bool_]:
    """Evaluate nominal analytic slices at every grid sample coordinate."""
    included = np.zeros(grid.states.shape, dtype=bool)
    for row, height in enumerate(grid.y):
        section = constraints.horizontal_section(height)
        if section is not None:
            left = grid.x >= section.lower if section.lower_closed else grid.x > section.lower
            right = grid.x <= section.upper if section.upper_closed else grid.x < section.upper
            included[row] = left & right
    return included
