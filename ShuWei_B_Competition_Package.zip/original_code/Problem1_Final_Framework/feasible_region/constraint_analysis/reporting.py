"""Write reproducible CSV tables and draw the grid-to-analytic comparison."""

import csv
from collections.abc import Sequence
from dataclasses import asdict
from math import acos, degrees, sqrt
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from .experiment import BoundaryProbe, ResolutionResult, Study
from .model import Membership
from .sampling import GridSample, analytic_membership

if TYPE_CHECKING:
    from matplotlib.figure import Figure


def write_rows(rows: Sequence[ResolutionResult] | Sequence[BoundaryProbe], path: Path) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(asdict(rows[0])))
        writer.writeheader()
        writer.writerows(map(asdict, rows))


def write_grid(study: Study, grid: GridSample, path: Path) -> None:
    analytic = analytic_membership(study.constraints, grid)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("row", "column", "x", "y", "state", "grid_included", "analytic_included"))
        for row, y in enumerate(grid.y):
            for column, x in enumerate(grid.x):
                state = Membership(grid.states[row, column])
                writer.writerow((row, column, x, y, state.name.lower(),
                                 int(state.included), int(analytic[row, column])))


def plot_study(study: Study, grid: GridSample, rows: Sequence[ResolutionResult]) -> "Figure":
    """Draw smooth analytic geometry, the rasterized approximation, and its error."""
    from matplotlib import pyplot as plt
    from matplotlib.colors import ListedColormap
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path as PlotPath

    teal = "#12635c"
    open_color = "#a94928"
    fill = "#b9ded3"
    reference = "#283e56"

    fig = plt.figure(figsize=(10.4, 7.2), layout="constrained")
    layout = fig.add_gridspec(2, 2, height_ratios=(1.75, 1))
    left, right = fig.add_subplot(layout[0, 0]), fig.add_subplot(layout[0, 1])
    errors = fig.add_subplot(layout[1, :])

    angle = degrees(acos(study.cut / study.radius))
    arc = PlotPath.arc(angle, 360 - angle)
    arc_vertices = arc.vertices * study.radius
    arc_path = PlotPath(arc_vertices, arc.codes)
    area_path = PlotPath(
        np.vstack((arc_vertices, arc_vertices[0])),
        np.append(arc.codes, PlotPath.CLOSEPOLY),
    )
    cut_height = sqrt(study.radius**2 - study.cut**2)
    left.add_patch(PathPatch(area_path, facecolor=fill, edgecolor="none"))
    right.pcolormesh(
        grid.x_edges, grid.y_edges, grid.feasible.astype(int), shading="flat",
        cmap=ListedColormap(["#ffffff", fill]), vmin=0, vmax=1, rasterized=False,
    )
    for axes in (left, right):
        axes.add_patch(PathPatch(
            arc_path, facecolor="none", edgecolor=teal, linewidth=1.25, label="Closed circle",
        ))
        axes.plot(
            [study.cut, study.cut], [-cut_height, cut_height], color=open_color,
            linewidth=1.4, linestyle=(0, (4, 3)), label="Open cut",
        )
        axes.scatter([study.cut, study.cut], [-cut_height, cut_height],
                     s=24, facecolor="white", edgecolor=open_color, linewidth=1, zorder=4)
        b = study.bounds
        axes.set(xlim=(b.xmin, b.xmax), ylim=(b.ymin, b.ymax), xlabel="x", ylabel="y")
        axes.set_xticks([-5, 0, 5])
        axes.set_yticks([-5, 0, 5])
        axes.set_aspect("equal")
        axes.spines[["top", "right"]].set_visible(False)
        axes.grid(alpha=0.15, zorder=0)
    left.set_title("Analytic intersection", loc="left", fontweight="bold")
    right.set_title(f"Grid estimate, {len(grid.x)} × {len(grid.y)}", loc="left", fontweight="bold")
    left.legend(loc="upper left", frameon=False, fontsize=8)

    n_values = sorted({row.resolution for row in rows})
    by_n = {n: [row for row in rows if row.resolution == n] for n in n_values}
    lows = [min(row.relative_error_percent for row in by_n[n]) for n in n_values]
    highs = [max(row.relative_error_percent for row in by_n[n]) for n in n_values]
    errors.fill_between(n_values, lows, highs, color="#dbe5ef", label="Range across sample offsets")
    offsets = [row for row in rows if (row.phase_x, row.phase_y) != (0.5, 0.5)]
    errors.scatter([row.resolution for row in offsets], [row.relative_error_percent for row in offsets],
                   color="#66819f", alpha=0.8, s=15, label="Offset samples")
    centers = [row for row in rows if (row.phase_x, row.phase_y) == (0.5, 0.5)]
    errors.plot([row.resolution for row in centers], [row.relative_error_percent for row in centers],
                marker="o", markersize=4, color=reference, linewidth=1.4, label="Cell centers")
    errors.axhline(0, color="#68717b", linewidth=0.85)
    errors.set_xscale("log", base=2)
    errors.set_xticks(n_values, labels=[str(n) for n in n_values])
    errors.set(
        xlabel="Cells per axis (log scale)", ylabel="Signed area error (%)",
        xlim=(n_values[0] * 0.90, n_values[-1] * 1.11),
    )
    errors.set_title("Area error across grid resolutions", loc="left", fontweight="bold")
    errors.spines[["top", "right"]].set_visible(False)
    errors.grid(axis="y", alpha=0.24)
    errors.legend(loc="upper right", fontsize=8, frameon=False)
    return fig
