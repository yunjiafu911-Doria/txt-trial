import csv

import matplotlib

from feasible_region.constraint_analysis.experiment import (
    ResolutionResult, boundary_probes, clipped_disk_study,
)
from feasible_region.constraint_analysis.reporting import plot_study, write_grid, write_rows
from feasible_region.constraint_analysis.sampling import sample_grid


def test_exports_real_csv_and_vector_comparison_figure(tmp_path):
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    study = clipped_disk_study()
    grid = sample_grid(study.constraints, study.bounds, 8)
    rows = [
        ResolutionResult(8, 0.5, 0.5, grid.area, study.exact_area, -1, 1, -1, 32, 0),
        ResolutionResult(8, 0.25, 0.25, grid.area, study.exact_area, 1, 1, 1, 32, 0),
    ]
    write_rows(rows, tmp_path / "experiment.csv")
    write_rows(boundary_probes(study), tmp_path / "boundaries.csv")
    write_grid(study, grid, tmp_path / "grid.csv")
    with (tmp_path / "grid.csv").open(newline="", encoding="utf-8") as stream:
        points = list(csv.DictReader(stream))
    assert len(points) == 64
    assert all(point["grid_included"] == point["analytic_included"] for point in points)
    figure = plot_study(study, grid, rows)
    try:
        assert len(figure.axes) == 3
        png, pdf = tmp_path / "study.png", tmp_path / "study.pdf"
        figure.savefig(png)
        figure.savefig(pdf)
        assert png.read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
        assert pdf.read_bytes().startswith(b"%PDF-")
        assert b"/Subtype /Image" not in pdf.read_bytes()
    finally:
        plt.close(figure)
