from math import nextafter, pi

import numpy as np
import pytest

from geometry import Point2D, Rectangle
from feasible_region.geometry3d import AxisAlignedBox, Point3D

from feasible_region.constraint_analysis import (
    BoxConstraint, ConstraintSet, DiskConstraint, Interval, Membership, PredicateConstraint, coordinates,
)
from feasible_region.constraint_analysis.experiment import boundary_probes, clipped_disk_study
from feasible_region.constraint_analysis.sampling import analytic_membership, sample_grid


@pytest.mark.parametrize(
    ("point", "expected"),
    [(Point2D(1, 2), (1, 2)), (Point3D(1, 2, 3), (1, 2, 3)), (np.array([1, 2]), (1, 2))],
)
def test_normalized_legacy_and_array_coordinates(point, expected):
    assert coordinates(point) == expected


@pytest.mark.parametrize("value", [(1,), (1, np.inf), (1, 1j), (True, 2), (10**400, 2)])
def test_invalid_points(value):
    with pytest.raises(ValueError):
        coordinates(value)


@pytest.mark.parametrize(
    ("interval", "state"),
    [
        (Interval(0, 1), Membership.CLOSED_BOUNDARY),
        (Interval(0, 1, lower_closed=False), Membership.OPEN_BOUNDARY),
    ],
)
def test_interval_tolerance_preserves_boundary_policy(interval, state):
    assert interval.classify(0) is state
    assert interval.classify(-1e-7, 1e-6) is state
    assert interval.classify(1e-7, 1e-6) is state
    assert interval.classify(-1e-7, 0) is Membership.OUTSIDE
    assert interval.classify(1e-7, 0) is Membership.INTERIOR


def test_intersection_of_intervals_preserves_endpoint_inclusion_and_singletons():
    assert Interval(0, 2).intersect(Interval(1, 3, False, True)) == Interval(1, 2, False, True)
    assert Interval(0, 1).intersect(Interval(1, 2)) == Interval(1, 1)
    assert Interval(0, 1, upper_closed=False).intersect(Interval(1, 2)) is None
    assert Interval(2, 3).intersect(Interval(0, 1)) is None


@pytest.mark.parametrize(
    ("point", "state"),
    [
        ((0, 0), Membership.INTERIOR),
        ((-5, 0), Membership.CLOSED_BOUNDARY),
        ((3, 0), Membership.OPEN_BOUNDARY),
        ((3, 4), Membership.OPEN_BOUNDARY),
        ((0, 5), Membership.CLOSED_BOUNDARY),
        ((3, 4.1), Membership.OUTSIDE),
        ((-5.01, 0), Membership.OUTSIDE),
    ],
)
def test_synthetic_scene_active_boundaries_and_boolean_acceptance(point, state):
    constraints = clipped_disk_study().constraints
    assert constraints.classify(point) is state
    assert constraints.contains(point) == (state in (Membership.INTERIOR, Membership.CLOSED_BOUNDARY))


def test_closed_tangent_has_singleton_section_and_open_disk_excludes_it():
    closed = ConstraintSet((DiskConstraint((1, 2), 3),))
    opened = ConstraintSet((DiskConstraint((1, 2), 3, closed=False),))
    assert closed.horizontal_section(5) == Interval(1, 1)
    assert closed.classify((1, 5)) is Membership.CLOSED_BOUNDARY
    assert opened.horizontal_section(5) is None
    assert opened.classify((1, 5)) is Membership.OPEN_BOUNDARY


def test_nextafter_distinguishes_sides_of_nominal_open_boundary():
    constraints = clipped_disk_study().constraints
    assert constraints.classify((nextafter(3.0, 0), 0)) is Membership.INTERIOR
    assert constraints.classify((3, 0)) is Membership.OPEN_BOUNDARY
    assert constraints.classify((nextafter(3.0, 4), 0)) is Membership.OUTSIDE


def test_3d_point_interface_and_mixed_boolean_predicates():
    box = AxisAlignedBox(Point3D(0, 0, 0), Point3D(4, 4, 4))
    first = BoxConstraint.from_box(box)
    second = PredicateConstraint(3, lambda p, tol: np.bool_(p[2] >= 1 - tol))
    constraints = ConstraintSet((first, second))
    assert constraints.contains(Point3D(2, 2, 2))
    assert constraints.classify(Point3D(0, 2, 2)) is Membership.CLOSED_BOUNDARY
    assert constraints.classify(Point3D(2, 2, 0)) is Membership.OUTSIDE
    assert not ConstraintSet((BoxConstraint.from_box(box, closed=False),)).contains((0, 2, 2))
    with pytest.raises(ValueError, match="2D"):
        constraints.horizontal_section(1)
    with pytest.raises(ValueError, match="dimension"):
        constraints.classify(Point2D(1, 2))


def test_custom_predicate_can_report_a_boundary_without_claiming_a_slice():
    custom = PredicateConstraint(2, lambda point, tol: Membership.OPEN_BOUNDARY)
    constraints = ConstraintSet((custom,))
    assert not constraints.contains((2, 3))
    with pytest.raises(NotImplementedError, match="analytic horizontal slice"):
        constraints.horizontal_section(1)
    with pytest.raises(TypeError, match="bool or Membership"):
        ConstraintSet((PredicateConstraint(2, lambda p, tol: 2),)).contains((0, 0))


def test_constraint_dimensions_must_match():
    with pytest.raises(ValueError, match="same"):
        ConstraintSet((DiskConstraint((0, 0), 1), PredicateConstraint(3, lambda p, tol: True)))
    with pytest.raises(ValueError, match="at least one"):
        ConstraintSet(())
    with pytest.raises(ValueError, match="nonnegative"):
        clipped_disk_study().constraints.contains((0, 0), tolerance=-0.1)


@pytest.mark.parametrize("n, phase", [(8, (0.5, 0.5)), (23, (0.25, 0.75)), (48, (0.75, 0.25))])
def test_grid_matches_nominal_cross_sections_at_all_sample_points(n, phase):
    study = clipped_disk_study()
    grid = sample_grid(study.constraints, study.bounds, n, phase=phase)
    np.testing.assert_array_equal(grid.feasible, analytic_membership(study.constraints, grid))
    assert grid.states.shape == (n, n)
    assert 0 < grid.area < 13**2


def test_grid_accounts_for_closed_tangent_at_exact_sample_coordinate():
    bounds = Rectangle(-0.5, -0.25, 1.5, 1.75)
    closed = ConstraintSet((DiskConstraint((0, 0), 0.5),))
    opened = ConstraintSet((DiskConstraint((0, 0), 0.5, closed=False),))
    for constraints, expected in ((closed, True), (opened, False)):
        grid = sample_grid(constraints, bounds, 2, phase=(0.5, 0.75))
        assert (grid.x[0], grid.y[0]) == (0, 0.5)
        np.testing.assert_array_equal(grid.feasible, analytic_membership(constraints, grid))
        assert grid.feasible[0, 0] == expected


def test_continuous_area_and_boundary_probe_rows():
    study = clipped_disk_study()
    y = np.linspace(-study.radius, study.radius, 4001)
    widths = []
    for height in y:
        section = study.constraints.horizontal_section(height)
        widths.append(0 if section is None else section.upper - section.lower)
    width = np.asarray(widths)
    integrated = np.dot((width[1:] + width[:-1]) / 2, np.diff(y))
    assert integrated == pytest.approx(study.exact_area, abs=0.002)
    assert pi * study.radius ** 2 / 2 < study.exact_area < pi * study.radius ** 2
    probes = boundary_probes(study)
    assert len(probes) == 45
    exact = {(r.reference, r.tolerance): r for r in probes if r.perturbation_x == 0}
    assert exact[("joint_contact", 0.0)].disk_state == "closed_boundary"
    assert exact[("joint_contact", 0.0)].box_state == "open_boundary"
    for tolerance in (0.0, 1e-9, 1e-6):
        assert exact[("closed_arc", tolerance)].feasible
        assert not exact[("open_cut", tolerance)].feasible
        assert not exact[("joint_contact", tolerance)].feasible


@pytest.mark.parametrize("n", [0, True, 1.5])
def test_resolution_validation(n):
    study = clipped_disk_study()
    with pytest.raises(ValueError, match="resolution"):
        sample_grid(study.constraints, study.bounds, n)


def test_phase_and_coordinate_precision_validation():
    study = clipped_disk_study()
    with pytest.raises(ValueError, match="phase"):
        sample_grid(study.constraints, study.bounds, 8, phase=(0, 0.5))
    offset = 1e16
    with pytest.raises(ValueError, match="coordinate precision"):
        sample_grid(study.constraints, Rectangle(offset, offset, offset + 8, offset + 8), 8)
