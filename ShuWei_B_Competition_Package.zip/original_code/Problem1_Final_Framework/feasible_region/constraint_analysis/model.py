"""Common point interface and boundary-aware conjunctions in two or three dimensions."""

from collections.abc import Callable, Iterable
from dataclasses import dataclass, field
from enum import IntEnum
from fractions import Fraction
from math import hypot, isfinite, sqrt, ulp
from numbers import Real
from typing import Protocol

from numpy import bool_

from geometry import Point2D, Rectangle
from feasible_region.geometry3d import AxisAlignedBox, Point3D

from .._float_chord import inward_endpoint

Coordinates = tuple[float, ...]
PointLike = Point2D | Point3D | Iterable[float]


class Membership(IntEnum):
    OUTSIDE = 0
    OPEN_BOUNDARY = 1
    CLOSED_BOUNDARY = 2
    INTERIOR = 3

    @property
    def included(self) -> bool:
        return self >= Membership.CLOSED_BOUNDARY


def _finite(value: float, name: str) -> float:
    if isinstance(value, (bool, bool_)) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite real number.")
    try:
        converted = float(value)
    except OverflowError as error:
        raise ValueError(f"{name} must be representable as a finite float.") from error
    if not isfinite(converted):
        raise ValueError(f"{name} must be a finite real number.")
    return converted


def _tolerance(value: float) -> float:
    value = _finite(value, "tolerance")
    if value < 0:
        raise ValueError("tolerance must be nonnegative.")
    return value


def coordinates(point: PointLike) -> Coordinates:
    """Read a legacy two- or three-dimensional point or a coordinate iterable."""
    if isinstance(point, Point2D):
        values = (point.x, point.y)
    elif isinstance(point, Point3D):
        values = point.coordinates
    else:
        values = tuple(point)
    if len(values) not in (2, 3):
        raise ValueError("points must have two or three coordinates.")
    return tuple(_finite(value, "coordinate") for value in values)


def _boundary(closed: bool) -> Membership:
    return Membership.CLOSED_BOUNDARY if closed else Membership.OPEN_BOUNDARY


@dataclass(frozen=True, slots=True)
class Interval:
    lower: float
    upper: float
    lower_closed: bool = True
    upper_closed: bool = True

    def __post_init__(self) -> None:
        lower, upper = _finite(self.lower, "lower"), _finite(self.upper, "upper")
        if lower > upper or (lower == upper and not (self.lower_closed and self.upper_closed)):
            raise ValueError("interval must be nonempty.")
        object.__setattr__(self, "lower", lower)
        object.__setattr__(self, "upper", upper)

    def classify(self, value: float, tolerance: float = 0.0) -> Membership:
        value = _finite(value, "value")
        return self._classify(value, _tolerance(tolerance))

    def _classify(self, value: float, tolerance: float) -> Membership:
        if value < self.lower - tolerance or value > self.upper + tolerance:
            return Membership.OUTSIDE
        lower = _boundary(self.lower_closed) if value <= self.lower + tolerance else Membership.INTERIOR
        upper = _boundary(self.upper_closed) if value >= self.upper - tolerance else Membership.INTERIOR
        return min(lower, upper)

    def contains(self, value: float) -> bool:
        return self.classify(value).included

    def intersect(self, other: "Interval") -> "Interval | None":
        lower, upper = max(self.lower, other.lower), min(self.upper, other.upper)
        if lower > upper:
            return None
        lower_closed = self.contains(lower) and other.contains(lower)
        upper_closed = self.contains(upper) and other.contains(upper)
        if lower == upper and not (lower_closed and upper_closed):
            return None
        return Interval(lower, upper, lower_closed, upper_closed)


class Constraint(Protocol):
    dimension: int

    def classify(self, point: Coordinates, tolerance: float) -> Membership: ...


@dataclass(frozen=True, slots=True)
class BoxConstraint:
    axes: tuple[Interval, ...]

    def __post_init__(self) -> None:
        axes = tuple(self.axes)
        if len(axes) not in (2, 3):
            raise ValueError("box must have two or three axes.")
        object.__setattr__(self, "axes", axes)

    @property
    def dimension(self) -> int:
        return len(self.axes)

    @classmethod
    def from_rectangle(cls, rectangle: Rectangle, *, closed: bool = True) -> "BoxConstraint":
        return cls((
            Interval(rectangle.xmin, rectangle.xmax, closed, closed),
            Interval(rectangle.ymin, rectangle.ymax, closed, closed),
        ))

    @classmethod
    def from_box(cls, box: AxisAlignedBox, *, closed: bool = True) -> "BoxConstraint":
        return cls(tuple(
            Interval(lower, upper, closed, closed)
            for lower, upper in zip(box.minimum.coordinates, box.maximum.coordinates)
        ))

    def classify(self, point: Coordinates, tolerance: float) -> Membership:
        if len(point) != self.dimension:
            raise ValueError("point dimension must match the box.")
        return min(axis._classify(value, tolerance) for axis, value in zip(self.axes, point))

    def horizontal_slice(self, y: float) -> Interval | None:
        x_axis, y_axis = self.axes
        return x_axis if y_axis.contains(y) else None


@dataclass(frozen=True, slots=True)
class DiskConstraint:
    center: PointLike
    radius: float
    closed: bool = True
    dimension: int = field(default=2, init=False)

    def __post_init__(self) -> None:
        center = coordinates(self.center)
        radius = _finite(self.radius, "radius")
        if len(center) != self.dimension or radius <= 0:
            raise ValueError("disk requires a 2D center and positive radius.")
        object.__setattr__(self, "center", center)
        object.__setattr__(self, "radius", radius)

    def _span(self, y: float, radius: float) -> tuple[float, float] | None:
        if radius <= 0:
            return None
        if not isfinite(radius):
            raise ValueError("offset disk radius must be finite.")
        cx, cy = self.center
        lower, upper = cy - radius, cy + radius
        if y < lower or y > upper:
            return None
        if y == lower or y == upper:
            return cx, cx
        gap = min(abs(y - cy), radius)
        if gap == 0:
            extent = radius
        else:
            product = (radius - gap) * (radius + gap)
            # Use the direct circle formula when its product is representable.
            if 0 < product and isfinite(product):
                extent = sqrt(product)
            else:
                extent = radius * sqrt(((radius - gap) / radius) * (1 + gap / radius))
        return cx - extent, cx + extent

    def _compare_radius(self, point: Coordinates, offset: float) -> int:
        """Compare with the circle, resolving near ties on the binary inputs."""
        radius = self.radius + offset
        if not isfinite(radius):
            raise ValueError("offset disk radius must be finite.")
        x, y = point
        cx, cy = self.center
        distance = hypot(x - cx, y - cy)
        if not isfinite(distance):
            return 1
        if abs(distance - radius) > 8 * ulp(max(distance, radius)):
            return 1 if distance > radius else -1

        dx = Fraction(x) - Fraction(cx)
        dy = Fraction(y) - Fraction(cy)
        difference = dx * dx + dy * dy - (Fraction(self.radius) + Fraction(offset)) ** 2
        return (difference > 0) - (difference < 0)

    def classify(self, point: Coordinates, tolerance: float) -> Membership:
        outer = self._compare_radius(point, tolerance)
        if outer > 0:
            return Membership.OUTSIDE
        if tolerance < self.radius:
            inner = outer if tolerance == 0 else self._compare_radius(point, -tolerance)
            if inner < 0:
                return Membership.INTERIOR
        return _boundary(self.closed)

    def horizontal_slice(self, y: float) -> Interval | None:
        # Endpoint flags encode membership over finite float coordinates.
        # A rounded endpoint inside the disk belongs even when the true rim is open.
        cx, cy = self.center
        width_squared = Fraction(self.radius)**2 - (Fraction(float(y)) - Fraction(cy))**2
        if width_squared < 0 or (width_squared == 0 and not self.closed):
            return None
        span = self._span(y, self.radius) or (cx, cx)
        left, left_exact = inward_endpoint(cx, span[0], width_squared, -1)
        right, right_exact = inward_endpoint(cx, span[1], width_squared, 1)
        return Interval(left, right, self.closed or not left_exact, self.closed or not right_exact)


@dataclass(frozen=True, slots=True)
class PredicateConstraint:
    """Wrap a Boolean predicate or a boundary-aware classifier on normalized coordinates."""

    dimension: int
    predicate: Callable[[Coordinates, float], bool | Membership]

    def __post_init__(self) -> None:
        if self.dimension not in (2, 3):
            raise ValueError("predicate dimension must be 2 or 3.")

    def classify(self, point: Coordinates, tolerance: float) -> Membership:
        result = self.predicate(point, tolerance)
        if isinstance(result, Membership):
            return result
        if isinstance(result, (bool, bool_)):
            return Membership.INTERIOR if result else Membership.OUTSIDE
        raise TypeError("predicate must return bool or Membership.")


@dataclass(frozen=True, slots=True)
class ConstraintSet:
    constraints: tuple[Constraint, ...]
    dimension: int = field(init=False)

    def __post_init__(self) -> None:
        constraints = tuple(self.constraints)
        if not constraints:
            raise ValueError("provide at least one constraint.")
        dimension = constraints[0].dimension
        if dimension not in (2, 3) or any(c.dimension != dimension for c in constraints):
            raise ValueError("all constraints must use the same 2D or 3D dimension.")
        object.__setattr__(self, "constraints", constraints)
        object.__setattr__(self, "dimension", dimension)

    def _classify_coordinates(self, point: Coordinates, tolerance: float) -> Membership:
        state = Membership.INTERIOR
        for constraint in self.constraints:
            outcome = constraint.classify(point, tolerance)
            if not isinstance(outcome, Membership):
                raise TypeError("constraint classifier must return Membership.")
            state = min(state, outcome)
            if state is Membership.OUTSIDE:
                break
        return state

    def classify(self, point: PointLike, *, tolerance: float = 0.0) -> Membership:
        values = coordinates(point)
        if len(values) != self.dimension:
            raise ValueError("point dimension must match the constraint set.")
        return self._classify_coordinates(values, _tolerance(tolerance))

    def contains(self, point: PointLike, *, tolerance: float = 0.0) -> bool:
        return self.classify(point, tolerance=tolerance).included

    def horizontal_section(self, y: float) -> Interval | None:
        """Intersect nominal (zero-tolerance) horizontal slices of supported constraints."""
        if self.dimension != 2:
            raise ValueError("horizontal sections require a 2D constraint set.")
        y = _finite(y, "section height")
        slices = tuple(getattr(constraint, "horizontal_slice", None) for constraint in self.constraints)
        if any(not callable(make_slice) for make_slice in slices):
            raise NotImplementedError("every constraint must provide an analytic horizontal slice.")
        result = slices[0](y)
        for make_slice in slices[1:]:
            if result is None:
                return None
            section = make_slice(y)
            if section is None:
                return None
            result = result.intersect(section)
        return result
