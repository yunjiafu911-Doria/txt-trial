"""A reproducible clipped-disk benchmark and boundary probes."""

from dataclasses import dataclass
from math import asin, pi, sqrt

import numpy as np

from geometry import Point2D, Rectangle

from .model import BoxConstraint, ConstraintSet, DiskConstraint
from .sampling import GridSample, analytic_membership, sample_grid


RESOLUTIONS = (16, 24, 32, 48, 64, 96, 128, 192, 256)
PHASES = ((0.5, 0.5), (0.25, 0.25), (0.25, 0.75), (0.75, 0.25), (0.75, 0.75))


@dataclass(frozen=True, slots=True)
class Study:
    constraints: ConstraintSet
    bounds: Rectangle
    radius: float
    cut: float

    @property
    def exact_area(self) -> float:
        r, a = self.radius, self.cut
        return a * sqrt(r * r - a * a) + r * r * (asin(a / r) + pi / 2)


@dataclass(frozen=True, slots=True)
class ResolutionResult:
    resolution: int
    phase_x: float
    phase_y: float
    area: float
    exact_area: float
    signed_error: float
    absolute_error: float
    relative_error_percent: float
    included_samples: int
    sample_disagreements: int


@dataclass(frozen=True, slots=True)
class BoundaryProbe:
    reference: str
    perturbation_x: float
    tolerance: float
    x: float
    y: float
    disk_state: str
    box_state: str
    intersection_state: str
    feasible: bool


def clipped_disk_study() -> Study:
    radius, cut = 5.0, 3.0
    bounds = Rectangle(-6.5, -6.5, 6.5, 6.5)
    disk = DiskConstraint(Point2D(0, 0), radius)
    box = BoxConstraint.from_rectangle(
        Rectangle(bounds.xmin, bounds.ymin, cut, bounds.ymax), closed=False
    )
    return Study(ConstraintSet((disk, box)), bounds, radius, cut)


def run_resolution_study(study: Study) -> tuple[list[ResolutionResult], GridSample]:
    rows = []
    pictured_grid = None
    exact_area = study.exact_area
    for resolution in RESOLUTIONS:
        for phase_x, phase_y in PHASES:
            grid = sample_grid(study.constraints, study.bounds, resolution, phase=(phase_x, phase_y))
            analytic = analytic_membership(study.constraints, grid)
            area = grid.area
            error = area - exact_area
            rows.append(ResolutionResult(
                resolution, phase_x, phase_y, area, exact_area, error, abs(error),
                100 * error / exact_area, int(np.count_nonzero(grid.feasible)),
                int(np.count_nonzero(grid.feasible != analytic)),
            ))
            if resolution == 48 and (phase_x, phase_y) == PHASES[0]:
                pictured_grid = grid
    assert pictured_grid is not None
    return rows, pictured_grid


def boundary_probes(study: Study) -> list[BoundaryProbe]:
    disk, box = study.constraints.constraints
    joint_y = sqrt(study.radius**2 - study.cut**2)
    locations = (
        ("open_cut", study.cut, 0.0),
        ("closed_arc", -study.radius, 0.0),
        ("joint_contact", study.cut, joint_y),
    )
    rows = []
    for reference, anchor_x, y in locations:
        for tolerance in (0.0, 1e-9, 1e-6):
            for perturbation in (-1e-7, -1e-11, 0.0, 1e-11, 1e-7):
                point = (anchor_x + perturbation, y)
                state = study.constraints.classify(point, tolerance=tolerance)
                rows.append(BoundaryProbe(
                    reference, perturbation, tolerance, *point,
                    disk.classify(point, tolerance).name.lower(),
                    box.classify(point, tolerance).name.lower(),
                    state.name.lower(), state.included,
                ))
    return rows
