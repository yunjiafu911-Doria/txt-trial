"""Export a reproducible grid resolution and boundary treatment experiment."""

import argparse
from pathlib import Path

from .experiment import boundary_probes, clipped_disk_study, run_resolution_study
from .reporting import plot_study, write_grid, write_rows


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("constraint_analysis_output"))
    args = parser.parse_args()

    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    study = clipped_disk_study()
    rows, grid = run_resolution_study(study)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_rows(rows, args.output_dir / "resolution_experiment.csv")
    write_rows(boundary_probes(study), args.output_dir / "boundary_probes.csv")
    write_grid(study, grid, args.output_dir / "grid_comparison.csv")

    with matplotlib.rc_context({"pdf.fonttype": 42, "savefig.facecolor": "white"}):
        figure = plot_study(study, grid, rows)
        figure.savefig(args.output_dir / "constraint_comparison.png", dpi=350)
        figure.savefig(args.output_dir / "constraint_comparison.pdf")
        plt.close(figure)

    print(f"Analytic area: {study.exact_area:.10f}")
    print(f"Grid runs: {len(rows)}; pointwise disagreements: {sum(r.sample_disagreements for r in rows)}")
    print(f"Results: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
