"""Approximate a center-feasible set by classifying rectangular grid cells."""

from dataclasses import dataclass
from operator import index

import numpy as np
from numpy.typing import NDArray

from .model import CenterState, FeasibleRegion


@dataclass(frozen=True, slots=True)
class GridSample:
    x_edges: NDArray[np.float64]
    y_edges: NDArray[np.float64]
    states: NDArray[np.uint8]

    @property
    def x_centers(self) -> NDArray[np.float64]:
        return _midpoints(self.x_edges)

    @property
    def y_centers(self) -> NDArray[np.float64]:
        return _midpoints(self.y_edges)

    @property
    def estimated_free_area(self) -> float:
        area_per_cell = np.diff(self.y_edges)[:, None] * np.diff(self.x_edges)[None, :]
        return float(area_per_cell[self.states == CenterState.FREE].sum())


def _midpoints(edges: NDArray[np.float64]) -> NDArray[np.float64]:
    return edges[:-1] * 0.5 + edges[1:] * 0.5


def _cell_count(value: int, name: str) -> int:
    if isinstance(value, (bool, np.bool_)):
        raise ValueError(f"{name} must be a positive integer.")
    try:
        cells = index(value)
    except TypeError as error:
        raise ValueError(f"{name} must be a positive integer.") from error
    if cells < 1:
        raise ValueError(f"{name} must be a positive integer.")
    return cells


def _axis_edges(start: float, stop: float, cells: int, name: str) -> NDArray[np.float64]:
    with np.errstate(over="ignore", invalid="ignore"):
        edges = np.linspace(start, stop, _cell_count(cells, name) + 1)
        centers = _midpoints(edges)
    if not np.all(np.isfinite(edges)) or not np.all((edges[:-1] < centers) & (centers < edges[1:])):
        raise ValueError(f"{name} is too fine for the coordinate precision; use fewer cells or rescale.")
    return edges


def sample_grid(region: FeasibleRegion, nx: int, ny: int) -> GridSample:
    """Label each cell by its center; state rows are indexed by increasing y."""
    bounds = region.workspace.bounds
    x_edges = _axis_edges(bounds.xmin, bounds.xmax, nx, "nx")
    y_edges = _axis_edges(bounds.ymin, bounds.ymax, ny, "ny")
    states = region.classify_points(_midpoints(x_edges)[None, :], _midpoints(y_edges)[:, None])
    return GridSample(x_edges, y_edges, states)
