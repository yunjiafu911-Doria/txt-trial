"""Render a reproducible synthetic center-feasibility example."""

import argparse
from pathlib import Path

import numpy as np

from .model import Disk, FeasibleRegion, Rectangle, Workspace
from .reporting import plot_comparison, write_grid_csv, write_sections_csv
from .sampling import sample_grid


def generate_workspace(seed: int) -> Workspace:
    """Place randomly sized rectangles in five of six synthetic layout cells."""
    rng = np.random.default_rng(seed)
    bounds = Rectangle(0, 0, 24, 16)
    slot_size = 8
    obstacles = []
    for slot in rng.choice(6, size=5, replace=False):
        row, column = divmod(int(slot), 3)
        width, height = rng.uniform(3.3, 5.7), rng.uniform(2.4, 4.8)
        x = float(column * slot_size + rng.uniform(0.65, slot_size - width - 0.65))
        y = float(row * slot_size + rng.uniform(0.65, slot_size - height - 0.65))
        obstacles.append(Rectangle(x, y, x + float(width), y + float(height)))
    return Workspace(bounds, tuple(obstacles))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--radius", type=float, default=1.15)
    parser.add_argument("--tolerance", type=float, default=1e-9)
    parser.add_argument("--nx", type=int, default=64)
    parser.add_argument("--ny", type=int, default=44)
    parser.add_argument("--dpi", type=int, default=320)
    parser.add_argument("--output-dir", type=Path, default=Path("feasible_region_output"))
    args = parser.parse_args()
    if args.dpi < 1:
        parser.error("--dpi must be positive")

    region = FeasibleRegion(generate_workspace(args.seed), Disk(args.radius), args.tolerance)
    grid = sample_grid(region, args.nx, args.ny)

    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_grid_csv(grid, args.output_dir / "grid_samples.csv")
    write_sections_csv(region, grid.y_centers, args.output_dir / "analytic_sections.csv")
    figure = plot_comparison(region, grid)
    figure.savefig(args.output_dir / "feasible_region.png", dpi=args.dpi)
    with matplotlib.rc_context({"pdf.fonttype": 42}):
        figure.savefig(args.output_dir / "feasible_region.pdf")
    plt.close(figure)
    print(f"Grid-estimated feasible area: {grid.estimated_free_area:.4f} square units")
    print(f"Artifacts: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
