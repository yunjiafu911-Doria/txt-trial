"""Synthetic optimization benchmarks and independent rational constraint oracles."""

from collections.abc import Callable
from dataclasses import dataclass
from fractions import Fraction
from math import hypot, sin

from geometry import Point2D, Rectangle

from ..constraint_analysis import BoxConstraint, ConstraintSet, DiskConstraint, Interval, Membership
from .model import Constraint, Objective, ReferenceBound


@dataclass(frozen=True, slots=True)
class Rule:
    constraint: Constraint
    margin: Callable[[Fraction, Fraction], Fraction]
    definition: str
    strict: bool = False
    boundary_metadata: bool = True

    def independent_check(self, point: Point2D) -> tuple[Membership, Fraction]:
        margin = self.margin(Fraction(point.x), Fraction(point.y))
        if margin < 0:
            state = Membership.OUTSIDE
        elif margin > 0:
            state = Membership.INTERIOR
        else:
            state = Membership.OPEN_BOUNDARY if self.strict else Membership.CLOSED_BOUNDARY
        return state, margin


@dataclass(frozen=True, slots=True)
class Benchmark:
    name: str
    bounds: Rectangle
    objective: Objective
    rules: tuple[Rule, ...]
    starts: tuple[Point2D, ...]
    proof: str
    reference: ReferenceBound | None = None

    @property
    def constraints(self) -> tuple[Constraint, ...]:
        return tuple(rule.constraint for rule in self.rules)


def benchmarks() -> tuple[Benchmark, ...]:
    wide = Rectangle(-1.25, -1.25, 1.25, 1.25)
    unit = Rectangle(-1, -1, 1, 1)
    disk = ConstraintSet((DiskConstraint((0, 0), 1),))
    closed = Benchmark(
        "closed_disk_projection", wide, lambda p: (2 - p.x)**2 + p.y**2,
        (
            Rule(Constraint("unit_disk", predicate=disk.classify, residual=lambda p: 1 - hypot(p.x, p.y)),
                 lambda x, y: 1 - x*x - y*y, "1-x^2-y^2"),
            Rule(Constraint("floor", residual=lambda p: p.y + 0.5),
                 lambda x, y: y + Fraction(1, 2), "y+1/2"),
        ),
        (Point2D(-0.75, 0), Point2D(0.25, 0.625), Point2D(0.5, -0.25)),
        "单位闭圆盘内有 x ≤ 1，因此 (2−x)²+y² ≥ 1。点 (1,0) 满足全部约束且取等。",
        ReferenceBound(1, (Point2D(1, 0),)),
    )
    opened = Benchmark(
        "strict_open_edge", wide, lambda p: p.x + (p.y - 0.125)**2,
        (
            Rule(Constraint("x_positive", residual=lambda p: p.x, strict=True), lambda x, y: x, "x", strict=True),
            Rule(Constraint("x_cap", residual=lambda p: 1 - p.x), lambda x, y: 1 - x, "1-x"),
            Rule(Constraint("vertical_band", predicate=lambda p: abs(p.y) <= 0.75),
                 lambda x, y: Fraction(3, 4) - abs(y), "3/4-|y|", boundary_metadata=False),
        ),
        (Point2D(0.25, -0.5), Point2D(0.75, 0.5), Point2D(0.5, 0)),
        "在闭包上目标下界为 0，唯一等值点 (0,1/8) 被 x>0 排除。沿 (t/2,1/8) 逼近时目标值为 t/2。",
        ReferenceBound(0, (Point2D(0, 0.125),), limit=Point2D(0, 0.125), approach=lambda t: Point2D(t / 2, 0.125)),
    )
    height = 0.1875
    closed_line = ConstraintSet((BoxConstraint((Interval(-0.75, 0.75), Interval(height, height))),))
    line = Benchmark(
        "zero_width_feasible_set", unit, lambda p: (p.x - 0.375)**2 + (p.y - 0.5)**2,
        (
            Rule(Constraint("closed_line", predicate=closed_line.classify),
                 lambda x, y: min(Fraction(3, 4) - abs(x), -abs(y - Fraction(3, 16))),
                 "min(3/4-|x|,-|y-3/16|)"),
        ),
        (Point2D(-0.625, height), Point2D(0, height), Point2D(0.625, height)),
        "闭可行集固定 y=3/16，目标下界为 (3/16−1/2)²=25/256。唯一取等点 (3/8,3/16) 可行。",
        ReferenceBound(25 / 256, (Point2D(0.375, height),)),
    )
    multimodal = Benchmark(
        "disconnected_uncertified", unit,
        lambda p: (p.x**2 - 0.25)**2 + (p.y - 0.125)**2 + 0.035 * sin(19 * p.x),
        (
            Rule(Constraint("two_branches", predicate=lambda p: abs(p.x) >= 0.375),
                 lambda x, y: abs(x) - Fraction(3, 8), "|x|-3/8", boundary_metadata=False),
            Rule(Constraint("vertical_band", predicate=lambda p: abs(p.y) <= 0.75),
                 lambda x, y: Fraction(3, 4) - abs(y), "3/4-|y|", boundary_metadata=False),
        ),
        (Point2D(-0.5, 0.5), Point2D(0.5, 0.5), Point2D(0.75, -0.5)),
        "目标含振荡项且可行域有两个分支。未提供全局下界或全局证明，记录数值候选及起点差异。",
    )
    return closed, opened, line, multimodal


def box_state(bounds: Rectangle, point: Point2D) -> tuple[Membership, Fraction]:
    x, y = Fraction(point.x), Fraction(point.y)
    margin = min(x - Fraction(bounds.xmin), Fraction(bounds.xmax) - x,
                 y - Fraction(bounds.ymin), Fraction(bounds.ymax) - y)
    state = Membership.OUTSIDE if margin < 0 else Membership.CLOSED_BOUNDARY if margin == 0 else Membership.INTERIOR
    return state, margin
