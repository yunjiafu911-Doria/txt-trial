"""Bounded two-dimensional black-box minimization with explicit feasibility checks."""

from .model import Constraint, ReferenceBound, SearchOptions, SearchStatus
from .search import minimize_2d

__all__ = ["Constraint", "ReferenceBound", "SearchOptions", "SearchStatus", "minimize_2d"]
