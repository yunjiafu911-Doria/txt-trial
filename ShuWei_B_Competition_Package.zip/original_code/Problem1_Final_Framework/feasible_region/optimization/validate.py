"""Validate the existing optimizer against synthetic analytic benchmarks."""

import argparse
import csv
from fractions import Fraction
from itertools import product
from math import isfinite, nextafter
import os
from pathlib import Path
import re
import subprocess
import sys

import numpy as np

from geometry import Point2D

from ..constraint_analysis import BoxConstraint, ConstraintSet, Interval, Membership
from .model import SearchOptions, SearchStatus
from .search import minimize_2d
from .validation_cases import Benchmark, benchmarks, box_state


GRID_SIZES = (9, 17, 33, 65)
STEP_TOLERANCES = (1e-5, 1e-8)


def _independent(case, point):
    box, margin = box_state(case.bounds, point)
    records = [("search_bounds", box, margin, "minimum box slack", True)]
    for rule in case.rules:
        state, margin = rule.independent_check(point)
        records.append((rule.constraint.name, state, margin, rule.definition, rule.boundary_metadata))
    return records


def _oracle_feasible(case, point):
    return all(state.included for _, state, _, _, _ in _independent(case, point))


def _audit(case, evaluation, context, kind, identifier):
    records = _independent(case, evaluation.point)
    allowed = all(state.included for _, state, _, _, _ in records)
    if allowed != evaluation.state.included:
        raise AssertionError(f"{case.name}: independent feasibility disagrees at {evaluation.point}.")
    if allowed and evaluation.value != float(case.objective(evaluation.point)):
        raise AssertionError(f"{case.name}: saved objective disagrees at {evaluation.point}.")
    rows = []
    for check, (name, state, margin, definition, full_state) in zip(evaluation.checks, records, strict=True):
        if check.name != name or check.state.included != state.included or (full_state and check.state is not state):
            raise AssertionError(f"{case.name}: {name} disagrees at {evaluation.point}.")
        rows.append(_check_row(
            context, kind, identifier, evaluation.point, name, check.state, state, check.residual,
            margin, definition, 0.0, "full_state_match" if full_state else "boolean_match",
        ))
    return rows


def _check_row(context, kind, identifier, point, name, solver, oracle,
               solver_residual, margin, definition, constraint_tolerance, outcome):
    return {
        **context, "point_type": kind, "point_id": identifier, "x": point.x, "y": point.y,
        "constraint": name, "constraint_tolerance": constraint_tolerance,
        "solver_state": solver.name.lower(), "oracle_state": oracle.name.lower(),
        "solver_included": int(solver.included), "oracle_included": int(oracle.included),
        "solver_residual": solver_residual, "oracle_margin": float(margin),
        "oracle_margin_definition": definition, "outcome": outcome,
    }


def _numeric_probes() -> list[dict]:
    disk_rule = benchmarks()[0].rules[0]
    rows = []
    context = {"case": "disk_boundary_probe", "grid_size": None, "step_tolerance": None}
    disk_points = (
        ("axis_contact", Point2D(1, 0)),
        ("one_ulp_inside", Point2D(nextafter(1.0, 0), 0)),
        ("one_ulp_outside", Point2D(nextafter(1.0, 2), 0)),
        ("below_float_boundary_resolution", Point2D(1, 2.0**-30)),
    )
    for name, point in disk_points:
        check = disk_rule.constraint.evaluate(point)
        expected, margin = disk_rule.independent_check(point)
        outcome = "full_state_match"
        if check.state is not expected:
            if name != "below_float_boundary_resolution" or abs(margin) >= Fraction(1, 2**52):
                raise AssertionError(f"Unexpected disk boundary difference: {point}.")
            outcome = "floating_point_resolution_limit"
        rows.append(_check_row(context, "boundary_probe", name, point, check.name, check.state, expected,
                               check.residual, margin, disk_rule.definition, 0.0, outcome))

    context = {"case": "interval_boundary_probe", "grid_size": None, "step_tolerance": None}
    epsilon = 2.0**-20
    for closed, tolerance in product((False, True), (0.0, epsilon)):
        axis = Interval(0, 1, lower_closed=closed)
        domain = ConstraintSet((BoxConstraint((axis, Interval(-1, 1))),))
        for x in (-2 * epsilon, -epsilon / 2, 0.0, epsilon / 2, epsilon, 2 * epsilon):
            point = Point2D(x, 0)
            observed = domain.classify(point, tolerance=tolerance)
            if x < -tolerance:
                expected = Membership.OUTSIDE
            elif x <= tolerance:
                expected = Membership.CLOSED_BOUNDARY if closed else Membership.OPEN_BOUNDARY
            else:
                expected = Membership.INTERIOR
            if observed is not expected:
                raise AssertionError(f"Boundary policy disagrees for x={x}, tolerance={tolerance}.")
            rows.append(_check_row(
                context, "boundary_probe", "closed" if closed else "open", point, "x_lower",
                observed, expected, x, Fraction(x), "x", tolerance, "full_state_match",
            ))
    return rows


def _reference(case: Benchmark, checks: list[dict]) -> str:
    if case.reference is None:
        return "global_not_proven"
    result = minimize_2d(case.objective, case.bounds, case.constraints,
                         options=SearchOptions(grid_size=9, starts=3, step_tolerance=1e-5),
                         initial_points=case.starts, reference=case.reference)
    expected = (SearchStatus.UNATTAINED_REFERENCE if case.reference.limit is not None
                else SearchStatus.ATTAINED_REFERENCE)
    if result.status is not expected:
        raise AssertionError(f"{case.name}: expected reference status {expected.value}, got {result.status.value}.")
    context = {"case": case.name, "grid_size": None, "step_tolerance": None}
    if result.best is None:
        raise AssertionError("A validated reference case produced no feasible observation.")
    checks.extend(_audit(case, result.best, context, "reference_best", "best"))
    if result.reference_limit is not None:
        checks.extend(_audit(case, result.reference_limit, context, "reference_limit", "excluded"))
    for sample in result.approach:
        checks.extend(_audit(case, sample.evaluation, context, "reference_approach", str(sample.t)))
    return expected.value


def run_validation(grid_sizes=GRID_SIZES, step_tolerances=STEP_TOLERANCES):
    results, convergence, checks = [], [], _numeric_probes()
    for case in benchmarks():
        reference_status = _reference(case, checks)
        reference_value = case.reference.value if case.reference is not None else None
        for n in grid_sizes:
            bounds = case.bounds
            xs = np.linspace(bounds.xmin, bounds.xmax, n).tolist()
            ys = np.linspace(bounds.ymin, bounds.ymax, n).tolist()
            points = map(lambda pair: Point2D(*pair), product(xs, ys))
            grid_values = [case.objective(point) for point in points if _oracle_feasible(case, point)]
            for step in step_tolerances:
                options = SearchOptions(grid_size=n, starts=5, step_tolerance=step)
                context = {"case": case.name, "grid_size": n, "step_tolerance": step}
                result = minimize_2d(case.objective, bounds, case.constraints,
                                     options=options, initial_points=case.starts)
                if result.feasible_samples != len(grid_values) or result.best is None:
                    raise AssertionError(f"Grid or seeded search failed for {context}.")
                grid_only_status = None
                if not grid_values:
                    grid_only = minimize_2d(case.objective, bounds, case.constraints, options=options)
                    if grid_only.status is not SearchStatus.NO_FEASIBLE_SAMPLE:
                        raise AssertionError(f"Unexpected grid-only feasibility for {context}.")
                    grid_only_status = grid_only.status.value
                checks.extend(_audit(case, result.best, context, "best_candidate", "best"))
                local_values = []
                for i, run in enumerate(result.runs, start=1):
                    source = "fixed" if run.start.point in case.starts else "grid_pool"
                    checks.extend(_audit(case, run.start, context, "start", i))
                    checks.extend(_audit(case, run.candidate, context, "local_candidate", i))
                    local_values.append(run.candidate.value)
                    previous = run.start.value
                    for item in run.trace:
                        current = item.current
                        value = current.value
                        if value is None or not isfinite(value) or value > previous or not _oracle_feasible(case, current.point):
                            raise AssertionError(f"Invalid local trace at {context}, start {i}.")
                        previous = value
                        convergence.append({
                            **context, "start_id": i, "start_source": source,
                            "start_x": run.start.point.x, "start_y": run.start.point.y,
                            "start_objective": run.start.value, "iteration": item.iteration,
                            "normalized_step": item.step, "improved": int(item.improved),
                            "x": current.point.x, "y": current.point.y, "objective": value,
                            "objective_gap": None if reference_value is None else value - reference_value,
                            "stop_reason": run.stop_reason if item.iteration == len(run.trace) else "",
                        })
                best_value = result.best.value
                if reference_value is not None and best_value < reference_value - case.reference.value_tolerance:
                    raise AssertionError(f"A search observation violated the analytic bound for {context}.")
                results.append({
                    **context, "grid_points": result.sampled, "grid_feasible": result.feasible_samples,
                    "grid_best_objective": min(grid_values, default=None), "grid_only_status_if_empty": grid_only_status,
                    "local_starts": len(result.runs), "fixed_starts": len(case.starts),
                    "evaluations": result.evaluations, "search_status": result.status.value,
                    "reference_status": reference_status, "reference_value": reference_value,
                    "best_x": result.best.point.x, "best_y": result.best.point.y,
                    "best_objective": best_value,
                    "objective_gap": None if reference_value is None else best_value - reference_value,
                    "local_endpoint_spread": max(local_values) - min(local_values),
                    "local_iterations_total": sum(len(run.trace) for run in result.runs),
                    "local_iterations_max": max(len(run.trace) for run in result.runs),
                    "step_tolerance_stops": sum(run.stop_reason == "step_tolerance" for run in result.runs),
                    "iteration_limit_stops": sum(run.stop_reason == "iteration_limit" for run in result.runs),
                    "all_accepted_candidates_independently_feasible": 1,
                })
    return results, convergence, checks


def _write_csv(path: Path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def _run_pytest():
    command = [sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider", "-ra", "-W", "error"]
    result = subprocess.run(
        command, cwd=Path(__file__).resolve().parents[2], check=False, capture_output=True, encoding="utf-8",
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, end="", file=sys.stderr)
    summary = result.stdout.strip().splitlines()[-1] if result.stdout.strip() else ""
    counts = {name: int(count) for count, name in re.findall(r"(\d+) (passed|failed|skipped|errors?)\b", summary)}
    return command, result.returncode, summary, counts


def _write_report(path, results, convergence, checks, pytest_run, invocation):
    table_rows = []
    for row in results:
        if row["step_tolerance"] != min(STEP_TOLERANCES):
            continue
        grid = "无" if row["grid_best_objective"] is None else f'{row["grid_best_objective"]:.10g}'
        gap = "无证明" if row["objective_gap"] is None else f'{row["objective_gap"]:.3g}'
        table_rows.append(f'| {row["case"]} | {row["grid_size"]} | {row["grid_feasible"]} | {grid} | '
                          f'{row["best_objective"]:.10g} | {gap} | {row["local_endpoint_spread"]:.3g} | {row["local_iterations_max"]} |')
    table = "\n".join(table_rows)
    proofs = "\n".join(f"- `{case.name}`。{case.proof}" for case in benchmarks())
    differences = [row for row in checks if row["outcome"] == "floating_point_resolution_limit"]
    precision = "\n".join(
        f'- `({r["x"]!r}, {r["y"]!r})` 的独立圆盘余量为 `{r["oracle_margin"]:.6g}`，'
        f'现有浮点切片判为 `{r["solver_state"]}`。这一探针接近双精度边界分辨能力，单独标注。'
        for r in differences
    ) or "- 精度探针与独立判定一致。"
    tests = "本次未使用 --run-tests。"
    if pytest_run is not None:
        command, exit_code, summary, counts = pytest_run
        shell = '& "' + command[0] + '" ' + subprocess.list2cmdline(command[1:])
        tests = (f"通过 **{counts.get('passed', 0)}**，失败 **{counts.get('failed', 0)}**，"
                 f"跳过 **{counts.get('skipped', 0)}**，错误 **{counts.get('error', 0) + counts.get('errors', 0)}**。"
                 f"退出码为 {exit_code}。\n\n~~~powershell\n{shell}\n~~~\n\npytest 摘要为 `{summary}`。")
    limits = sum(row["iteration_limit_stops"] for row in results)
    search_runs = sum(row["local_starts"] for row in results)
    cases_compared = sum(row["local_endpoint_spread"] > 1e-7 for row in results)
    path.write_text(f"""# 二维约束优化系统验证报告

本报告复用当前几何、综合约束与优化模块。验证涵盖 {len(results)} 组配置、{search_runs} 次局部搜索、{len(convergence)} 条迭代记录和 {len(checks)} 条约束记录。以下输出来自合成案例。

## 接口与方法

- 原目标函数使用 `Point2D → float`，约束使用布尔谓词、带边界状态的 `Membership` 或有符号残差。对搜索盒、各约束和候选值做独立复核。几何余量使用输入坐标的有理数表示计算，布尔约束的校验比较可行性。
- 以 9、17、33、65 为每轴网格数，以 `1e-5` 和 `1e-8` 为归一化步长停止阈值。每组保留三个相同的明确起点，余下名额由网格补充。分辨率比较的搜索调用没有传入解析参考点。解析参考另行核验。
- 全部保存的局部迭代状态均可行，目标值非增。{limits} 次局部搜索达到迭代上限。{cases_compared} 组配置的局部终点目标跨度大于 `1e-7`。具体起点、逐步值和停止原因见 [convergence.csv](convergence.csv)。

## 解析依据

{proofs}

## 分辨率对照

下表使用较细的步长阈值 `1e-8`。差值为搜索最佳目标减解析最小值或下确界。搜索到达很小的正残差时，严格边界上的排除点仍保留其原始状态。

| 案例 | 每轴网格数 | 网格可行点 | 网格最小目标 | 搜索最佳值 | 与解析值的差 | 局部终点目标跨度 | 单起点最大轮数 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
{table}

零宽闭可行域的粗网格只搜索时未采到可行点，传入位于该集合内的明确起点后可继续求解。网格采样的覆盖率与局部搜索停止阈值分别记录。

## 边界与容差

- 残差为零时，闭约束接受接触，严格约束排除接触。正的几何容差形成边界带，开边界拒绝带内点，闭边界接受带内点。搜索步长阈值只用于停止局部轮询。
{precision}

[验证汇总](validation_results.csv) · [逐步收敛](convergence.csv) · [约束与边界复核](constraint_checks.csv)

## 自动测试

{tests}

验证入口实际执行命令：

~~~powershell
{invocation}
~~~
""", encoding="utf-8", newline="\n")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/optimization_validation"))
    parser.add_argument("--run-tests", action="store_true", help="Run and record the complete workspace pytest suite.")
    args = parser.parse_args()
    results, convergence, checks = run_validation()
    pytest_run = _run_pytest() if args.run_tests else None
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for filename, rows in (("validation_results.csv", results), ("convergence.csv", convergence),
                           ("constraint_checks.csv", checks)):
        _write_csv(args.output_dir / filename, rows)
    invocation = '& "' + sys.executable + '" ' + subprocess.list2cmdline(
        ["-B", "-W", "error", "-m", "feasible_region.optimization.validate", *sys.argv[1:]]
    )
    _write_report(args.output_dir / "VALIDATION_REPORT.md", results, convergence, checks, pytest_run, invocation)
    print(f"Configurations: {len(results)}; convergence rows: {len(convergence)}; constraint rows: {len(checks)}.")
    print(f"Report: {(args.output_dir / 'VALIDATION_REPORT.md').resolve()}")
    return pytest_run[1] if pytest_run is not None else 0


if __name__ == "__main__":
    raise SystemExit(main())
