"""Run reproducible optimization examples and export candidates and convergence."""

import argparse
import csv
from collections import Counter
from collections.abc import Iterable
from math import hypot
from pathlib import Path

from geometry import Point2D, Rectangle

from ..constraint_analysis import ConstraintSet, DiskConstraint
from .model import Constraint, OptimizationResult, ReferenceBound, SearchOptions
from .search import minimize_2d


def synthetic_cases(options: SearchOptions) -> dict[str, OptimizationResult]:
    bounds = Rectangle(-2, -2, 2, 2)
    center = Point2D(0.375, -0.625)
    region = ConstraintSet((DiskConstraint((0, 0), 1.75),))
    disk = Constraint("disk", predicate=region.classify, residual=lambda p: 1.75 - hypot(p.x, p.y))

    def bowl(point):
        return (point.x - center.x)**2 + (point.y - center.y)**2

    def distance_squared(point):
        return point.x**2 + point.y**2

    def two_wells(point):
        return (point.x**2 - 1)**2 + (point.y - 0.2)**2 + 0.1 * point.x

    origin = Point2D(0, 0)
    return {
        "closed_bowl": minimize_2d(
            bowl, bounds, (disk,), options=options,
            reference=ReferenceBound(0, (center,)),
        ),
        "open_boundary": minimize_2d(
            distance_squared, bounds,
            (Constraint("positive_x", residual=lambda p: p.x, strict=True),),
            options=options, reference=ReferenceBound(
                0, (origin,), limit=origin, approach=lambda t: Point2D(t, 0),
            ),
        ),
        "disconnected_wells": minimize_2d(
            two_wells, bounds,
            (Constraint("separated_regions", predicate=lambda p: abs(p.x) >= 0.5),),
            options=options,
        ),
    }


def _write_csv(path: Path, header: tuple[str, ...], rows: Iterable[tuple]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def export(results: dict[str, OptimizationResult], destination: Path) -> None:
    destination.mkdir(parents=True, exist_ok=True)
    candidates, residuals, trace, approach, report = [], [], [], [], []
    for case, result in results.items():
        selected = [(f"start_{i}_result", run.candidate) for i, run in enumerate(result.runs, start=1)]
        if result.best is not None:
            selected.insert(0, ("best", result.best))
        for name, item in selected:
            candidates.append((case, name, item.point.x, item.point.y, item.value,
                               item.state.name.lower(), result.status.value))
        checked = selected.copy()
        if result.reference_limit is not None:
            checked.append(("excluded_limit", result.reference_limit))
        for name, item in checked:
            for check in item.checks:
                residuals.append((case, name, item.point.x, item.point.y, check.name,
                                  check.state.name.lower(), check.residual))
        for index, run in enumerate(result.runs, start=1):
            for step in run.trace:
                item = step.current
                trace.append((case, index, run.start.point.x, run.start.point.y, step.iteration,
                              step.step, int(step.improved), item.point.x, item.point.y, item.value,
                              run.stop_reason if step.iteration == len(run.trace) else ""))
        for item in result.approach:
            entry = item.evaluation
            approach.append((case, item.t, entry.point.x, entry.point.y, item.distance, entry.value,
                             result.reference_value, entry.value - result.reference_value))
        stopping = Counter(run.stop_reason for run in result.runs)
        summary = ", ".join(f"{reason} × {count}" for reason, count in sorted(stopping.items())) or "无"
        best_value = f"{result.best.value:.10g}" if result.best is not None else "无"
        report.append(
            f"| {case} | {result.status.value} | {best_value} | {result.feasible_samples}/{result.sampled} "
            f"| {result.evaluations} | {len(result.runs)} | {summary} |"
        )

    _write_csv(destination / "candidates.csv",
               ("case", "candidate", "x", "y", "objective", "state", "result_status"), candidates)
    _write_csv(destination / "constraint_residuals.csv",
               ("case", "sample", "x", "y", "constraint", "state", "signed_residual"), residuals)
    _write_csv(destination / "convergence.csv",
               ("case", "start_id", "start_x", "start_y", "iteration", "normalized_step", "improved",
                "x", "y", "objective", "stop_reason"), trace)
    _write_csv(destination / "reference_approach.csv",
               ("case", "t", "x", "y", "distance_to_limit", "objective", "reference_value", "objective_gap"), approach)
    rows = "\n".join(report)
    document = f"""# 合成优化案例收敛报告

| 案例 | 结果类别 | 最佳已评估可行值 | 网格可行数 / 总数 | 已判定的不同点 | 局部起点数 | 停止原因 |
| --- | --- | ---: | ---: | ---: | ---: | --- |
{rows}

## 解析依据

- `closed_bowl` 的目标是两个平方之和。唯一取等点为 `(0.375, -0.625)`，该点满足闭圆盘约束，最小值 0 可取到。
- `open_boundary` 在 `x > 0` 下最小化 `x² + y²`。唯一取等点为原点，严格约束将其排除。取 `(t, 0)` 且 `0 < t ≤ 1`，目标值为 `t²` 并趋于 0，因此下确界为 0，且不可取到。
- `disconnected_wells` 由分离的两个可行分支组成。多起点输出用于比较局部候选，结果保留为数值候选。

## 如何读取结果

`candidates.csv` 记录最佳已观察可行解及各起点的终点。`constraint_residuals.csv` 中严格边界的残差 0 对应 `open_boundary`，布尔约束缺少残差函数时该列为空。`convergence.csv` 记录每一次局部轮询的无量纲步长、目标值及停止原因。`reference_approach.csv` 保存解析路径的有限采样。参考结论依赖上面的解析依据。
"""
    (destination / "CONVERGENCE.md").write_text(document, encoding="utf-8", newline="\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/optimization"))
    parser.add_argument("--grid-size", type=int, default=17)
    parser.add_argument("--starts", type=int, default=5)
    parser.add_argument("--step-tolerance", type=float, default=1e-8)
    parser.add_argument("--max-iterations", type=int, default=160)
    args = parser.parse_args()
    options = SearchOptions(args.grid_size, args.starts, args.step_tolerance, args.max_iterations)
    results = synthetic_cases(options)
    export(results, args.output_dir)
    for name, result in results.items():
        value = result.best.value if result.best is not None else None
        print(f"{name}: {result.status.value}; best feasible observation = {value}")
    print(f"Results: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
