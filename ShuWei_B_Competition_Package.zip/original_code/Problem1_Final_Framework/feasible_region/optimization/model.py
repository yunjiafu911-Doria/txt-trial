"""Contracts and results for two-dimensional black-box optimization."""

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from math import isfinite
from numbers import Real

from numpy import bool_

from geometry import Point2D

from ..constraint_analysis import Membership


Objective = Callable[[Point2D], float]


def finite(value: float, label: str) -> float:
    if isinstance(value, (bool, bool_)) or not isinstance(value, Real):
        raise ValueError(f"{label} must be a finite real number.")
    try:
        result = float(value)
    except OverflowError as error:
        raise ValueError(f"{label} must be a finite real number.") from error
    if not isfinite(result):
        raise ValueError(f"{label} must be a finite real number.")
    return result


@dataclass(frozen=True, slots=True)
class Check:
    name: str
    state: Membership
    residual: float | None


@dataclass(frozen=True, slots=True)
class Constraint:
    """A Boolean/classified predicate, or a signed margin with a chosen boundary rule."""

    name: str
    predicate: Callable[[Point2D], bool | Membership] | None = None
    residual: Callable[[Point2D], float] | None = None
    strict: bool = False

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not self.name.strip():
            raise ValueError("Each constraint needs a nonempty name.")
        if self.predicate is None and self.residual is None:
            raise ValueError("Provide a predicate or a signed residual.")
        if self.predicate is not None and self.strict:
            raise ValueError("A custom predicate defines its own boundary policy.")

    def evaluate(self, point: Point2D) -> Check:
        margin = finite(self.residual(point), f"{self.name} residual") if self.residual is not None else None
        if self.predicate is not None:
            outcome = self.predicate(point)
            if isinstance(outcome, Membership):
                state = outcome
            elif isinstance(outcome, (bool, bool_)):
                state = Membership.INTERIOR if outcome else Membership.OUTSIDE
            else:
                raise TypeError("A predicate must return bool or Membership.")
        else:
            assert margin is not None
            if margin < 0:
                state = Membership.OUTSIDE
            elif margin > 0:
                state = Membership.INTERIOR
            else:
                state = Membership.OPEN_BOUNDARY if self.strict else Membership.CLOSED_BOUNDARY
        return Check(self.name, state, margin)


@dataclass(frozen=True, slots=True)
class SearchOptions:
    grid_size: int = 17
    starts: int = 5
    step_tolerance: float = 1e-8
    max_iterations: int = 160

    def __post_init__(self) -> None:
        for name, value, minimum in (
            ("grid_size", self.grid_size, 2), ("starts", self.starts, 1),
            ("max_iterations", self.max_iterations, 1),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
                raise ValueError(f"{name} must be an integer of at least {minimum}.")
        if not 0 < finite(self.step_tolerance, "step_tolerance") < 0.25:
            raise ValueError("step_tolerance must be strictly between 0 and 0.25.")


@dataclass(frozen=True, slots=True)
class ReferenceBound:
    """Model-supplied lower bound and all its equality points on the closure.

    For an excluded limit, approach(t) is a model-supplied feasible path for
    0 < t <= 1 tending to limit. The optimizer audits finitely many values.
    """

    value: float
    equality_points: tuple[Point2D, ...]
    limit: Point2D | None = None
    approach: Callable[[float], Point2D] | None = None
    value_tolerance: float = 1e-12

    def __post_init__(self) -> None:
        points = tuple(self.equality_points)
        if not points:
            raise ValueError("Provide the reference equality points.")
        object.__setattr__(self, "equality_points", points)
        if (self.limit is None) != (self.approach is None):
            raise ValueError("Provide the limit and approach together.")
        if self.limit is not None and self.limit not in points:
            raise ValueError("The approach limit must be a reference equality point.")
        object.__setattr__(self, "value", finite(self.value, "reference value"))
        tolerance = finite(self.value_tolerance, "value_tolerance")
        if tolerance < 0:
            raise ValueError("value_tolerance must be nonnegative.")
        object.__setattr__(self, "value_tolerance", tolerance)


class SearchStatus(str, Enum):
    NO_FEASIBLE_SAMPLE = "no_feasible_sample"
    FEASIBLE_CANDIDATE = "feasible_candidate"
    ATTAINED_REFERENCE = "attained_reference"
    UNATTAINED_REFERENCE = "unattained_reference"


@dataclass(frozen=True, slots=True)
class Evaluation:
    point: Point2D
    state: Membership
    value: float | None
    checks: tuple[Check, ...]


@dataclass(frozen=True, slots=True)
class Iteration:
    iteration: int
    step: float
    improved: bool
    current: Evaluation


@dataclass(frozen=True, slots=True)
class LocalRun:
    start: Evaluation
    candidate: Evaluation
    trace: tuple[Iteration, ...]
    stop_reason: str


@dataclass(frozen=True, slots=True)
class ApproachSample:
    t: float
    distance: float
    evaluation: Evaluation


@dataclass(frozen=True, slots=True)
class OptimizationResult:
    status: SearchStatus
    best: Evaluation | None
    runs: tuple[LocalRun, ...]
    sampled: int
    feasible_samples: int
    evaluations: int
    skipped_initial_points: int
    reference_value: float | None = None
    reference_limit: Evaluation | None = None
    approach: tuple[ApproachSample, ...] = ()
