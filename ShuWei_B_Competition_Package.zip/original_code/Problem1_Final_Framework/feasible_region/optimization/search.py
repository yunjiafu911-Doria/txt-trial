"""Deterministic grid search and derivative-free pattern refinement."""

from collections.abc import Iterable
from itertools import product
from math import hypot

from geometry import Point2D, PointLocation, Rectangle

from ..constraint_analysis import Membership
from .model import (
    ApproachSample,
    Check,
    Constraint,
    Evaluation,
    Iteration,
    LocalRun,
    Objective,
    OptimizationResult,
    ReferenceBound,
    SearchOptions,
    SearchStatus,
    finite,
)


_DIRECTIONS = tuple((x, y) for x, y in product((-1, 0, 1), repeat=2) if (x, y) != (0, 0))


class _Evaluator:
    def __init__(self, bounds: Rectangle, objective: Objective, constraints: tuple[Constraint, ...]):
        self.bounds = bounds
        self.objective = objective
        self.constraints = constraints
        self.cache: dict[Point2D, Evaluation] = {}
        self.width = finite(bounds.xmax - bounds.xmin, "x span")
        self.height = finite(bounds.ymax - bounds.ymin, "y span")

    def evaluate(self, point: Point2D) -> Evaluation:
        cached = self.cache.get(point)
        if cached is not None:
            return cached
        b = self.bounds
        margin = min(point.x - b.xmin, b.xmax - point.x, point.y - b.ymin, b.ymax - point.y)
        if margin < 0:
            result = Evaluation(point, Membership.OUTSIDE, None, (Check("search_bounds", Membership.OUTSIDE, margin),))
        else:
            edge = Membership.CLOSED_BOUNDARY if margin == 0 else Membership.INTERIOR
            checks = (Check("search_bounds", edge, margin), *(c.evaluate(point) for c in self.constraints))
            state = min(check.state for check in checks)
            value = finite(self.objective(point), "objective") if state.included else None
            result = Evaluation(point, state, value, checks)
        self.cache[point] = result
        return result


def _axis(lower: float, upper: float, n: int) -> list[float]:
    result = [lower]
    result.extend(lower + (upper - lower) * (i / (n - 1)) for i in range(1, n - 1))
    result.append(upper)
    if any(left >= right for left, right in zip(result, result[1:])):
        raise ValueError("Grid exceeds coordinate precision; lower grid_size or rescale the search box.")
    return result


def _value(item: Evaluation) -> float:
    assert item.value is not None
    return item.value


def _starts(
    evaluator: _Evaluator, samples: list[Evaluation], specified: list[Evaluation], limit: int
) -> list[Evaluation]:
    selected = list(specified)
    available = [item for item in sorted(samples, key=_value) if item not in specified]
    if not available or len(selected) == limit:
        return selected
    selected.append(available.pop(0))
    # Farthest-first in normalized box coordinates avoids clustering every start.
    while available and len(selected) < limit:
        def separation(item):
            return min(hypot(
                (item.point.x - anchor.point.x) / evaluator.width,
                (item.point.y - anchor.point.y) / evaluator.height,
            ) for anchor in selected)

        chosen = max(available, key=separation)
        available.remove(chosen)
        selected.append(chosen)
    return selected


def _refine(evaluator: _Evaluator, start: Evaluation, options: SearchOptions) -> LocalRun:
    current = start
    step = 0.25
    trace = []
    stop = "iteration_limit"
    bounds = evaluator.bounds
    for iteration in range(1, options.max_iterations + 1):
        best = current
        for dx, dy in _DIRECTIONS:
            x = min(bounds.xmax, max(bounds.xmin, current.point.x + dx * step * evaluator.width))
            y = min(bounds.ymax, max(bounds.ymin, current.point.y + dy * step * evaluator.height))
            trial = evaluator.evaluate(Point2D(x, y))
            if trial.value is not None and _value(trial) < _value(best):
                best = trial
        improved = best is not current
        current = best
        trace.append(Iteration(iteration, step, improved, current))
        if not improved:
            step *= 0.5
            if step <= options.step_tolerance:
                stop = "step_tolerance"
                break
    return LocalRun(start, current, tuple(trace), stop)


def _check_reference(
    evaluator: _Evaluator, reference: ReferenceBound,
) -> tuple[tuple[ApproachSample, ...], Evaluation | None]:
    for point in reference.equality_points:
        if evaluator.bounds.locate(point) is PointLocation.OUTSIDE:
            raise ValueError("Reference equality points must be inside the closed search bounds.")
        evaluation = evaluator.evaluate(point)
        value = evaluation.value if evaluation.value is not None else finite(evaluator.objective(point), "reference objective")
        if abs(value - reference.value) > reference.value_tolerance:
            raise ValueError("Reference equality point does not match the reference objective value.")

    if reference.limit is None:
        return (), None
    limit = evaluator.evaluate(reference.limit)
    if limit.state.included:
        raise ValueError("An approach limit must be excluded from the feasible set.")
    assert reference.approach is not None
    samples = []
    for exponent in (1, 2, 4, 8, 12, 16, 20):
        t = 2.0**-exponent
        point = reference.approach(t)
        item = evaluator.evaluate(point)
        if item.value is None:
            raise ValueError("The reference approach produced an infeasible sample.")
        distance = hypot(point.x - limit.point.x, point.y - limit.point.y)
        samples.append(ApproachSample(t, distance, item))
    if samples[-1].distance >= samples[0].distance:
        raise ValueError("The sampled reference approach did not get closer to its limit.")
    if abs(_value(samples[-1].evaluation) - reference.value) >= abs(_value(samples[0].evaluation) - reference.value):
        raise ValueError("The sampled approach objective did not get closer to the reference value.")
    return tuple(samples), limit


def minimize_2d(
    objective: Objective,
    bounds: Rectangle,
    constraints: Iterable[Constraint] = (),
    *,
    options: SearchOptions = SearchOptions(),
    initial_points: Iterable[Point2D] = (),
    reference: ReferenceBound | None = None,
) -> OptimizationResult:
    """Find feasible candidates, optionally auditing a model-supplied reference."""
    constraints = tuple(constraints)
    names = ("search_bounds", *(constraint.name for constraint in constraints))
    if len(set(names)) != len(names):
        raise ValueError("Constraint names must be unique and exclude the reserved search_bounds.")
    evaluator = _Evaluator(bounds, objective, constraints)
    xs = _axis(bounds.xmin, bounds.xmax, options.grid_size)
    ys = _axis(bounds.ymin, bounds.ymax, options.grid_size)
    entries = [evaluator.evaluate(Point2D(x, y)) for x, y in product(xs, ys)]
    feasible = [entry for entry in entries if entry.value is not None]
    explicit = []
    skipped = 0
    for point in initial_points:
        entry = evaluator.evaluate(point)
        if entry.value is None:
            skipped += 1
        elif entry not in explicit:
            explicit.append(entry)
    if len(explicit) > options.starts:
        raise ValueError("The number of distinct feasible initial points exceeds starts.")

    approach, limit = _check_reference(evaluator, reference) if reference is not None else ((), None)
    starts = _starts(evaluator, feasible, explicit, options.starts)
    runs = tuple(_refine(evaluator, start, options) for start in starts)
    best = min((item for item in evaluator.cache.values() if item.value is not None), key=_value, default=None)
    status = SearchStatus.NO_FEASIBLE_SAMPLE if best is None else SearchStatus.FEASIBLE_CANDIDATE
    if reference is not None and best is not None:
        if _value(best) < reference.value - reference.value_tolerance:
            raise ValueError("A feasible observation contradicts the supplied lower bound.")
        equality = tuple(evaluator.evaluate(point) for point in reference.equality_points)
        witness = next((point for point in equality if point.value == reference.value), None)
        if witness is not None:
            best = witness
            status = SearchStatus.ATTAINED_REFERENCE
        elif approach and all(not point.state.included for point in equality):
            status = SearchStatus.UNATTAINED_REFERENCE
    return OptimizationResult(
        status, best, runs, len(entries), len(feasible), len(evaluator.cache), skipped,
        reference.value if reference is not None else None, limit, approach,
    )
