"""Independent numerical audit of the optimization benchmarks on synthetic inputs."""

import argparse
import csv
from fractions import Fraction as F
from itertools import product
import json
from math import fsum, nextafter, sin
from pathlib import Path
from random import Random
from statistics import median

from geometry import Point2D, Rectangle, Workspace

from ..constraint_analysis import BoxConstraint, ConstraintSet, DiskConstraint, Interval
from ..model import Disk, FeasibleRegion
from .model import SearchOptions, SearchStatus
from .search import minimize_2d
from .validation_cases import benchmarks


GRIDS = (9, 17, 33, 65)
STOP_EXPONENTS = (14, 24, 34)
SEEDS = (53317, 53323)
PROOF = {
    "closed_disk_projection": ("proven_attained", F(1), Point2D(1, 0)),
    "strict_open_edge": ("proven_unattained", F(0), None),
    "zero_width_feasible_set": ("proven_attained", F(25, 256), Point2D(0.375, 0.1875)),
    "disconnected_uncertified": ("global_not_proven", None, None),
}


def oracle(case, point):
    """Use independent rational inequalities, not the benchmark rule callables."""
    x, y = F(point.x), F(point.y)
    b = case.bounds
    boundaries = [("search_bounds", min(x - F(b.xmin), F(b.xmax) - x, y - F(b.ymin), F(b.ymax) - y), False)]
    if case.name == "closed_disk_projection":
        restrictions = [("unit_disk", 1 - x*x - y*y, False), ("floor", y + F(1, 2), False)]
        value = (2 - x)**2 + y*y
    elif case.name == "strict_open_edge":
        restrictions = [("x_positive", x, True), ("x_cap", 1 - x, False), ("vertical_band", F(3, 4) - abs(y), False)]
        value = x + (y - F(1, 8))**2
    elif case.name == "zero_width_feasible_set":
        restrictions = [("closed_line", min(F(3, 4) - abs(x), -abs(y - F(3, 16))), False)]
        value = (x - F(3, 8))**2 + (y - F(1, 2))**2
    else:
        if case.name != "disconnected_uncertified":
            raise ValueError(f"Unknown audit benchmark: {case.name}")
        restrictions = [("two_branches", abs(x) - F(3, 8), False), ("vertical_band", F(3, 4) - abs(y), False)]
        value = fsum((float((x*x - F(1, 4))**2), float((y - F(1, 8))**2), 0.035 * sin(19 * float(x))))
    return boundaries + restrictions, value


def _allows(margin, strict):
    return margin > 0 if strict else margin >= 0


def _feasible(records):
    return all(_allows(margin, strict) for _, margin, strict in records)


def _audit_point(case, observation):
    records, value = oracle(case, observation.point)
    if not _feasible(records) or observation.value is None:
        raise AssertionError(f"An accepted point is infeasible: {case.name}, {observation.point}")
    if abs(float(value) - observation.value) > 1e-14 * max(1.0, abs(float(value))):
        raise AssertionError(f"Objective check failed: {case.name}, {observation.point}")
    if [r[0] for r in records] != [c.name for c in observation.checks]:
        raise AssertionError(f"Constraint interface mismatch: {case.name}")
    if any(not check.state.included for check in observation.checks):
        raise AssertionError("An accepted point has a rejected solver constraint.")
    return records, value


def _starts(case, seed):
    rng = Random(seed)
    if case.name == "disconnected_uncertified":
        selected = [Point2D(-0.625, 0.25), Point2D(0.625, -0.25)]
    else:
        selected = []
    while len(selected) < 3:
        x = rng.randrange(-1024, 1025) / 1024
        y = 0.1875 if case.name == "zero_width_feasible_set" else rng.randrange(-1024, 1025) / 1024
        point = Point2D(x, y)
        if point not in selected and _feasible(oracle(case, point)[0]):
            selected.append(point)
    return tuple(selected)


def _grid_values(case, n):
    box = case.bounds
    # The benchmark boxes and n-1 are binary fractions, so these grid points are exact.
    xs = [F(box.xmin) + (F(box.xmax) - F(box.xmin)) * F(i, n - 1) for i in range(n)]
    ys = [F(box.ymin) + (F(box.ymax) - F(box.ymin)) * F(i, n - 1) for i in range(n)]
    values = []
    for x, y in product(xs, ys):
        records, value = oracle(case, Point2D(float(x), float(y)))
        if _feasible(records):
            values.append(value)
    return values


def _checks(configuration, role, label, case, observation):
    records, _ = _audit_point(case, observation)
    return [
        _check_row(configuration, case.name, role, label, observation.point, name, margin,
                   strict, int(check.state.included), int(_allows(margin, strict)),
                   check.state.name.lower(), "match", check.residual)
        for (name, margin, strict), check in zip(records, observation.checks, strict=True)
    ]


def _check_row(config, case, role, label, point, name, margin, strict, actual, expected, state, finding, residual=None):
    return {
        "configuration": config, "case": case, "point_role": role, "point_id": label,
        "x": point.x, "y": point.y, "constraint": name, "strict": int(strict),
        "independent_margin": float(margin), "solver_residual": residual,
        "solver_included": actual, "independent_included": expected,
        "solver_state": state, "audit_outcome": finding,
    }


def _probes():
    disk = ConstraintSet((DiskConstraint((0, 0), 1),))
    rows = []
    for label, point in (
        ("contact", Point2D(1, 0)), ("inside_ulp", Point2D(nextafter(1., 0.), 0)),
        ("outside_ulp", Point2D(nextafter(1., 2.), 0)), ("rounding_outside", Point2D(1, 2.0**-30)),
    ):
        margin = 1 - F(point.x)**2 - F(point.y)**2
        state = disk.classify(point)
        expected_name = "outside" if margin < 0 else "interior" if margin > 0 else "closed_boundary"
        if state.name.lower() != expected_name:
            raise AssertionError(f"Disk precision regression at {point}.")
        rows.append(_check_row("", "disk_probe", "boundary_probe", label, point, "circle", margin, False,
                               int(state.included), int(margin >= 0), state.name.lower(), "match"))

    # Test the tolerance band separately from arithmetic roundoff.
    epsilon = 2.0**-20
    for tolerance, closed, x in product((0.0, epsilon), (False, True), (-epsilon / 2, 0.0, epsilon / 2, 2*epsilon)):
        point = Point2D(x, 0)
        domain = ConstraintSet((BoxConstraint((Interval(0, 1, lower_closed=closed), Interval(-1, 1))),))
        state = domain.classify(point, tolerance=tolerance)
        expected = x >= -tolerance if closed else x > tolerance
        if state.included != expected:
            raise AssertionError("Open/closed tolerance policy failed.")
        rows.append(_check_row("", "tolerance_probe", "boundary_probe", f"tol={tolerance:g}", point,
                               "x_lower", F(x), not closed, int(state.included), int(expected),
                               state.name.lower(), "match"))

    # Strict clearance must accept the float immediately outside the arc.
    model = FeasibleRegion(Workspace(Rectangle(-3, -3, 4, 4), (Rectangle(0, 0, 1, 1),)), Disk(1), tolerance=0)
    point = Point2D(2, 1 + 2.0**-30)
    margin = (F(point.x) - 1)**2 + (F(point.y) - 1)**2 - 1
    state = model.classify(point)
    if not model.is_legal(point) or not model.is_legal(point, exact=True):
        raise AssertionError("A representable exterior point was rejected at the Minkowski arc.")
    rows.append(_check_row("", "minkowski_precision_probe", "boundary_probe", "outside_arc",
                           point, "strict_clearance", margin, True, int(model.is_legal(point)),
                           int(margin > 0), state.name.lower(),
                           "match" if model.is_legal(point) == (margin > 0) else "documented_float_limit"))

    projected = Point2D(model.inflated_obstacles[0].horizontal_span(point.y)[1], point.y)
    diagnostic = model.boundary_diagnostic(projected)
    margin = (F(projected.x) - 1)**2 + (F(projected.y) - 1)**2 - 1
    rows.append(_check_row("", "minkowski_contact_marker", "boundary_probe", "rounded_contact_marker",
                           projected, "strict_clearance", margin, True, int(model.is_legal(projected)),
                           int(margin > 0), diagnostic.state.name.lower(),
                           "representation_sensitive" if diagnostic.rounding_sensitive else "match"))

    # The float endpoint may be interior to the continuous open disk.
    open_disk = ConstraintSet((DiskConstraint((0, 0), 1, closed=False),))
    section = open_disk.horizontal_section(0.5)
    point = Point2D(section.upper, 0.5)
    margin = 1 - F(point.x)**2 - F(point.y)**2
    belongs = section.contains(point.x)
    if not belongs or not open_disk.contains((point.x, point.y)):
        raise AssertionError("A representable interior point was excluded by its open slice.")
    rows.append(_check_row("", "slice_precision_probe", "boundary_probe", "rounded_open_endpoint", point,
                           "analytic_slice", margin, True, int(belongs), int(margin > 0),
                           open_disk.classify(point).name.lower(),
                           "match" if belongs == (margin > 0) else "documented_float_limit"))
    return rows


def audit():
    summary, trace, checks = [], [], _probes()
    for case in benchmarks():
        label, reference, witness = PROOF[case.name]
        if witness is not None:
            constraints, value = oracle(case, witness)
            if not _feasible(constraints) or value != reference:
                raise AssertionError(f"Bad proof witness for {case.name}.")
        for n in GRIDS:
            grid = _grid_values(case, n)
            for exponent, seed in product(STOP_EXPONENTS, SEEDS):
                config = f"{case.name}__{n}__{exponent}__{seed}"
                seeds = _starts(case, seed)
                options = SearchOptions(grid_size=n, starts=5, step_tolerance=2.0**-exponent, max_iterations=220)
                search = minimize_2d(case.objective, case.bounds, case.constraints, options=options, initial_points=seeds)
                if search.status is not SearchStatus.FEASIBLE_CANDIDATE or search.feasible_samples != len(grid):
                    raise AssertionError(f"Grid/search status failed in {config}.")
                if not grid:
                    grid_only = minimize_2d(case.objective, case.bounds, case.constraints, options=options)
                    if grid_only.status is not SearchStatus.NO_FEASIBLE_SAMPLE:
                        raise AssertionError("A zero-coverage grid was misinterpreted.")
                margins, value = _audit_point(case, search.best)
                checks.extend(_checks(config, "best", "best", case, search.best))
                if reference is not None and (value < reference or (label == "proven_unattained" and value == reference)):
                    raise AssertionError(f"Analytic lower bound or strict domain contradicted: {config}.")
                for index, run in enumerate(search.runs, 1):
                    for role, item in (("start", run.start), ("endpoint", run.candidate)):
                        checks.extend(_checks(config, role, index, case, item))
                    previous = run.start.value
                    for step in run.trace:
                        margins_i, objective_i = _audit_point(case, step.current)
                        if step.current.value > previous:
                            raise AssertionError("Local objective increased.")
                        previous = step.current.value
                        trace.append({
                            "configuration": config, "start": index,
                            "start_source": "fixed_seed" if run.start.point in seeds else "grid",
                            "start_x": run.start.point.x, "start_y": run.start.point.y,
                            "start_objective": run.start.value, "iteration": step.iteration,
                            "step": step.step, "x": step.current.point.x, "y": step.current.point.y,
                            "objective": step.current.value, "independent_objective": float(objective_i),
                            "min_independent_margin": float(min(m for _, m, _ in margins_i)),
                            "independent_feasible": 1,
                            "stop_reason": run.stop_reason if step.iteration == len(run.trace) else "",
                        })
                local = [run.candidate.value for run in search.runs]
                summary.append({
                    "configuration": config, "case": case.name, "grid_size": n, "step_tolerance": options.step_tolerance,
                    "seed": seed, "grid_feasible": len(grid), "grid_best": float(min(grid)) if grid else None,
                    "grid_only_status_if_empty": "no_feasible_sample" if not grid else "",
                    "best_x": search.best.point.x, "best_y": search.best.point.y, "objective": search.best.value,
                    "independent_objective": float(value), "independent_feasible": 1,
                    "minimum_certified_or_infimum": None if reference is None else float(reference),
                    "proof_status": label, "candidate_is_exact_proven_witness": int(search.best.point == witness),
                    "independent_objective_gap": float(value - reference) if reference is not None else None,
                    "min_independent_margin": float(min(m for _, m, _ in margins)),
                    "starts": len(local), "start_spread": max(local) - min(local),
                    "iterations": sum(len(run.trace) for run in search.runs),
                    "step_stops": sum(run.stop_reason == "step_tolerance" for run in search.runs),
                    "iteration_limit_stops": sum(run.stop_reason == "iteration_limit" for run in search.runs),
                })
    return summary, trace, checks


def _save(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        out = csv.DictWriter(stream, fieldnames=list(rows[0]))
        out.writeheader()
        out.writerows(rows)


def _plot(path, summary, trace):
    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    fig, (a, b) = plt.subplots(1, 2, figsize=(9.0, 3.55), layout="constrained")
    cases = (
        ("closed_disk_projection", "Closed disk", "#175d70"),
        ("strict_open_edge", "Open edge", "#a65227"),
        ("zero_width_feasible_set", "Closed line", "#456d35"),
    )
    fine = 2.0**-max(STOP_EXPONENTS)
    for name, label, color in cases:
        values = [median(r["independent_objective_gap"] for r in summary
                         if r["case"] == name and r["grid_size"] == n and r["step_tolerance"] == fine) for n in GRIDS]
        a.plot(GRIDS, values, marker="o", color=color, label=label)
    a.set(title="Gap to the analytic reference", ylabel="Median exact objective gap", xlabel="Grid points per axis")
    a.set_yscale("symlog", linthresh=1e-12)
    a.legend(frameon=False, fontsize=8)

    configurations = {
        row["configuration"]: row["grid_size"] for row in summary
        if row["case"] == "disconnected_uncertified" and row["step_tolerance"] == fine
    }
    endpoints = [row for row in trace if row["stop_reason"] and row["configuration"] in configurations]
    for positive, label, color in ((False, "x < 0 branch", "#213f61"), (True, "x > 0 branch", "#a65227")):
        values = [
            median(row["objective"] for row in endpoints
                   if configurations[row["configuration"]] == n and (row["x"] > 0) == positive)
            for n in GRIDS
        ]
        b.plot(GRIDS, values, marker="o", color=color, label=label)
    b.set(title="Local endpoints by feasible branch", ylabel="Median terminal objective", xlabel="Grid points per axis")
    b.ticklabel_format(axis="y", style="plain", useOffset=False)
    b.legend(frameon=False, fontsize=8)
    for ax in (a, b):
        ax.set_xticks(GRIDS)
        ax.grid(axis="y", alpha=0.25)
    try:
        fig.savefig(path, dpi=280)
    finally:
        plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/strict_audit"))
    args = parser.parse_args()
    summary, trace, checks = audit()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for name, data in (("validation_results.csv", summary), ("convergence.csv", trace), ("constraint_checks.csv", checks)):
        _save(args.output_dir / name, data)
    _plot(args.output_dir / "audit_convergence.png", summary, trace)
    print(json.dumps({
        "configurations": len(summary), "starts": sum(r["starts"] for r in summary),
        "trace_rows": len(trace), "check_rows": len(checks),
        "known_precision_limits": [r["case"] for r in checks
                                   if r["audit_outcome"] in {"documented_float_limit", "representation_sensitive"}],
        "iteration_limits": sum(r["iteration_limit_stops"] for r in summary),
        "seeds": SEEDS,
    }))


if __name__ == "__main__":
    main()
