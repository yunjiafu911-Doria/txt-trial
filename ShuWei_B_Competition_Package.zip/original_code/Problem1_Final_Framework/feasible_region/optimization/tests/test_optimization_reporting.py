import csv

from feasible_region.optimization.demo import export, synthetic_cases
from feasible_region.optimization.model import SearchOptions


def test_demo_exports_candidates_residuals_trace_and_open_boundary_path(tmp_path):
    results = synthetic_cases(SearchOptions())
    export(results, tmp_path)

    def read_csv(name):
        with (tmp_path / name).open(newline="", encoding="utf-8") as stream:
            return list(csv.DictReader(stream))

    candidates = [row for row in read_csv("candidates.csv") if row["candidate"] == "best"]
    assert [row["result_status"] for row in candidates] == [
        "attained_reference", "unattained_reference", "feasible_candidate",
    ]
    diagnostics = read_csv("constraint_residuals.csv")
    excluded = [row for row in diagnostics if row["sample"] == "excluded_limit" and row["constraint"] == "positive_x"]
    assert len(excluded) == 1 and excluded[0]["state"] == "open_boundary"
    assert float(excluded[0]["signed_residual"]) == 0
    assert any(row["signed_residual"] == "" for row in diagnostics if row["constraint"] == "separated_regions")
    trace = read_csv("convergence.csv")
    assert len({(row["case"], row["start_id"]) for row in trace}) == 15
    assert len([row for row in trace if row["stop_reason"]]) == 15
    approach = read_csv("reference_approach.csv")
    assert len(approach) == 7
    assert float(approach[-1]["objective_gap"]) < float(approach[0]["objective_gap"])
    report = (tmp_path / "CONVERGENCE.md").read_text(encoding="utf-8")
    assert "下确界" in report and "disconnected_wells" in report
