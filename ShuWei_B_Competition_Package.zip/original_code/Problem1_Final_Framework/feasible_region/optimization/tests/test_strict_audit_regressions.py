from fractions import Fraction
from math import nextafter

from geometry import Point2D, Rectangle
from feasible_region.constraint_analysis import ConstraintSet, DiskConstraint, Membership
from feasible_region.optimization import Constraint, ReferenceBound, SearchOptions, SearchStatus, minimize_2d


def test_disk_reclassifies_exterior_that_rounds_to_hypot_boundary():
    point = Point2D(1, 2.0**-30)
    domain = ConstraintSet((DiskConstraint((0, 0), 1),))
    assert 1 - Fraction(point.x)**2 - Fraction(point.y)**2 == -Fraction(1, 2**60)
    assert domain.classify(point) is Membership.OUTSIDE
    assert domain.classify(Point2D(1, 0)) is Membership.CLOSED_BOUNDARY
    assert domain.classify(Point2D(nextafter(1.0, 0), 0)) is Membership.INTERIOR


def test_rounded_feasible_objective_does_not_prove_attainment_on_open_domain():
    origin = Point2D(0, 0)
    result = minimize_2d(
        lambda p: 1 + p.x**2 + p.y**2, Rectangle(-1, -1, 1, 1),
        (Constraint("positive_x", residual=lambda p: p.x, strict=True),),
        options=SearchOptions(step_tolerance=2**-34),
        reference=ReferenceBound(1, (origin,), limit=origin, approach=lambda t: Point2D(t, 0)),
    )
    assert result.best.point.x > 0 and result.best.value == 1.0
    assert (1 + Fraction(result.best.point.x)**2 + Fraction(result.best.point.y)**2) > 1
    assert result.reference_limit.state is Membership.OPEN_BOUNDARY
    assert result.status is SearchStatus.UNATTAINED_REFERENCE
