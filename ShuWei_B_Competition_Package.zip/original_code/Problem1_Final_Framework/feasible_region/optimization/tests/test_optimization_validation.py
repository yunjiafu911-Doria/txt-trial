from feasible_region.optimization.validate import _numeric_probes, run_validation


def test_validation_comparison_keeps_reference_out_of_seeded_search_and_audits_candidates():
    rows, convergence, checks = run_validation(grid_sizes=(9, 33), step_tolerances=(1e-6,))
    assert len(rows) == 8
    by_case = {(item["case"], item["grid_size"]): item for item in rows}
    for row in rows:
        assert row["search_status"] == "feasible_candidate"
        assert row["all_accepted_candidates_independently_feasible"] == 1
        assert row["local_iterations_total"] >= row["local_iterations_max"]
    line_coarse = by_case["zero_width_feasible_set", 9]
    assert line_coarse["grid_feasible"] == 0 and line_coarse["grid_only_status_if_empty"] == "no_feasible_sample"
    assert line_coarse["best_objective"] == 25 / 256
    assert by_case["zero_width_feasible_set", 33]["grid_feasible"] > 0
    assert by_case["closed_disk_projection", 9]["reference_status"] == "attained_reference"
    strict = by_case["strict_open_edge", 33]
    assert strict["reference_status"] == "unattained_reference" and strict["objective_gap"] > 0
    assert by_case["disconnected_uncertified", 33]["reference_status"] == "global_not_proven"
    assert {item["start_source"] for item in convergence} == {"fixed", "grid_pool"}
    assert all(check["oracle_included"] == 1 for check in checks if check["point_type"] == "best_candidate")
    assert any(check["point_type"] == "reference_limit" and check["constraint"] == "x_positive"
               and check["oracle_state"] == "open_boundary" and check["oracle_included"] == 0 for check in checks)


def test_numeric_probes_cover_float_resolution_and_geometric_tolerance():
    probes = _numeric_probes()
    assert len(probes) == 28
    contact = next(row for row in probes if row["point_id"] == "axis_contact")
    assert contact["solver_state"] == contact["oracle_state"] == "closed_boundary"
    subtle = next(row for row in probes if row["point_id"] == "below_float_boundary_resolution")
    assert subtle["oracle_state"] == "outside"
    assert subtle["outcome"] in {"full_state_match", "floating_point_resolution_limit"}
    boundary_bands = [row for row in probes if row["case"] == "interval_boundary_probe"
                      and row["x"] == 0 and row["constraint_tolerance"] > 0]
    assert {row["solver_state"] for row in boundary_bands} == {"open_boundary", "closed_boundary"}
