from math import inf

import pytest

from geometry import Point2D, Rectangle

from feasible_region.constraint_analysis import ConstraintSet, DiskConstraint, Membership
from feasible_region.optimization import Constraint, ReferenceBound, SearchOptions, SearchStatus, minimize_2d


BOUNDS = Rectangle(-2, -2, 2, 2)


def squared(point):
    return point.x**2 + point.y**2


def test_custom_boolean_and_geometry_predicates_share_the_existing_point_model():
    disk = ConstraintSet((DiskConstraint((0, 0), 1),))
    result = minimize_2d(
        lambda p: (p.x - 0.317)**2 + (p.y + 0.223)**2,
        BOUNDS,
        (Constraint("disk", predicate=disk.classify),
         Constraint("band", predicate=lambda p: abs(p.y) < 0.5, residual=lambda p: 0.5 - abs(p.y))),
    )
    assert result.status is SearchStatus.FEASIBLE_CANDIDATE
    assert isinstance(result.best.point, Point2D)
    assert result.best.point.x == pytest.approx(0.317, abs=1e-6)
    assert result.best.point.y == pytest.approx(-0.223, abs=1e-6)
    assert result.best.value < 1e-12
    checks = {item.name: item for item in result.best.checks}
    assert checks["disk"].residual is None
    assert checks["band"].residual > 0


def test_strict_and_closed_zero_residual_are_distinct():
    point = Point2D(0, 0)
    closed = Constraint("closed", residual=lambda p: p.x)
    opened = Constraint("open", residual=lambda p: p.x, strict=True)
    assert closed.evaluate(point).state is Membership.CLOSED_BOUNDARY
    assert opened.evaluate(point).state is Membership.OPEN_BOUNDARY
    assert opened.evaluate(point).residual == 0
    assert not opened.evaluate(point).state.included


def test_verified_closed_reference_is_attained():
    origin = Point2D(0, 0)
    result = minimize_2d(
        squared, BOUNDS, (Constraint("nonnegative", residual=lambda p: p.x),),
        reference=ReferenceBound(0, (origin,)),
    )
    assert result.status is SearchStatus.ATTAINED_REFERENCE
    assert result.best.point == origin and result.best.value == 0
    assert result.best.state is Membership.CLOSED_BOUNDARY


def test_open_reference_approaches_zero_without_selecting_the_excluded_limit():
    origin = Point2D(0, 0)
    constraint = Constraint("positive", residual=lambda p: p.x, strict=True)
    reference = ReferenceBound(0, (origin,), limit=origin, approach=lambda t: Point2D(t, 0))
    result = minimize_2d(squared, BOUNDS, (constraint,), reference=reference)
    assert result.status is SearchStatus.UNATTAINED_REFERENCE
    assert result.best.point.x > 0 and 0 < result.best.value < 1e-12
    assert result.reference_limit.point == origin
    assert result.reference_limit.state is Membership.OPEN_BOUNDARY
    assert result.reference_limit.value is None
    assert [row.evaluation.value for row in result.approach] == [row.t**2 for row in result.approach]
    assert result.approach[-1].distance < result.approach[0].distance
    heuristic = minimize_2d(squared, BOUNDS, (constraint,))
    assert heuristic.status is SearchStatus.FEASIBLE_CANDIDATE
    assert heuristic.best.point.x > 0


def test_disconnected_regions_keep_distinct_start_results_and_nonincreasing_trace():
    result = minimize_2d(
        lambda p: (p.x**2 - 1)**2 + p.y**2 + 0.1 * p.x,
        BOUNDS, (Constraint("branches", predicate=lambda p: abs(p.x) >= 0.5),),
        initial_points=(Point2D(-1, 0), Point2D(1, 0), Point2D(0, 0)),
    )
    assert result.skipped_initial_points == 1
    assert len(result.runs) == 5
    assert result.runs[0].candidate.point.x < -0.9
    assert result.runs[1].candidate.point.x > 0.9
    assert result.best.point.x < 0
    assert result.runs[0].candidate.value < result.runs[1].candidate.value
    for run in result.runs:
        values = [run.start.value, *(row.current.value for row in run.trace)]
        assert all(first >= last for first, last in zip(values, values[1:]))
        assert run.stop_reason == "step_tolerance"


def test_iteration_limit_and_feasible_start_off_the_grid():
    options = SearchOptions(grid_size=2, starts=1, max_iterations=1)
    only_point = Point2D(0.317, 0.223)
    constraint = Constraint("isolated", predicate=lambda p: p == only_point)
    absent = minimize_2d(squared, BOUNDS, (constraint,), options=options)
    assert absent.status is SearchStatus.NO_FEASIBLE_SAMPLE and absent.best is None
    found = minimize_2d(squared, BOUNDS, (constraint,), options=options, initial_points=(only_point,))
    assert found.feasible_samples == 0
    assert found.best.point == only_point
    assert found.runs[0].stop_reason == "iteration_limit"


def test_never_calls_objective_on_rejected_grid_points():
    def domain_only(point):
        assert point.x > 0
        return point.x

    result = minimize_2d(domain_only, BOUNDS, (Constraint("positive", predicate=lambda p: p.x > 0),))
    assert result.best.point.x > 0


def test_bad_reference_is_rejected():
    with pytest.raises(ValueError, match="contradicts"):
        minimize_2d(squared, BOUNDS, reference=ReferenceBound(1, (Point2D(1, 0),)))
    with pytest.raises(ValueError, match="reference objective value"):
        minimize_2d(squared, BOUNDS, reference=ReferenceBound(1, (Point2D(0, 0),)))
    origin = Point2D(0, 0)
    with pytest.raises(ValueError, match="infeasible sample"):
        minimize_2d(
            squared, BOUNDS, (Constraint("positive", residual=lambda p: p.x, strict=True),),
            reference=ReferenceBound(0, (origin,), limit=origin, approach=lambda t: Point2D(-t, 0)),
        )


def test_bad_objective_residual_and_options_fail_explicitly():
    with pytest.raises(ValueError, match="objective"):
        minimize_2d(lambda p: inf, BOUNDS)
    with pytest.raises(ValueError, match="residual"):
        minimize_2d(squared, BOUNDS, (Constraint("broken", residual=lambda p: inf),))
    with pytest.raises(ValueError, match="grid_size"):
        SearchOptions(grid_size=1)
    with pytest.raises(ValueError, match="unique"):
        minimize_2d(squared, BOUNDS, (Constraint("a", predicate=lambda p: True),) * 2)
