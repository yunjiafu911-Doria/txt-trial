"""Export grid samples, analytic sections, and an analytic-versus-grid figure."""

import csv
from collections.abc import Iterable
from pathlib import Path
from typing import TYPE_CHECKING

import numpy as np

from .model import CenterState, FeasibleRegion, Rectangle, RoundedRectangle
from .sampling import GridSample

if TYPE_CHECKING:
    from matplotlib.figure import Figure


STATE_COLORS = {
    CenterState.OUTSIDE_WORKSPACE: "#e7ebee",
    CenterState.OBSTACLE_OVERLAP: "#ecc5ac",
    CenterState.CONTACT: "#e5bd55",
    CenterState.FREE: "#c9e5d8",
}
ORIGINAL_OBSTACLE = "#965745"
MINKOWSKI_OUTLINE = "#8a442a"


def write_grid_csv(grid: GridSample, path: str | Path) -> None:
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("row", "column", "x", "y", "state", "strictly_legal"))
        x_centers = grid.x_centers
        for row, y in enumerate(grid.y_centers):
            for column, x in enumerate(x_centers):
                state = CenterState(grid.states[row, column])
                writer.writerow((row, column, x, y, state.name.lower(), int(state is CenterState.FREE)))


def write_sections_csv(region: FeasibleRegion, heights: Iterable[float], path: str | Path) -> None:
    with Path(path).open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(("y", "interval", "x_lower_open", "x_upper_open"))
        for y in heights:
            sections = region.horizontal_free_intervals(y)
            if not sections:
                writer.writerow((y, "", "", ""))
            for index, (left, right) in enumerate(sections, start=1):
                writer.writerow((y, index, left, right))


def _rectangle_patch(rectangle: Rectangle, **style):
    from matplotlib.patches import Rectangle as RectanglePatch

    return RectanglePatch(
        (rectangle.xmin, rectangle.ymin),
        rectangle.xmax - rectangle.xmin,
        rectangle.ymax - rectangle.ymin,
        **style,
    )


def _rounded_patch(obstacle: RoundedRectangle, **style):
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path as CurvePath

    rectangle = obstacle.rectangle
    radius = obstacle.radius
    if radius == 0:
        return _rectangle_patch(rectangle, **style)

    # Bézier arcs render as vector curves. Geometry queries use the exact circle formula.
    corners = (
        (rectangle.xmax, rectangle.ymin, -90, 0),
        (rectangle.xmax, rectangle.ymax, 0, 90),
        (rectangle.xmin, rectangle.ymax, 90, 180),
        (rectangle.xmin, rectangle.ymin, 180, 270),
    )
    vertices = []
    codes = []
    for x, y, start, end in corners:
        arc = CurvePath.arc(start, end)
        vertices.extend((arc.vertices * radius + (x, y)).tolist())
        codes.append(CurvePath.MOVETO if not codes else CurvePath.LINETO)
        codes.extend(arc.codes[1:])
    vertices.append(vertices[0])
    codes.append(CurvePath.CLOSEPOLY)
    return PathPatch(CurvePath(vertices, codes), **style)


def plot_comparison(region: FeasibleRegion, grid: GridSample) -> "Figure":
    """Draw the continuous construction and the cell-based sampling side by side."""
    from matplotlib import pyplot as plt
    from matplotlib.colors import BoundaryNorm, ListedColormap
    from matplotlib.patches import Patch

    workspace = region.workspace.bounds
    figure, (analytic, sampled) = plt.subplots(1, 2, figsize=(11, 5.1), sharex=True, sharey=True)
    figure.subplots_adjust(left=0.075, right=0.975, top=0.89, bottom=0.23, wspace=0.13)

    canvas = _rectangle_patch(workspace, facecolor=STATE_COLORS[CenterState.OUTSIDE_WORKSPACE])
    analytic.add_patch(canvas)
    if region.strict_bounds is not None:
        analytic.add_patch(_rectangle_patch(
            region.strict_bounds, facecolor=STATE_COLORS[CenterState.FREE], edgecolor="#4e8871",
            linewidth=1.1,
        ))
    for obstacle in region.strict_obstacles:
        patch = _rounded_patch(obstacle, facecolor=STATE_COLORS[CenterState.OBSTACLE_OVERLAP])
        analytic.add_patch(patch)
        patch.set_clip_path(canvas)
    for obstacle in region.inflated_obstacles:
        patch = _rounded_patch(obstacle, facecolor="none", edgecolor=MINKOWSKI_OUTLINE, linewidth=1.1)
        analytic.add_patch(patch)
        patch.set_clip_path(canvas)
    for rectangle in region.workspace.rectangles:
        analytic.add_patch(_rectangle_patch(rectangle, facecolor=ORIGINAL_OBSTACLE))
    analytic.set_title("Analytic geometry", loc="left", fontweight="bold")

    cmap = ListedColormap([STATE_COLORS[state] for state in CenterState])
    norm = BoundaryNorm(np.arange(len(CenterState) + 1) - 0.5, cmap.N)
    sampled.pcolormesh(
        grid.x_edges, grid.y_edges, grid.states, cmap=cmap, norm=norm, shading="flat",
        rasterized=False,
    )
    for rectangle in region.workspace.rectangles:
        sampled.add_patch(_rectangle_patch(rectangle, fill=False, edgecolor=ORIGINAL_OBSTACLE, linewidth=1))
    ny, nx = grid.states.shape
    sampled.set_title(f"Grid sampling, {nx} × {ny} cells", loc="left", fontweight="bold")

    for axes in (analytic, sampled):
        axes.set(
            xlim=(workspace.xmin, workspace.xmax), ylim=(workspace.ymin, workspace.ymax),
            xlabel="x", ylabel="y",
        )
        axes.set_aspect("equal")
    figure.legend(
        handles=[
            Patch(facecolor=STATE_COLORS[CenterState.FREE], label="Strictly feasible"),
            Patch(facecolor=STATE_COLORS[CenterState.OUTSIDE_WORKSPACE], label="Workspace edge band"),
            Patch(facecolor=STATE_COLORS[CenterState.CONTACT], label="Sampled contact"),
            Patch(facecolor=STATE_COLORS[CenterState.OBSTACLE_OVERLAP], label="Obstacle exclusion"),
            Patch(facecolor="none", edgecolor=MINKOWSKI_OUTLINE, label="Minkowski boundary"),
            Patch(facecolor=ORIGINAL_OBSTACLE, label="Original obstacle"),
        ],
        loc="lower center", bbox_to_anchor=(0.5, 0.035), frameon=False, ncol=3,
    )
    return figure
