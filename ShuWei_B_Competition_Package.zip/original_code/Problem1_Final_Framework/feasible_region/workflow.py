"""Run an integrated constraint check on synthetic teaching examples."""

import csv
from pathlib import Path

from .api import (
    BoxConstraint,
    ConstraintSet,
    Disk,
    FeasibleRegion,
    Interval,
    Point2D,
    Point3D,
    PredicateConstraint,
    Rectangle,
    Workspace,
    angle_in_interval,
    azimuth,
    center_constraint,
    elevation,
    horizontal_distance,
    sample_feasible_grid,
    segment_box_intersection,
)
from .geometry3d.demo import generate_scene, plot_scene
from .reporting import plot_comparison


def _run_planar(output_dir: Path) -> None:
    from matplotlib import pyplot as plt
    from matplotlib.patches import Rectangle as WindowPatch

    workspace = Workspace(Rectangle(0, 0, 12, 8), (Rectangle(3, 2, 5, 4),))
    region = FeasibleRegion(workspace, Disk(0.75), tolerance=0.0)
    window = BoxConstraint((Interval(0.75, 10, upper_closed=False), Interval(1, 7)))
    intersection = ConstraintSet((center_constraint(region), window))
    points = (
        ("interior", Point2D(2, 6)),
        ("obstacle", Point2D(4, 3)),
        ("obstacle_touch", Point2D(2.25, 3)),
        ("workspace_touch", Point2D(0.75, 6)),
        ("open_cut", Point2D(10, 5)),
        ("closed_cut", Point2D(8, 1)),
        ("outside", Point2D(11.5, 6)),
    )
    states = tuple(intersection.classify(point) for _, point in points)
    with (output_dir / "constraints_2d.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow((
            "sample_id", "x", "y", "footprint_state", "window_state", "intersection_state", "included",
        ))
        for (name, point), state in zip(points, states):
            writer.writerow((
                name, point.x, point.y, region.classify(point).name.lower(),
                window.classify((point.x, point.y), 0.0).name.lower(), state.name.lower(), int(state.included),
            ))

    figure = plot_comparison(region, sample_feasible_grid(region, 48, 32))
    for label in figure.legends[0].get_texts():
        if label.get_text() == "Strictly feasible":
            label.set_text("Footprint-clear area")
    x_axis, y_axis = window.axes
    figure.suptitle("2D constraints: footprint clearance and analysis window", fontsize=13)
    for axes in figure.axes:
        axes.add_patch(WindowPatch(
            (x_axis.lower, y_axis.lower), x_axis.upper - x_axis.lower, y_axis.upper - y_axis.lower,
            fill=False, edgecolor="#564b82", linewidth=1.15, linestyle=":", zorder=4,
        ))
        axes.plot(
            [x_axis.upper, x_axis.upper], [y_axis.lower, y_axis.upper],
            color="#564b82", linestyle="--", linewidth=1.45, zorder=4,
        )
        for (_, point), state in zip(points, states):
            axes.scatter(
                point.x, point.y, marker="o" if state.included else "x", s=32,
                color="#165848" if state.included else "#9c4028", zorder=5,
            )
    figure.text(
        0.5, 0.14, "Dotted: analysis window  |  Dashed: open edge  |  Circles: accepted  |  Crosses: excluded",
        ha="center", fontsize=8,
    )
    try:
        figure.savefig(output_dir / "scene_2d.png", dpi=250)
    finally:
        plt.close(figure)


def _run_spatial(output_dir: Path, seed: int) -> None:
    from matplotlib import pyplot as plt

    box, segments = generate_scene(seed)
    height_threshold = box.minimum.z + 0.25 * (box.maximum.z - box.minimum.z)
    intersection = ConstraintSet((
        BoxConstraint.from_box(box),
        PredicateConstraint(3, lambda point, tolerance: point[2] >= height_threshold - tolerance),
    ))
    with (output_dir / "geometry_3d.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow((
            "case_id", "start_x", "start_y", "start_z", "end_x", "end_y", "end_z",
            "segment_box_state", "midpoint_intersection_state", "midpoint_included",
            "horizontal_distance", "azimuth_deg", "elevation_deg", "azimuth_in_band", "elevation_in_band",
        ))
        for index, segment in enumerate(segments, start=1):
            start, end = segment.start, segment.end
            midpoint = Point3D(*(0.5 * a + 0.5 * b for a, b in zip(start.coordinates, end.coordinates)))
            intersection_state = intersection.classify(midpoint)
            azimuth_deg, elevation_deg = azimuth(start, end), elevation(start, end)
            writer.writerow((
                index, *start.coordinates, *end.coordinates,
                segment_box_intersection(segment, box).value, intersection_state.name.lower(),
                int(intersection_state.included), horizontal_distance(start, end), azimuth_deg, elevation_deg,
                int(angle_in_interval(azimuth_deg, 350, 8, period=360)),
                int(angle_in_interval(elevation_deg, -35, 35)),
            ))

    figure = plot_scene(box, segments, seed=seed)
    try:
        figure.savefig(output_dir / "scene_3d.png", dpi=220)
    finally:
        plt.close(figure)


def run_examples(output_dir: str | Path, *, seed: int = 42) -> dict[str, Path]:
    """Generate four integrated example artifacts in output_dir."""
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    _run_planar(destination)
    _run_spatial(destination, seed)
    names = ("constraints_2d.csv", "geometry_3d.csv", "scene_2d.png", "scene_3d.png")
    return {name: destination / name for name in names}
