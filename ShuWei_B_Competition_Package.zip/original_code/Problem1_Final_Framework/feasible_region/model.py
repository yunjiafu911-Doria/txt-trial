"""Analytic geometry for a disk moving inside an axis-aligned workspace."""

from dataclasses import dataclass, field
from enum import IntEnum
from fractions import Fraction
from math import hypot, isfinite, ulp

import numpy as np
from numpy.typing import ArrayLike, NDArray

from geometry import Point2D as Point, Rectangle, Workspace

from ._float_chord import inward_endpoint


class CenterState(IntEnum):
    OUTSIDE_WORKSPACE = 0
    OBSTACLE_OVERLAP = 1
    CONTACT = 2
    FREE = 3


@dataclass(frozen=True, slots=True)
class BoundaryDiagnostic:
    """Compare the slice convention with exact geometry of the supplied numbers."""

    state: CenterState
    exact_state: CenterState

    @property
    def rounding_sensitive(self) -> bool:
        return self.state is not self.exact_state


@dataclass(frozen=True, slots=True)
class Disk:
    """An origin-centered disk used as the footprint of a movable object."""

    radius: float

    def __post_init__(self) -> None:
        if not isfinite(self.radius) or self.radius < 0:
            raise ValueError("radius must be finite and nonnegative.")


FloatArray = NDArray[np.float64]
Limits = tuple[float | FloatArray, float | FloatArray, float, float]


def _box_limits(rectangle: Rectangle, offset: float) -> tuple[float, float, float, float]:
    return (
        rectangle.xmin - offset, rectangle.xmax + offset,
        rectangle.ymin - offset, rectangle.ymax + offset,
    )


def _rounded_limits(rectangle: Rectangle, offset: float, y: FloatArray) -> Limits:
    """Return horizontal endpoints at y, plus the outer vertical limits."""
    left, right, bottom, top = _box_limits(rectangle, offset)
    if offset <= 0:
        # A zero offset preserves the rectangle, and a negative offset insets it.
        return left, right, bottom, top

    gap = np.clip(np.maximum(rectangle.ymin - y, y - rectangle.ymax), 0, offset)
    # Evaluate sqrt(offset**2 - gap**2) without squaring a large offset.
    extension = offset * np.sqrt(((offset - gap) / offset) * (1 + gap / offset))
    # On a straight cap use zero extension even if subtracting coordinates loses a bit.
    extension = np.where((bottom < y) & (y < top), extension, 0)
    left = np.asarray(rectangle.xmin - extension).copy()
    right = np.asarray(rectangle.xmax + extension).copy()
    corner = (bottom < y) & (y < top) & ((y < rectangle.ymin) | (y > rectangle.ymax))
    if np.any(corner):
        heights, first, indices = np.unique(y[corner], return_index=True, return_inverse=True)
        left_guesses, right_guesses = left[corner][first], right[corner][first]
        radius_squared = Fraction(offset) ** 2
        for index, height in enumerate(heights):
            edge = rectangle.ymin if height < rectangle.ymin else rectangle.ymax
            width_squared = radius_squared - (Fraction(float(height)) - Fraction(edge)) ** 2
            left_guesses[index] = inward_endpoint(float(rectangle.xmin), float(left_guesses[index]), width_squared, -1)[0]
            right_guesses[index] = inward_endpoint(float(rectangle.xmax), float(right_guesses[index]), width_squared, 1)[0]
        left[corner], right[corner] = left_guesses[indices], right_guesses[indices]
    return left, right, bottom, top


def _contains(
    x: FloatArray, y: FloatArray, limits: Limits, *, closed: bool,
) -> NDArray[np.bool_]:
    left, right, bottom, top = limits
    compare = np.less_equal if closed else np.less
    return compare(left, x) & compare(x, right) & compare(bottom, y) & compare(y, top)


@dataclass(frozen=True, slots=True)
class RoundedRectangle:
    rectangle: Rectangle
    disk: Disk

    @property
    def radius(self) -> float:
        return self.disk.radius

    def signed_clearance(self, point: Point) -> float:
        """Signed distance to the rounded boundary, negative on its interior."""
        rectangle = self.rectangle
        dx = max(rectangle.xmin - point.x, point.x - rectangle.xmax)
        dy = max(rectangle.ymin - point.y, point.y - rectangle.ymax)
        distance = hypot(max(dx, 0), max(dy, 0)) + min(max(dx, dy), 0)
        clearance = distance - self.radius
        if 0 < distance < float("inf") and abs(clearance) <= 8 * ulp(max(distance, self.radius)):
            dx, dy = _exact_gaps(rectangle, Fraction(point.x), Fraction(point.y))
            numerator = max(dx, 0)**2 + max(dy, 0)**2 - Fraction(self.radius)**2
            return float(numerator / (Fraction(distance) + Fraction(self.radius)))
        return clearance

    def horizontal_span(self, y: float) -> tuple[float, float] | None:
        """Return the closed span of the rounded rectangle at height y."""
        if not isfinite(y):
            raise ValueError("y must be finite.")
        left, right, bottom, top = _rounded_limits(self.rectangle, self.radius, np.asarray(y, dtype=float))
        if not bottom <= y <= top:
            return None
        return float(left), float(right)


def _exact_gaps(rectangle: Rectangle, x: Fraction, y: Fraction) -> tuple[Fraction, Fraction]:
    return (
        max(Fraction(rectangle.xmin) - x, x - Fraction(rectangle.xmax)),
        max(Fraction(rectangle.ymin) - y, y - Fraction(rectangle.ymax)),
    )


def _exact_offset_compare(dx: Fraction, dy: Fraction, offset: Fraction) -> int:
    nearest_side = max(dx, dy)
    if nearest_side <= 0:
        difference = nearest_side - offset
    elif offset < 0:
        return 1
    else:
        difference = max(dx, 0)**2 + max(dy, 0)**2 - offset**2
    return (difference > 0) - (difference < 0)


def minkowski_sum(rectangle: Rectangle, disk: Disk) -> RoundedRectangle:
    """Represent the exact sum by flat edges and four quarter-circle arcs."""
    return RoundedRectangle(rectangle, disk)


@dataclass(frozen=True, slots=True)
class FeasibleRegion:
    workspace: Workspace
    disk: Disk
    tolerance: float = 1e-9
    inflated_obstacles: tuple[RoundedRectangle, ...] = field(init=False)
    strict_obstacles: tuple[RoundedRectangle, ...] = field(init=False, repr=False)
    strict_bounds: Rectangle | None = field(init=False)

    def __post_init__(self) -> None:
        if not isfinite(self.tolerance) or self.tolerance < 0:
            raise ValueError("tolerance must be finite and nonnegative.")

        obstacles = tuple(minkowski_sum(rectangle, self.disk) for rectangle in self.workspace.rectangles)
        object.__setattr__(self, "inflated_obstacles", obstacles)
        strict_disk = Disk(self.disk.radius + self.tolerance)
        object.__setattr__(self, "strict_obstacles", tuple(
            minkowski_sum(rectangle, strict_disk) for rectangle in self.workspace.rectangles
        ))
        left, right, bottom, top = _box_limits(self.workspace.bounds, -strict_disk.radius)
        interior = Rectangle(left, bottom, right, top) if left < right and bottom < top else None
        object.__setattr__(self, "strict_bounds", interior)

    def classify_points(self, x: ArrayLike, y: ArrayLike) -> NDArray[np.uint8]:
        """Classify broadcastable coordinates using the analytic offset boundaries."""
        x, y = np.asarray(x), np.asarray(y)
        if np.iscomplexobj(x) or np.iscomplexobj(y):
            raise ValueError("Point coordinates must be real.")
        x, y = np.broadcast_arrays(x.astype(float, copy=False), y.astype(float, copy=False))
        if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)):
            raise ValueError("Point coordinates must be finite.")

        lower = self.disk.radius - self.tolerance
        upper = self.disk.radius + self.tolerance
        bounds = self.workspace.bounds
        strictly_within = _contains(x, y, _box_limits(bounds, -upper), closed=False)
        within_or_touching = _contains(x, y, _box_limits(bounds, -lower), closed=True)

        states = np.full(x.shape, CenterState.FREE, dtype=np.uint8)
        states[~strictly_within] = CenterState.CONTACT
        # Aggregate all closed contacts before applying the higher-priority overlap state.
        blocked = np.zeros(x.shape, dtype=bool)
        for obstacle in self.workspace.rectangles:
            outer_limits = _rounded_limits(obstacle, upper, y)
            inner_limits = outer_limits if lower == upper else _rounded_limits(obstacle, lower, y)
            states[_contains(x, y, outer_limits, closed=True)] = CenterState.CONTACT
            blocked |= _contains(x, y, inner_limits, closed=False)
        states[blocked] = CenterState.OBSTACLE_OVERLAP
        states[~within_or_touching] = CenterState.OUTSIDE_WORKSPACE
        return states

    def classify(self, point: Point) -> CenterState:
        return CenterState(self.classify_points(point.x, point.y).item())

    def classify_exact(self, point: Point) -> CenterState:
        """Classify the supplied numbers exactly, before any slice endpoint rounding."""
        x, y = Fraction(point.x), Fraction(point.y)
        radius, tolerance = Fraction(self.disk.radius), Fraction(self.tolerance)
        lower, upper = radius - tolerance, radius + tolerance
        wall = -max(_exact_gaps(self.workspace.bounds, x, y))
        if wall < lower:
            return CenterState.OUTSIDE_WORKSPACE
        contact = wall <= upper
        for obstacle in self.workspace.rectangles:
            dx, dy = _exact_gaps(obstacle, x, y)
            if _exact_offset_compare(dx, dy, lower) < 0:
                return CenterState.OBSTACLE_OVERLAP
            contact |= _exact_offset_compare(dx, dy, upper) <= 0
        return CenterState.CONTACT if contact else CenterState.FREE

    def boundary_diagnostic(self, point: Point) -> BoundaryDiagnostic:
        """Flag points whose compatibility classification depends on rounding."""
        return BoundaryDiagnostic(self.classify(point), self.classify_exact(point))

    def is_legal(self, point: Point, *, allow_contact: bool = False, exact: bool = False) -> bool:
        state = self.classify_exact(point) if exact else self.classify(point)
        if not exact and allow_contact and state is CenterState.CONTACT:
            state = self.classify_exact(point)
        return state is CenterState.FREE or (allow_contact and state is CenterState.CONTACT)

    def horizontal_free_intervals(self, y: float) -> tuple[tuple[float, float], ...]:
        """Return open x intervals of strictly feasible centers at height y."""
        if not isfinite(y):
            raise ValueError("y must be finite.")
        if self.strict_bounds is None or not self.strict_bounds.ymin < y < self.strict_bounds.ymax:
            return ()

        bounds = self.strict_bounds
        blocked = [obstacle.horizontal_span(y) for obstacle in self.strict_obstacles]
        intervals = []
        cursor = bounds.xmin
        for start, end in sorted(span for span in blocked if span is not None):
            if end <= cursor:
                continue
            if start >= bounds.xmax:
                break
            if start > cursor:
                intervals.append((cursor, start))
            cursor = max(cursor, end)
            if cursor >= bounds.xmax:
                break
        if cursor < bounds.xmax:
            intervals.append((cursor, bounds.xmax))
        return tuple(intervals)
