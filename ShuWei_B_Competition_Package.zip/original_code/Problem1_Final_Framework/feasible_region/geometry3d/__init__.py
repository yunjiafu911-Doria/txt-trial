"""General three-dimensional geometry for teaching examples."""

from .angles import angle_in_interval, azimuth, elevation, horizontal_distance
from .geometry import AxisAlignedBox, BoxIntersection, Point3D, Segment3D, segment_box_intersection

__all__ = [
    "Point3D", "Segment3D", "AxisAlignedBox", "BoxIntersection", "segment_box_intersection",
    "horizontal_distance", "azimuth", "elevation", "angle_in_interval",
]
