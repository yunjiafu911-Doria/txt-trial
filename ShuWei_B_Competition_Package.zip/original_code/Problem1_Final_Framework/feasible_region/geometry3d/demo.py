"""Draw three segment–box relationships using a seeded synthetic scene."""

import argparse
from collections.abc import Sequence
from pathlib import Path
from random import Random
from typing import TYPE_CHECKING

from .geometry import AxisAlignedBox, BoxIntersection, Point3D, Segment3D, segment_box_intersection

if TYPE_CHECKING:
    from matplotlib.figure import Figure


def generate_scene(seed: int) -> tuple[AxisAlignedBox, tuple[Segment3D, ...]]:
    """Randomize the box and segment endpoints while covering all three relations."""
    rng = Random(seed)
    x0, y0, z0 = (rng.uniform(-2, 0) for _ in range(3))
    width, depth, height = (rng.uniform(2.3, 3.8) for _ in range(3))
    x1, y1, z1 = x0 + width, y0 + depth, z0 + height
    box = AxisAlignedBox(Point3D(x0, y0, z0), Point3D(x1, y1, z1))
    left, right = x0 - rng.uniform(0.7, 1.2), x1 + rng.uniform(0.7, 1.2)
    outside_y = y0 - rng.uniform(0.45, 0.9)
    inside_y0 = y0 + rng.uniform(0.2, 0.45) * depth
    inside_y1 = y0 + rng.uniform(0.55, 0.8) * depth
    lower_z = z0 + rng.uniform(0.15, 0.4) * height
    upper_z = z0 + rng.uniform(0.6, 0.85) * height

    segments = (
        Segment3D(Point3D(left, outside_y, lower_z), Point3D(right, outside_y, upper_z)),
        Segment3D(Point3D(left, inside_y0, lower_z), Point3D(right, inside_y1, upper_z)),
        Segment3D(Point3D(left, y0, z1), Point3D(right, y0, z1)),
    )
    return box, segments


def _box_faces(box: AxisAlignedBox) -> list[list[tuple[float, float, float]]]:
    x0, y0, z0 = box.minimum.coordinates
    x1, y1, z1 = box.maximum.coordinates
    vertices = (
        (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
        (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
    )
    faces = (
        (0, 1, 2, 3), (4, 5, 6, 7), (0, 1, 5, 4),
        (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7),
    )
    return [[vertices[index] for index in face] for face in faces]


def plot_scene(box: AxisAlignedBox, segments: Sequence[Segment3D], *, seed: int) -> "Figure":
    from matplotlib import pyplot as plt
    from matplotlib.ticker import MaxNLocator
    from mpl_toolkits.mplot3d.art3d import Poly3DCollection

    if not segments:
        raise ValueError("Provide at least one segment to plot.")

    styles = {
        BoxIntersection.DISJOINT: ("Disjoint", "#3c5876"),
        BoxIntersection.INTERIOR: ("Intersects the interior", "#057269"),
        BoxIntersection.TOUCH: ("Boundary contact", "#a75020"),
    }
    coordinates = [box.minimum.coordinates, box.maximum.coordinates]
    coordinates.extend(point.coordinates for segment in segments for point in (segment.start, segment.end))
    limits = []
    for values in zip(*coordinates):
        lower, upper = min(values), max(values)
        margin = 0.06 * (upper - lower)
        limits.append((lower - margin, upper + margin))
    xlim, ylim, zlim = limits
    aspect = tuple(upper - lower for lower, upper in limits)

    figure, axes = plt.subplots(
        1, len(segments), squeeze=False, figsize=(4.1 * len(segments), 4.4),
        subplot_kw={"projection": "3d", "computed_zorder": False},
    )
    figure.subplots_adjust(left=0.03, right=0.93, bottom=0.07, top=0.87, wspace=0.1)
    faces = _box_faces(box)
    for axis, segment in zip(axes[0], segments):
        title, color = styles[segment_box_intersection(segment, box)]
        axis.add_collection3d(Poly3DCollection(
            faces, facecolor=(0.33, 0.56, 0.70, 0.14), edgecolor="#708b9f",
            linewidth=0.8, zorder=2,
        ))
        axis.plot(
            (segment.start.x, segment.end.x), (segment.start.y, segment.end.y),
            (segment.start.z, segment.end.z), marker="o", color=color,
            linewidth=2.6, markersize=4.5, zorder=4,
        )
        axis.set(
            xlim=xlim, ylim=ylim, zlim=zlim,
            xlabel="x", ylabel="y", zlabel="z", title=title,
        )
        axis.title.set_color(color)
        axis.title.set_fontweight("bold")
        for direction in (axis.xaxis, axis.yaxis, axis.zaxis):
            direction.set_major_locator(MaxNLocator(nbins=5))
        axis.set_box_aspect(aspect)
        axis.view_init(elev=25, azim=-59)
    figure.suptitle(f"Segment and axis-aligned box · synthetic scene, seed {seed}")
    return figure


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", type=Path, default=Path("geometry3d_scene.png"))
    args = parser.parse_args()

    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    box, segments = generate_scene(args.seed)
    figure = plot_scene(box, segments, seed=args.seed)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    figure.savefig(args.output, dpi=220)
    plt.close(figure)
    print("Scene classifications:", ", ".join(segment_box_intersection(s, box).value for s in segments))
    print(f"Saved PNG: {args.output.resolve()}")


if __name__ == "__main__":
    main()
