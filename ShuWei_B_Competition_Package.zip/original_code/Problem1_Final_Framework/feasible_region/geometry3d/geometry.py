"""Exact slab clipping for straight segments and axis-aligned boxes."""

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from math import isfinite


def _require_finite(value: float, name: str) -> None:
    if (
        isinstance(value, bool)
        or not isinstance(value, (int, float))
        or (isinstance(value, float) and not isfinite(value))
    ):
        raise ValueError(f"{name} must be an integer or a finite float.")


@dataclass(frozen=True, slots=True)
class Point3D:
    x: float
    y: float
    z: float

    def __post_init__(self) -> None:
        for name, value in zip(("x", "y", "z"), self.coordinates):
            _require_finite(value, name)

    @property
    def coordinates(self) -> tuple[float, float, float]:
        return self.x, self.y, self.z


@dataclass(frozen=True, slots=True)
class Segment3D:
    start: Point3D
    end: Point3D


@dataclass(frozen=True, slots=True)
class AxisAlignedBox:
    minimum: Point3D
    maximum: Point3D

    def __post_init__(self) -> None:
        if any(lower >= upper for lower, upper in zip(self.minimum.coordinates, self.maximum.coordinates)):
            raise ValueError("The box must have positive extent along every axis.")


class BoxIntersection(Enum):
    DISJOINT = "disjoint"
    INTERIOR = "interior"
    TOUCH = "touch"


ExactPoint = tuple[Fraction, Fraction, Fraction]
ExactBounds = tuple[tuple[Fraction, Fraction], ...]


def _exact_coordinates(point: Point3D) -> ExactPoint:
    return Fraction(point.x), Fraction(point.y), Fraction(point.z)


def _direction(start: ExactPoint, end: ExactPoint) -> ExactPoint:
    ax, ay, az = start
    bx, by, bz = end
    return bx - ax, by - ay, bz - az


def _offset_bounds(box: AxisAlignedBox, offset: Fraction) -> ExactBounds:
    return tuple(
        (Fraction(lower) - offset, Fraction(upper) + offset)
        for lower, upper in zip(box.minimum.coordinates, box.maximum.coordinates)
    )


def _clip(
    start: ExactPoint, direction: ExactPoint, bounds: ExactBounds
) -> tuple[Fraction, Fraction] | None:
    """Intersect per-axis parameter intervals with the closed segment interval."""
    entry, exit = Fraction(0), Fraction(1)
    for origin, component, (lower, upper) in zip(start, direction, bounds):
        if component == 0:
            if not lower <= origin <= upper:
                return None
            continue

        first, last = sorted(((lower - origin) / component, (upper - origin) / component))
        entry, exit = max(entry, first), min(exit, last)
        if entry > exit:
            return None
    return entry, exit


def segment_box_intersection(
    segment: Segment3D, box: AxisAlignedBox, *, tolerance: float = 0.0
) -> BoxIntersection:
    """Classify meeting the box interior, its boundary, or neither.

    The tolerance expands the closed box and shrinks the open interior by
    that distance on every face. The region between them counts as contact.
    """
    _require_finite(tolerance, "tolerance")
    if tolerance < 0:
        raise ValueError("tolerance must be nonnegative.")

    padding = Fraction(tolerance)
    start = _exact_coordinates(segment.start)
    direction = _direction(start, _exact_coordinates(segment.end))
    outer_bounds = _offset_bounds(box, padding)
    outer_interval = _clip(start, direction, outer_bounds)
    if outer_interval is None:
        return BoxIntersection.DISJOINT

    if padding == 0:
        inner_bounds, inner_interval = outer_bounds, outer_interval
    else:
        inner_bounds = _offset_bounds(box, -padding)
        if any(lower >= upper for lower, upper in inner_bounds):
            return BoxIntersection.TOUCH
        inner_interval = _clip(start, direction, inner_bounds)
        if inner_interval is None:
            return BoxIntersection.TOUCH

    # A midpoint test separates interior overlap from sliding on a face or an edge.
    middle = (inner_interval[0] + inner_interval[1]) / 2
    if all(
        lower < origin + middle * component < upper
        for origin, component, (lower, upper) in zip(start, direction, inner_bounds)
    ):
        return BoxIntersection.INTERIOR
    return BoxIntersection.TOUCH
