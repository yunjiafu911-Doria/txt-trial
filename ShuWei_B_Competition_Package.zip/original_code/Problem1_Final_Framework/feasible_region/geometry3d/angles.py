"""Distances, direction angles in degrees, and linear or periodic angle intervals."""

from fractions import Fraction
from math import atan2, degrees, hypot, inf

from .geometry import Point3D, _direction, _exact_coordinates, _require_finite


def horizontal_distance(start: Point3D, end: Point3D) -> float:
    """Return the Euclidean distance between the projections onto the xy-plane."""
    dx, dy, _ = _direction(_exact_coordinates(start), _exact_coordinates(end))
    try:
        return hypot(float(dx), float(dy))
    except OverflowError:
        return inf


def azimuth(start: Point3D, end: Point3D) -> float:
    """Return the counterclockwise angle from +x in [0, 360) degrees."""
    dx, dy, _ = _direction(_exact_coordinates(start), _exact_coordinates(end))
    scale = max(abs(dx), abs(dy))
    if scale == 0:
        raise ValueError("Azimuth requires a nonzero horizontal displacement.")
    angle = degrees(atan2(float(dy / scale), float(dx / scale))) % 360.0
    return 0.0 if angle == 360.0 else angle


def elevation(start: Point3D, end: Point3D) -> float:
    """Return the signed angle above the xy-plane in [-90, 90] degrees."""
    dx, dy, dz = _direction(_exact_coordinates(start), _exact_coordinates(end))
    scale = max(abs(dx), abs(dy), abs(dz))
    if scale == 0:
        raise ValueError("Elevation requires distinct points.")
    horizontal = hypot(float(dx / scale), float(dy / scale))
    return degrees(atan2(float(dz / scale), horizontal))


def angle_in_interval(
    angle: float,
    lower: float,
    upper: float,
    *,
    period: float | None = None,
    tolerance: float = 0.0,
) -> bool:
    """Test a closed interval, optionally following increasing angle around a period."""
    for name, value in (("angle", angle), ("lower", lower), ("upper", upper), ("tolerance", tolerance)):
        _require_finite(value, name)
    if tolerance < 0:
        raise ValueError("tolerance must be nonnegative.")

    value, start, end, padding = map(Fraction, (angle, lower, upper, tolerance))
    if period is None:
        if start > end:
            raise ValueError("A nonperiodic interval requires lower <= upper.")
        return start - padding <= value <= end + padding

    _require_finite(period, "period")
    if period <= 0:
        raise ValueError("period must be positive.")

    cycle = Fraction(period)
    if abs(end - start) >= cycle:
        return True
    span = (end - start) % cycle
    offset = (value - start) % cycle
    return offset <= span + padding or offset >= cycle - padding
