import matplotlib
import pytest

from feasible_region.geometry3d import BoxIntersection, segment_box_intersection
from feasible_region.geometry3d.demo import generate_scene, plot_scene


@pytest.mark.parametrize("seed", [0, 42, 810])
def test_scene_seed_reproducibility_and_relationship_coverage(seed):
    box, segments = generate_scene(seed)
    assert (box, segments) == generate_scene(seed)
    assert (box, segments) != generate_scene(seed + 1)
    assert [segment_box_intersection(segment, box) for segment in segments] == [
        BoxIntersection.DISJOINT, BoxIntersection.INTERIOR, BoxIntersection.TOUCH,
    ]


def test_plot_has_three_3d_panels_and_exports_png(tmp_path):
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    box, segments = generate_scene(42)
    figure = plot_scene(box, segments, seed=42)
    try:
        assert [axis.name for axis in figure.axes] == ["3d", "3d", "3d"]
        assert [axis.get_title() for axis in figure.axes] == [
            "Disjoint", "Intersects the interior", "Boundary contact",
        ]
        destination = tmp_path / "scene.png"
        figure.savefig(destination)
        assert destination.read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
    finally:
        plt.close(figure)
