from math import inf, nan, nextafter

import pytest

from feasible_region.geometry3d import (
    AxisAlignedBox,
    BoxIntersection,
    Point3D,
    Segment3D,
    angle_in_interval,
    azimuth,
    elevation,
    horizontal_distance,
    segment_box_intersection,
)


BOX = AxisAlignedBox(Point3D(0, 0, 0), Point3D(4, 4, 4))


@pytest.mark.parametrize(
    ("start", "end", "expected"),
    [
        ((-2, 5, 2), (6, 5, 2), BoxIntersection.DISJOINT),
        ((-2, 2, 2), (6, 2, 2), BoxIntersection.INTERIOR),
        ((-2, 0, 2), (6, 0, 2), BoxIntersection.TOUCH),
        ((-2, 0, 4), (6, 0, 4), BoxIntersection.TOUCH),
        ((-2, 0, 5), (6, 0, 5), BoxIntersection.DISJOINT),
        ((-2, 2, 2), (0, 2, 2), BoxIntersection.TOUCH),
        ((-1, -1, 2), (0, 0, 2), BoxIntersection.TOUCH),
        ((-1, -1, -1), (0, 0, 0), BoxIntersection.TOUCH),
        ((-1, 1, 0), (1, -1, 0), BoxIntersection.TOUCH),
        ((-1, -1, -1), (5, 5, 5), BoxIntersection.INTERIOR),
        ((0, 0, 0), (1, 1, 1), BoxIntersection.INTERIOR),
        ((1, 1, 1), (3, 3, 3), BoxIntersection.INTERIOR),
        ((2, 2, 2), (2, 2, 2), BoxIntersection.INTERIOR),
        ((0, 2, 2), (0, 2, 2), BoxIntersection.TOUCH),
        ((4, 4, 4), (4, 4, 4), BoxIntersection.TOUCH),
        ((5, 0, 0), (5, 0, 0), BoxIntersection.DISJOINT),
        ((5, 2, 2), (6, 2, 2), BoxIntersection.DISJOINT),
    ],
)
def test_segment_box_classifications_in_both_directions(start, end, expected):
    a, b = Point3D(*start), Point3D(*end)
    assert segment_box_intersection(Segment3D(a, b), BOX) is expected
    assert segment_box_intersection(Segment3D(b, a), BOX) is expected


@pytest.mark.parametrize(
    ("y", "expected"),
    [
        (-0.25, BoxIntersection.DISJOINT),
        (-0.125, BoxIntersection.TOUCH),
        (0.0, BoxIntersection.TOUCH),
        (0.125, BoxIntersection.TOUCH),
        (0.25, BoxIntersection.INTERIOR),
    ],
)
def test_tolerance_expands_outer_box_and_shrinks_inner_box(y, expected):
    segment = Segment3D(Point3D(-1, y, 2), Point3D(5, y, 2))
    assert segment_box_intersection(segment, BOX, tolerance=0.125) is expected


def test_inner_extent_can_collapse_when_tolerance_is_large():
    segment = Segment3D(Point3D(-1, 2, 2), Point3D(5, 2, 2))
    assert segment_box_intersection(segment, BOX, tolerance=2) is BoxIntersection.TOUCH


def test_default_zero_tolerance_distinguishes_adjacent_floats():
    epsilon_inside = nextafter(0.0, inf)
    epsilon_outside = nextafter(0.0, -inf)
    for y, expected in ((epsilon_inside, BoxIntersection.INTERIOR), (epsilon_outside, BoxIntersection.DISJOINT)):
        segment = Segment3D(Point3D(-1, y, 2), Point3D(5, y, 2))
        assert segment_box_intersection(segment, BOX) is expected


def test_exact_integer_intersection_with_large_coordinate_offset():
    offset = 10**30
    box = AxisAlignedBox(Point3D(offset, offset, offset), Point3D(offset + 4, offset + 4, offset + 4))
    segment = Segment3D(Point3D(offset - 1, offset + 2, offset + 2), Point3D(offset + 5, offset + 2, offset + 2))
    assert segment_box_intersection(segment, box) is BoxIntersection.INTERIOR
    assert horizontal_distance(segment.start, segment.end) == 6


@pytest.mark.parametrize("tolerance", [-1, inf, nan, True])
def test_invalid_intersection_tolerance(tolerance):
    with pytest.raises(ValueError, match="tolerance"):
        segment_box_intersection(Segment3D(Point3D(0, 0, 0), Point3D(1, 1, 1)), BOX, tolerance=tolerance)


@pytest.mark.parametrize("bad_coordinate", [inf, -inf, nan, 1j, True])
def test_invalid_point_coordinate(bad_coordinate):
    with pytest.raises(ValueError, match="finite"):
        Point3D(0, bad_coordinate, 0)


@pytest.mark.parametrize("maximum", [Point3D(0, 4, 4), Point3D(4, -1, 4), Point3D(4, 4, 0)])
def test_box_requires_positive_extent(maximum):
    with pytest.raises(ValueError, match="positive extent"):
        AxisAlignedBox(Point3D(0, 0, 0), maximum)


@pytest.mark.parametrize(
    ("direction", "expected"),
    [((1, 0, 2), 0), ((0, 1, 0), 90), ((-1, 0, -5), 180), ((0, -1, 0), 270), ((1, -1, 1), 315)],
)
def test_azimuth_cardinal_and_clockwise_directions(direction, expected):
    assert azimuth(Point3D(0, 0, 0), Point3D(*direction)) == pytest.approx(expected)


def test_horizontal_distance_and_elevation_ignore_vertical_for_planar_length_only():
    origin = Point3D(1, 2, 3)
    high = Point3D(4, 6, 8)
    assert horizontal_distance(origin, high) == 5
    assert elevation(origin, high) == pytest.approx(45)
    assert elevation(high, origin) == pytest.approx(-45)
    assert elevation(origin, Point3D(4, 6, 3)) == 0


def test_vertical_and_coincident_directions():
    origin, top = Point3D(1, 2, 1), Point3D(1, 2, 4)
    assert horizontal_distance(origin, top) == 0
    assert elevation(origin, top) == 90
    assert elevation(top, origin) == -90
    with pytest.raises(ValueError, match="horizontal displacement"):
        azimuth(origin, top)
    with pytest.raises(ValueError, match="distinct"):
        elevation(origin, origin)


def test_direction_angles_stay_finite_when_coordinate_difference_overflows():
    first, second = Point3D(-1e308, -1.3e308, 0), Point3D(1e308, 0.7e308, 1e308)
    assert horizontal_distance(first, second) == inf
    assert azimuth(first, second) == pytest.approx(45)
    assert elevation(first, second) == pytest.approx(19.4712206345)


@pytest.mark.parametrize(
    ("value", "expected"),
    [(350, True), (359, True), (0, True), (15, True), (375, True), (16, False), (180, False)],
)
def test_periodic_interval_crosses_zero_and_includes_both_endpoints(value, expected):
    assert angle_in_interval(value, 350, 15, period=360) is expected


def test_linear_interval_endpoints_and_tolerance():
    assert angle_in_interval(-25, -25, 60)
    assert angle_in_interval(60, -25, 60)
    assert not angle_in_interval(-25.125, -25, 60)
    assert angle_in_interval(-25.125, -25, 60, tolerance=0.125)


def test_periodic_tolerance_extends_both_sides():
    assert angle_in_interval(349.5, 350, 15, period=360, tolerance=0.5)
    assert angle_in_interval(15.5, 350, 15, period=360, tolerance=0.5)
    assert not angle_in_interval(349.499, 350, 15, period=360, tolerance=0.5)


def test_full_turn_singleton_and_non_degree_period():
    assert angle_in_interval(180, 5, 365, period=360)
    assert angle_in_interval(370, 10, 10, period=360)
    assert not angle_in_interval(180, 10, 10, period=360)
    assert angle_in_interval(0.125, 0.75, 0.25, period=1.0)


@pytest.mark.parametrize("period", [0, -1, inf])
def test_invalid_period(period):
    with pytest.raises(ValueError, match="period"):
        angle_in_interval(0, 1, 3, period=period)


def test_reversed_linear_bounds_and_invalid_angle():
    with pytest.raises(ValueError, match="lower <= upper"):
        angle_in_interval(0, 5, 1)
    with pytest.raises(ValueError, match="finite"):
        angle_in_interval(nan, 1, 5)
