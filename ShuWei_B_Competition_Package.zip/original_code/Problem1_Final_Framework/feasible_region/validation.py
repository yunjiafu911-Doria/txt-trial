"""Produce and validate the complete synthetic project outputs."""

import csv
from pathlib import Path
from statistics import median

from .constraint_analysis.experiment import boundary_probes, clipped_disk_study, run_resolution_study
from .constraint_analysis.reporting import plot_study, write_grid, write_rows
from .workflow import run_examples


def _read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def run_full(output_dir: str | Path, *, seed: int = 42) -> dict[str, Path]:
    """Regenerate all integration and numerical validation outputs."""
    import matplotlib
    from matplotlib import pyplot as plt

    destination = Path(output_dir)
    artifacts = run_examples(destination, seed=seed)
    planar = _read_csv(artifacts["constraints_2d.csv"])
    spatial = _read_csv(artifacts["geometry_3d.csv"])
    accepted = {row["sample_id"] for row in planar if row["included"] == "1"}
    relations = [row["segment_box_state"] for row in spatial]
    midpoint_states = [row["midpoint_intersection_state"] for row in spatial]
    if len(planar) != 7 or accepted != {"interior", "closed_cut"}:
        raise RuntimeError("The planar example no longer matches its boundary acceptance checks.")
    if relations != ["disjoint", "interior", "touch"] or midpoint_states != [
        "outside", "interior", "closed_boundary",
    ]:
        raise RuntimeError("The spatial example no longer matches its synthetic cases.")

    study = clipped_disk_study()
    rows, grid = run_resolution_study(study)
    probes = boundary_probes(study)
    disagreements = sum(row.sample_disagreements for row in rows)
    if disagreements:
        raise RuntimeError(f"The grid and analytic sections disagreed at {disagreements} samples.")

    nominal_probes = {probe.reference: probe.feasible for probe in probes
                      if probe.tolerance == 0 and probe.perturbation_x == 0}
    if nominal_probes != {"open_cut": False, "closed_arc": True, "joint_contact": False}:
        raise RuntimeError("The nominal open/closed boundary probe checks failed.")

    numerical = {name: destination / name for name in (
        "resolution_experiment.csv", "boundary_probes.csv", "grid_comparison.csv",
        "constraint_comparison.png", "constraint_comparison.pdf", "VALIDATION.md",
    )}
    write_rows(rows, numerical["resolution_experiment.csv"])
    write_rows(probes, numerical["boundary_probes.csv"])
    write_grid(study, grid, numerical["grid_comparison.csv"])
    with matplotlib.rc_context({"pdf.fonttype": 42, "savefig.facecolor": "white"}):
        figure = plot_study(study, grid, rows)
        try:
            figure.savefig(numerical["constraint_comparison.png"], dpi=350)
            figure.savefig(numerical["constraint_comparison.pdf"])
        finally:
            plt.close(figure)

    levels = sorted({row.resolution for row in rows})
    statistics = []
    for resolution in levels:
        errors = [row.relative_error_percent for row in rows if row.resolution == resolution]
        statistics.append(f"| {resolution} | {min(errors):.4f}% | {max(errors):.4f}% | {median(map(abs, errors)):.4f}% |")
    table = "\n".join(statistics)
    sample_count = sum(row.resolution**2 for row in rows)
    report = f"""# 合成场景验收与数值验证

三维示例使用随机种子 `{seed}`。二维净空和分辨率实验使用固定的合成几何场景，坐标长度单位任意。

## 集成判定

| 检查 | 实际结果 |
| --- | --- |
| 二维净空与窗口交集 | {len(planar)} 个样本，接受 {len(accepted)} 个。开边界、场地接触和障碍接触被排除，窗口闭边界内的净空样本被接受。 |
| 三维线段与长方体 | {len(spatial)} 个案例依次为不相交、进入内部、边界接触，均记录水平距离、方位角、俯仰角和角度区间判定。 |
| 三维中点约束交集 | 依次为外部、内部、闭边界接触。 |
| 解析横截面对照 | {len(rows)} 组网格和 {sample_count:,} 个采样点，逐点判定分歧数为 {disagreements}。 |
| 开闭边界探针 | {len(probes)} 行记录。零扰动和零容差下接受闭圆弧上的点，排除开裁切线与联合接触点。 |

## 网格分辨率与面积误差

解析参考面积为 **{study.exact_area:.10f}** 平方坐标单位。每个分辨率使用五个固定的采样偏移。相对误差为 `100 × (估算面积 − 参考面积) / 参考面积`。

| 每轴网格数 | 最小有符号误差 | 最大有符号误差 | 绝对相对误差中位数 |
| ---: | ---: | ---: | ---: |
{table}

逐点判定一致时，网格面积仍受到格子跨越曲线或裁切线的影响。加密后误差通常减小，部分分辨率会出现反弹。

## 对应文件

- [二维判定](constraints_2d.csv) · [三维几何](geometry_3d.csv)
- [分辨率实验](resolution_experiment.csv) · [容差探针](boundary_probes.csv) · [采样点对照](grid_comparison.csv)
- [二维示意图](scene_2d.png) · [三维示意图](scene_3d.png) · [数值对照图](constraint_comparison.pdf)
"""
    numerical["VALIDATION.md"].write_text(report, encoding="utf-8", newline="\n")
    return artifacts | numerical
