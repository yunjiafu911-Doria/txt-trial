"""Exact predicates for points, segments, and axis-aligned rectangles."""

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from math import isfinite


class PointLocation(Enum):
    OUTSIDE = "outside"
    BOUNDARY = "boundary"
    INSIDE = "inside"


class SegmentIntersection(Enum):
    DISJOINT = "disjoint"
    TOUCH = "touch"
    CROSS = "cross"
    OVERLAP = "overlap"


class SegmentRectangleRelation(Enum):
    DISJOINT = "disjoint"
    TOUCH = "touch"
    CROSS = "cross"
    OVERLAP = "overlap"
    INSIDE = "inside"


def _validate_coordinates(*values: float) -> None:
    for value in values:
        if isinstance(value, int):
            continue
        if not isinstance(value, float) or not isfinite(value):
            raise ValueError("Coordinates must be integers or finite floats.")


@dataclass(frozen=True, slots=True)
class Point2D:
    x: float
    y: float

    def __post_init__(self) -> None:
        _validate_coordinates(self.x, self.y)


@dataclass(frozen=True, slots=True)
class Rectangle:
    """An axis-aligned rectangle with positive width and height."""

    xmin: float
    ymin: float
    xmax: float
    ymax: float

    def __post_init__(self) -> None:
        _validate_coordinates(self.xmin, self.ymin, self.xmax, self.ymax)
        if self.xmin >= self.xmax or self.ymin >= self.ymax:
            raise ValueError("A rectangle must have positive width and height.")

    def locate(self, point: Point2D) -> PointLocation:
        """Classify a point against the closed rectangle."""
        if not (self.xmin <= point.x <= self.xmax and self.ymin <= point.y <= self.ymax):
            return PointLocation.OUTSIDE
        if self.xmin < point.x < self.xmax and self.ymin < point.y < self.ymax:
            return PointLocation.INSIDE
        return PointLocation.BOUNDARY

    def is_on_boundary(self, point: Point2D) -> bool:
        return self.locate(point) is PointLocation.BOUNDARY


@dataclass(frozen=True, slots=True)
class Workspace:
    """A rectangular canvas and the rectangles it contains."""

    bounds: Rectangle
    rectangles: tuple[Rectangle, ...] = ()

    def __post_init__(self) -> None:
        rectangles = tuple(self.rectangles)
        for rectangle in rectangles:
            if not (
                self.bounds.xmin <= rectangle.xmin <= rectangle.xmax <= self.bounds.xmax
                and self.bounds.ymin <= rectangle.ymin <= rectangle.ymax <= self.bounds.ymax
            ):
                raise ValueError("All rectangles must be within the workspace bounds.")
        object.__setattr__(self, "rectangles", rectangles)


def _orientation(a: Point2D, b: Point2D, c: Point2D) -> int:
    """Return +1 for a left turn, -1 for a right turn, and 0 for collinearity."""
    ax, ay = Fraction(a.x), Fraction(a.y)
    ab_x, ab_y = Fraction(b.x) - ax, Fraction(b.y) - ay
    ac_x, ac_y = Fraction(c.x) - ax, Fraction(c.y) - ay
    determinant = ab_x * ac_y - ab_y * ac_x
    return (determinant > 0) - (determinant < 0)


def _in_segment_bounds(point: Point2D, start: Point2D, end: Point2D) -> bool:
    return (
        min(start.x, end.x) <= point.x <= max(start.x, end.x)
        and min(start.y, end.y) <= point.y <= max(start.y, end.y)
    )


def point_on_segment(point: Point2D, start: Point2D, end: Point2D) -> bool:
    """Return whether the closed segment contains the point."""
    return _in_segment_bounds(point, start, end) and _orientation(start, end, point) == 0


def segment_intersection(
    a: Point2D, b: Point2D, c: Point2D, d: Point2D
) -> SegmentIntersection:
    """Classify the intersection of closed segments AB and CD."""
    abc = _orientation(a, b, c)
    abd = _orientation(a, b, d)
    cda = _orientation(c, d, a)
    cdb = _orientation(c, d, b)

    if abc == abd == cda == cdb == 0:
        # Lexicographic order is monotone along any line, including vertical lines.
        ab_start, ab_end = sorted(((a.x, a.y), (b.x, b.y)))
        cd_start, cd_end = sorted(((c.x, c.y), (d.x, d.y)))
        first, last = max(ab_start, cd_start), min(ab_end, cd_end)
        if first > last:
            return SegmentIntersection.DISJOINT
        if first == last:
            return SegmentIntersection.TOUCH
        return SegmentIntersection.OVERLAP

    if abc * abd < 0 and cda * cdb < 0:
        return SegmentIntersection.CROSS
    if (
        (abc == 0 and _in_segment_bounds(c, a, b))
        or (abd == 0 and _in_segment_bounds(d, a, b))
        or (cda == 0 and _in_segment_bounds(a, c, d))
        or (cdb == 0 and _in_segment_bounds(b, c, d))
    ):
        return SegmentIntersection.TOUCH
    return SegmentIntersection.DISJOINT


def segment_rectangle_relation(
    start: Point2D, end: Point2D, rectangle: Rectangle
) -> SegmentRectangleRelation:
    """Classify a closed segment relative to a rectangle and its boundary."""
    if rectangle.locate(start) is PointLocation.INSIDE and rectangle.locate(end) is PointLocation.INSIDE:
        return SegmentRectangleRelation.INSIDE

    # Clip the parameter t in start + t * (end - start) to each axis interval.
    x, y = Fraction(start.x), Fraction(start.y)
    dx, dy = Fraction(end.x) - x, Fraction(end.y) - y
    lower, upper = Fraction(0), Fraction(1)
    for origin, direction, minimum, maximum in (
        (x, dx, rectangle.xmin, rectangle.xmax),
        (y, dy, rectangle.ymin, rectangle.ymax),
    ):
        if direction == 0:
            if not minimum <= origin <= maximum:
                return SegmentRectangleRelation.DISJOINT
            continue
        entry, exit = sorted(
            ((Fraction(minimum) - origin) / direction, (Fraction(maximum) - origin) / direction)
        )
        lower, upper = max(lower, entry), min(upper, exit)
        if lower > upper:
            return SegmentRectangleRelation.DISJOINT

    if lower == upper or start == end:
        return SegmentRectangleRelation.TOUCH
    midpoint = (lower + upper) / 2
    middle_x, middle_y = x + midpoint * dx, y + midpoint * dy
    if rectangle.xmin < middle_x < rectangle.xmax and rectangle.ymin < middle_y < rectangle.ymax:
        return SegmentRectangleRelation.CROSS
    return SegmentRectangleRelation.OVERLAP
