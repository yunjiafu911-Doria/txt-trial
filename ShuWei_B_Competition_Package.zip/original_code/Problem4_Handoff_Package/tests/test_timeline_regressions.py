import pytest

from scheduler_sim.models import Resource, Task
from src.problem4_rescheduling.experiment import check_timeline, timeline
from src.problem4_rescheduling.model import Scenario, initial_plan, replay


@pytest.fixture
def interrupted_case():
    resources = (Resource("W", "worker"), Resource("Q", "quality"))
    tasks = (Task("A", 0, 10, ("worker", "quality")), Task("B", 5, 3, ("quality",)))
    plan = initial_plan(tasks, resources)
    scenario = Scenario("fault", failed="W")
    records = replay(plan, scenario, "dynamic", tasks=tasks, resources=resources)
    events = timeline(plan, records, tasks, scenario, "dynamic", 60)
    check_timeline(events, records)
    return events, records


@pytest.mark.parametrize(("event", "job", "change", "message"), [
    ("task_interrupt", "A", {"event": "task_finish"}, "terminal event kind"),
    ("task_finish", "B", {"event": "task_interrupt"}, "terminal event kind"),
    ("dispatch", "A", {"resource_ids": "W"}, "Invalid dispatch"),
    ("resource_failure", "", {"resource_ids": "unused"}, "no matching resource failure"),
    ("resource_released", "A", {"time_s": 6}, "Invalid resource release time"),
    ("task_start", "A", {"resource_ids": ""}, "commanded resource set"),
    ("initial_plan", "", {"event": "undefined"}, "Unknown event kind"),
    ("initial_plan", "", {"time_s": float("nan")}, "nonnegative integer"),
])
def test_mutated_ledger_is_rejected(interrupted_case, event, job, change, message):
    events, records = interrupted_case
    index = next(i for i, row in enumerate(events) if row["event"] == event and row["task_id"] == job)
    negative = list(events)
    negative[index] = dict(negative[index], **change)
    with pytest.raises(AssertionError, match=message):
        check_timeline(negative, records)


def test_replay_rejects_an_unknown_failed_resource():
    with pytest.raises(ValueError, match="identifier is unknown"):
        replay((), Scenario("bad_input", failed="missing"), "dynamic")


def test_replay_rejects_new_task_with_duplicate_identity():
    tasks = (Task("A", 0, 10, ("worker",)),)
    scenario = Scenario("duplicate", new_task=Task("A", 5, 1, ("worker",)))
    with pytest.raises(ValueError, match="identifiers must be unique"):
        replay((), scenario, "dynamic", tasks=tasks)


