from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from scheduler_sim.models import Resource, Task, TaskRun
from problem4_rescheduling.audit import certify, check_schedule
from problem4_rescheduling.experiment import check_timeline, timeline
from problem4_rescheduling.model import Record, SCENARIOS, Scenario, initial_plan, metrics, replay


WORKERS = (Resource("worker1", "worker"),)


def task(name, release, duration):
    return Task(name, release, duration, ("worker",))


def test_finish_at_event_precedes_failure_and_simultaneous_dispatch():
    jobs = (task("A", 0, 5), task("B", 5, 3))
    plan = initial_plan(jobs, WORKERS)
    scenario = Scenario("failure", at=5, failed="worker1")
    for policy in ("retain", "dynamic"):
        result = replay(plan, scenario, policy, tasks=jobs, resources=WORKERS)
        assert result == (Record(TaskRun("A", ("worker1",), 0, 5), 5),)
        assert check_schedule(result, jobs, WORKERS, plan, scenario, 60) == (1, 2, 60)
        events = timeline(plan, result, jobs, scenario, policy, 60)
        assert [event["event"] for event in events if event["time_s"] == 5][:3] == [
            "task_finish", "resource_released", "resource_failure",
        ]
        check_timeline(events, result)


def test_new_job_at_event_can_replace_a_not_yet_started_job():
    jobs = (task("A", 0, 5), task("B", 5, 7))
    newcomer = task("N", 5, 2)
    plan = initial_plan(jobs, WORKERS, horizon=7)
    scenario = Scenario("new", new_task=newcomer)
    retain = replay(plan, scenario, "retain", tasks=jobs, resources=WORKERS, horizon=7)
    dynamic = replay(plan, scenario, "dynamic", tasks=jobs, resources=WORKERS, horizon=7)
    assert [(entry.run.task_id, entry.run.start) for entry in retain] == [("A", 0), ("B", 5)]
    assert [(entry.run.task_id, entry.run.start) for entry in dynamic] == [("A", 0), ("N", 5), ("B", 7)]
    assert metrics(dynamic, (*jobs, newcomer), 7) == (3, 3, 7)


@pytest.mark.parametrize("policy", ["retain", "dynamic"])
def test_recovery_is_inclusive_and_started_work_continues(policy):
    jobs = (task("A", 0, 7), task("B", 5, 3))
    plan = initial_plan(jobs, WORKERS)
    scenario = Scenario("outage", at=5, recovery=9)
    records = replay(plan, scenario, policy, tasks=jobs, resources=WORKERS)
    assert [(record.run.task_id, record.run.start, record.effective_end) for record in records] == [
        ("A", 0, 7), ("B", 9, 12),
    ]
    events = timeline(plan, records, jobs, scenario, policy, 60)
    kinds = [event["event"] for event in events if event["time_s"] == 9]
    assert kinds.index("communication_recovered") < kinds.index("dispatch")
    check_timeline(events, records)
    forbidden = [dict(event) for event in events]
    command = next(event for event in forbidden if event["event"] == "dispatch" and event["task_id"] == "B")
    forbidden.remove(command)
    command["time_s"] = 8
    forbidden.insert(next(i for i, event in enumerate(forbidden) if event["time_s"] >= 9), command)
    with pytest.raises(AssertionError, match="Invalid dispatch"):
        check_timeline(forbidden, records)


def test_fault_during_service_keeps_start_and_blocks_reassignment():
    resources = (*WORKERS, Resource("quality1", "quality"))
    jobs = (Task("A", 0, 10, ("worker", "quality")), Task("B", 5, 3, ("quality",)))
    plan = initial_plan(jobs, resources)
    scenario = Scenario("busy_failure", failed="worker1")
    result = replay(plan, scenario, "dynamic", tasks=jobs, resources=resources)
    assert result[0].run == plan[0] and result[0].effective_end == 5
    assert result[0].interrupted and result[1].run.start == 10
    assert check_schedule(result, jobs, resources, plan, scenario, 60) == (2, 2, 10)
    check_timeline(timeline(plan, result, jobs, scenario, "dynamic", 60), result)


def test_exact_horizon_start_counts_even_if_finish_later():
    jobs = (task("A", 59, 1), task("B", 60, 2), task("C", 61, 1))
    plan = initial_plan(jobs, WORKERS)
    scenario = Scenario("late_outage", at=59, recovery=60)
    result = replay(plan, scenario, "dynamic", tasks=jobs, resources=WORKERS)
    assert len(result) == 1 and result[0].run.start == 60 and result[0].run.end > 60
    assert metrics(result, jobs) == (1, 2, 60)
    assert metrics(result, (jobs[0],)) == (1, 1, 60)


def test_no_eligible_resource_and_empty_snapshot():
    jobs = (Task("X", 0, 3, ("missing_kind",)),)
    record = replay((), Scenario("fault", failed="worker1"), "dynamic", tasks=jobs, resources=WORKERS)
    assert metrics(record, jobs) == (0, 1, 60)
    assert metrics((), ()) == (0, 0, 0)
    assert certify(jobs, (), (), 5, 60)[0] == (0, 1, 60)


def test_priority_selects_only_after_cardinality_and_latest():
    jobs = (task("A", 5, 6), task("B", 5, 2), task("C", 5, 2))
    # At most two jobs can initiate by 7. Starting the high-priority job first blocks the second.
    newcomer = task("N", 5, 9)
    scenario = Scenario("new", new_task=newcomer)
    result = replay((), scenario, "dynamic", tasks=jobs, resources=WORKERS, horizon=7,
                    priorities={"A": 99, "N": 200})
    assert [(r.run.task_id, r.run.start) for r in result] == [("B", 5), ("N", 7)]
    assert certify((*jobs, newcomer), WORKERS, (), 5, 7)[0] == (2, 4, 7)


def test_initial_commands_do_not_depend_on_future_scenario():
    plan = initial_plan()
    initial = tuple(run for run in plan if run.start < 5)
    assert initial
    for scenario in SCENARIOS:
        for policy in ("retain", "dynamic"):
            records = replay(plan, scenario, policy)
            assert tuple(entry.run for entry in records if entry.run.start < 5) == initial


def test_interval_checker_rejects_resource_overlap():
    jobs = (task("A", 0, 4), task("B", 1, 3))
    scenario = Scenario("no_disturbance", at=0)
    one = Record(TaskRun("A", ("worker1",), 0, 4), 4)
    two = Record(TaskRun("B", ("worker1",), 1, 4), 4)
    with pytest.raises(AssertionError, match="overlap"):
        check_schedule((one, two), jobs, WORKERS, (), scenario, 60)
