"""Replay a fixed schedule and plan a suffix from an observed snapshot."""

from collections import Counter
from dataclasses import dataclass
from itertools import combinations

from scheduler_sim.models import Resource, Task, TaskRun
from scheduler_sim.simulation import simulate


HORIZON = 60
RESOURCES = (Resource("W1", "worker"), Resource("W2", "worker"), Resource("Q", "quality"))
TASKS = (
    Task("A", 0, 5, ("worker",)), Task("B", 0, 22, ("worker",)), Task("C", 0, 16, ("quality",)),
    Task("D", 5, 28, ("worker", "quality")), Task("E", 8, 31, ("worker",)), Task("F", 12, 20, ("quality",)),
)
NEW_TASK = Task("G", 5, 15, ("worker", "quality"))
PRIORITY = {"D": 3, "G": 2}


@dataclass(frozen=True)
class Scenario:
    name: str
    at: int = 5
    new_task: Task | None = None
    failed: str | None = None
    recovery: int | None = None

    def __post_init__(self):
        if self.at < 0 or (self.recovery is not None and self.recovery <= self.at):
            raise ValueError("Recovery must follow a nonnegative disturbance time.")
        if self.new_task is not None and self.new_task.arrival != self.at:
            raise ValueError("The new task must be first observed at the disturbance time.")

    @property
    def disrupted(self):
        return self.new_task is not None or self.failed is not None or self.recovery is not None

    @property
    def decision_time(self):
        return self.at if self.recovery is None else self.recovery


SCENARIOS = (
    Scenario("none"), Scenario("new", new_task=NEW_TASK), Scenario("failure", failed="W1"),
    Scenario("outage", recovery=26), Scenario("new_failure", new_task=NEW_TASK, failed="W1"),
    Scenario("new_outage", new_task=NEW_TASK, recovery=26),
    Scenario("failure_outage", failed="W1", recovery=26),
    Scenario("all", new_task=NEW_TASK, failed="W1", recovery=26),
)


@dataclass(frozen=True)
class Record:
    run: TaskRun
    effective_end: int

    @property
    def interrupted(self):
        return self.effective_end < self.run.end


def metrics(records, tasks, horizon=HORIZON):
    n = sum(task.arrival <= horizon for task in tasks)
    k = sum(record.run.start <= horizon for record in records)
    latest = max((record.run.start for record in records if record.run.start <= horizon), default=0)
    return k, n, horizon if k < n else latest


def initial_plan(tasks=TASKS, resources=RESOURCES, horizon=HORIZON):
    # No scenario argument. New tasks and future faults are absent from this call.
    available = [task for task in tasks if task.arrival <= horizon]
    return tuple(run for run in simulate(resources, available, policy="spt").runs if run.start <= horizon)


def resource_bundles(task, resources):
    kinds = {resource.resource_id: resource.kind for resource in resources}
    needs = Counter(task.requirements)
    return [
        ids for ids in combinations(sorted(kinds), len(task.requirements))
        if Counter(kinds[key] for key in ids) == needs
    ]


def ready_times(prefix, decision):
    ready = {}
    for run in prefix:
        for key in run.resource_ids:
            ready[key] = max(ready.get(key, decision), run.end)
    return ready


def keep_suffix(plan, prefix, tasks, resources, decision, horizon):
    known = {task.task_id: task for task in tasks}
    active_resources = {resource.resource_id for resource in resources}
    executed = {run.task_id for run in prefix}
    ready = ready_times(prefix, decision)
    result = []
    for run in plan:
        if run.task_id in executed or not set(run.resource_ids) <= active_resources:
            continue
        start = max(run.start, decision, known[run.task_id].arrival,
                    *(ready.get(key, decision) for key in run.resource_ids))
        if start <= horizon:
            end = start + known[run.task_id].duration
            result.append(TaskRun(run.task_id, run.resource_ids, start, end))
            ready.update(dict.fromkeys(run.resource_ids, end))
    return result


def optimize_suffix(pending, resources, ready, decision, horizon, priorities):
    """Enumerate subsets, dispatch orders and resource choices at a known snapshot."""
    bundles = {task.task_id: resource_bundles(task, resources) for task in pending}
    best = ()
    best_key = None

    def search(remaining, ready, chosen, latest, priority_sum, total_start):
        nonlocal best, best_key
        count = len(chosen)
        key = (count, -latest if count == len(pending) else -horizon, priority_sum, -total_start)
        if best_key is None or key > best_key:
            best, best_key = chosen, key
        for task in remaining:
            for ids in bundles[task.task_id]:
                start = max(decision, task.arrival, *(ready.get(i, decision) for i in ids))
                if start <= horizon:
                    end = start + task.duration
                    run = TaskRun(task.task_id, ids, start, end)
                    search(tuple(other for other in remaining if other != task),
                           {**ready, **dict.fromkeys(ids, end)}, (*chosen, run), max(latest, start),
                           priority_sum + priorities.get(task.task_id, 1), total_start + start)

    search(tuple(pending), ready, (), 0, 0, 0)
    return best


def scenario_inputs(tasks, resources, scenario, horizon):
    jobs = (*tasks, *((scenario.new_task,) if scenario.new_task is not None else ()))
    resources = tuple(resources)
    resource_ids = {resource.resource_id for resource in resources}
    if len(resource_ids) != len(resources) or len({task.task_id for task in jobs}) != len(jobs):
        raise ValueError("Task and resource identifiers must be unique.")
    if scenario.failed is not None and scenario.failed not in resource_ids:
        raise ValueError("Failed resource identifier is unknown.")
    active = tuple(resource for resource in resources if resource.resource_id != scenario.failed)
    return tuple(task for task in jobs if task.arrival <= horizon), active


def replay(plan, scenario, policy, *, tasks=TASKS, resources=RESOURCES, horizon=HORIZON, priorities=PRIORITY):
    if policy not in ("retain", "dynamic"):
        raise ValueError("Policy must be retain or dynamic.")
    known, active = scenario_inputs(tasks, resources, scenario, horizon)
    if not scenario.disrupted:
        return tuple(Record(run, run.end) for run in plan)
    prefix = tuple(run for run in plan if run.start < scenario.at)
    decision = scenario.decision_time
    if policy == "retain":
        suffix = keep_suffix(plan, prefix, known, active, decision, horizon)
    else:
        frozen = {run.task_id for run in prefix}
        pending = tuple(task for task in known if task.task_id not in frozen)
        suffix = optimize_suffix(pending, active, ready_times(prefix, decision), decision, horizon, priorities)
    records = []
    for run in (*prefix, *suffix):
        end = min(run.end, scenario.at) if scenario.failed in run.resource_ids else run.end
        records.append(Record(run, end))
    return tuple(sorted(records, key=lambda entry: (entry.run.start, entry.run.task_id)))

