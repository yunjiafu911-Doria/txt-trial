"""Run all disruption combinations, verify them and export evidence."""

import argparse
import csv
from pathlib import Path

import numpy as np

from .audit import certify, check_schedule
from .model import HORIZON, RESOURCES, SCENARIOS, TASKS, initial_plan, metrics, replay, scenario_inputs


def timeline(plan, records, known, scenario, policy, horizon):
    events = []

    def add(time, order, kind, task="", keys=(), note=""):
        events.append((time, order, kind, task, ";".join(keys), note))

    add(0, -1, "initial_plan", note="baseline tasks only")
    planned = {run.task_id: run for run in plan}
    started = {record.run.task_id for record in records}
    for task in known:
        add(task.arrival, 4, "task_release", task.task_id, note=f"duration={task.duration}")
        if task.task_id not in started:
            if policy == "retain" and task.task_id not in planned:
                note = "absent_from_initial_plan"
            elif policy == "retain" and scenario.failed in planned[task.task_id].resource_ids:
                note = "original_resource_failed"
            else:
                note = "no_start_in_window"
            add(horizon, 10, "pending_at_window_end", task.task_id, note=note)
    if scenario.failed is not None:
        add(scenario.at, 2, "resource_failure", keys=(scenario.failed,))
    if scenario.recovery is not None:
        add(scenario.at, 2, "communication_down")
        add(scenario.recovery, 3, "communication_recovered")
    if scenario.disrupted and policy == "dynamic":
        add(scenario.decision_time, 5, "suffix_replan", note="observed snapshot")
    for entry in records:
        run = entry.run
        add(run.start, 6, "dispatch", run.task_id, run.resource_ids)
        add(run.start, 8, "task_start", run.task_id, run.resource_ids, f"planned_end={run.end}")
        if entry.interrupted:
            add(entry.effective_end, 2.2, "task_interrupt", run.task_id, run.resource_ids,
                "original start and reservation kept")
        else:
            add(run.end, 0, "task_finish", run.task_id, run.resource_ids)
        for key in run.resource_ids:
            add(run.start, 7, "resource_acquired", run.task_id, (key,))
            if entry.interrupted and key == scenario.failed:
                add(entry.effective_end, 2.3, "resource_released", run.task_id, (key,), "failed")
            else:
                add(run.end, 1, "resource_released", run.task_id, (key,))
    return [
        dict(scenario=scenario.name, policy=policy, sequence=index, time_s=time, event=event,
             task_id=task, resource_ids=keys, detail=note)
        for index, (time, _, event, task, keys, note) in enumerate(sorted(events), start=1)
    ]


def check_timeline(events, records):
    """Validate the event stream against the schedule and resource state."""
    owners, failures = {}, {}
    online = True
    by_job = {entry.run.task_id: entry for entry in records}
    if len(by_job) != len(records):
        raise AssertionError("Duplicate task in schedule records.")
    job_events = {"dispatch", "resource_acquired", "task_start", "task_finish",
                  "task_interrupt", "resource_released"}
    seen, published, dispatched, running, ended = set(), set(), set(), set(), set()
    pending, plan_seen = set(), False
    clock, previous_time = [], -1
    for item in events:
        kind, time, job, resource = (item[key] for key in ("event", "time_s", "task_id", "resource_ids"))
        if type(time) is not int or time < 0:
            raise AssertionError("Event ledger time must be a nonnegative integer.")
        if time < previous_time:
            raise AssertionError("Event ledger time moved backwards.")
        previous_time = time
        sequence = item["sequence"]
        if type(sequence) is not int:
            raise AssertionError("Event ledger sequence must be an integer.")
        clock.append(sequence)
        if kind not in job_events:
            if kind == "communication_down":
                if not online:
                    raise AssertionError("Communication is already down.")
                online = False
            elif kind == "communication_recovered":
                if online:
                    raise AssertionError("Recovery without an outage.")
                online = True
            elif kind == "resource_failure":
                if not resource or ";" in resource or resource in failures:
                    raise AssertionError("Invalid resource failure event.")
                failures[resource] = time
            elif kind == "suffix_replan":
                if not online:
                    raise AssertionError("A replan was issued during an outage.")
            elif kind == "initial_plan":
                if plan_seen or time != 0:
                    raise AssertionError("Event ledger has an invalid initial plan.")
                plan_seen = True
            elif kind == "pending_at_window_end":
                if job not in published or job in by_job or job in pending:
                    raise AssertionError("Invalid pending-task event.")
                pending.add(job)
            elif kind == "task_release":
                if not job or job in published:
                    raise AssertionError("Missing or repeated task release identifier.")
                published.add(job)
            else:
                raise AssertionError(f"Unknown event kind: {kind}.")
            continue

        key = (job, kind, resource)
        if key in seen or job not in by_job:
            raise AssertionError("Duplicate or unexpected task event.")
        seen.add(key)
        record = by_job[job]
        run = record.run
        bundle = ";".join(run.resource_ids)
        if kind == "dispatch":
            if (not online or job not in published or time != run.start or resource != bundle
                    or any(r in failures for r in run.resource_ids)):
                raise AssertionError("Invalid dispatch in event ledger.")
            dispatched.add(job)
        elif kind == "resource_acquired":
            if (resource not in run.resource_ids or resource in owners or resource in failures
                    or job not in dispatched or job in running or time != run.start):
                raise AssertionError("Resource acquisition without an available dispatched resource.")
            owners[resource] = job
        elif kind == "task_start":
            if (job not in dispatched or time != run.start or resource != bundle
                    or any(owners.get(r) != job for r in run.resource_ids)):
                raise AssertionError("Start without the commanded resource set.")
            running.add(job)
        elif kind in {"task_finish", "task_interrupt"}:
            expected_kind = "task_interrupt" if record.interrupted else "task_finish"
            if (kind != expected_kind or job not in running or job in ended or resource != bundle
                    or time != record.effective_end or time <= run.start):
                raise AssertionError("Invalid service end or terminal event kind.")
            for resource_id in run.resource_ids:
                if owners.get(resource_id) != job:
                    raise AssertionError("Service terminated without its reserved resource set.")
                if not record.interrupted and run.start < failures.get(resource_id, time) < time:
                    raise AssertionError("A failed service cannot finish normally.")
            if record.interrupted and not any(failures.get(r) == time for r in run.resource_ids):
                raise AssertionError("An interrupted task has no matching resource failure.")
            ended.add(job)
        else:
            early_release = record.interrupted and failures.get(resource) == record.effective_end
            expected_time = record.effective_end if early_release else run.end
            if job not in ended or owners.get(resource) != job or time != expected_time:
                raise AssertionError("Invalid resource release time or owner.")
            del owners[resource]
    if owners or ended != set(by_job):
        raise AssertionError("Ledger did not close every run and resource reservation.")
    if not online:
        raise AssertionError("Event ledger omits communication recovery.")
    if not plan_seen or pending != published - set(by_job):
        raise AssertionError("Initial or pending-task events are missing from the ledger.")
    if clock != list(range(1, len(clock)+1)):
        raise AssertionError("Event ledger sequence is not consecutive.")



def run_experiments():
    plan = initial_plan()
    rows, events, schedules = [], [], {}
    for scenario in SCENARIOS:
        known, active = scenario_inputs(TASKS, RESOURCES, scenario, HORIZON)
        frozen = tuple(run for run in plan if scenario.disrupted and run.start < scenario.at)
        decision = scenario.decision_time if scenario.disrupted else 0
        optimum, placements = certify(known, active, frozen, decision, HORIZON)
        for policy in ("retain", "dynamic"):
            records = replay(plan, scenario, policy)
            measured = metrics(records, known)
            if measured != check_schedule(records, known, RESOURCES, plan, scenario, HORIZON):
                raise AssertionError("Independent objective calculation disagrees.")
            ledger = timeline(plan, records, known, scenario, policy, HORIZON)
            check_timeline(ledger, records)
            k, n, latest = measured
            optimum_reached = measured == optimum
            if policy == "dynamic" and not optimum_reached:
                raise AssertionError(f"Optimality check failed for {scenario.name}.")
            rows.append(dict(
                scenario=scenario.name, policy=policy, started_k=k, tasks_n=n, eta=k/n,
                latest_start_s=latest, finished_by_60=sum(
                    record.effective_end <= HORIZON and not record.interrupted for record in records),
                interrupted=sum(record.interrupted for record in records), constraints_ok=1,
                reference_k=optimum[0], reference_latest_s=optimum[2],
                reference_placement_variables=placements, attains_reference=int(optimum_reached),
                unstarted=";".join(sorted({task.task_id for task in known} -
                                           {entry.run.task_id for entry in records})),
                replan_s=decision if scenario.disrupted and policy == "dynamic" else "",
            ))
            events.extend(ledger)
            schedules[scenario.name, policy] = records
    return rows, events, schedules


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def draw(rows, schedules, dest):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    fig, axes = plt.subplots(2, 1, figsize=(10.6, 6.6), sharex=True, layout="constrained")
    positions = np.arange(len(SCENARIOS))
    for i, (policy, label, color) in enumerate((("retain", "Retain", "#a45640"), ("dynamic", "Dynamic", "#236e61"))):
        selected = [row for row in rows if row["policy"] == policy]
        shift = (i-0.5)*0.34
        axes[0].bar(positions+shift, [row["eta"] for row in selected], width=0.34, color=color, label=label)
        axes[1].bar(positions+shift, [row["latest_start_s"] for row in selected], width=0.34, color=color)
    axes[0].set(title="Synthetic service experiments | 60 s start window", ylabel="Fraction started", ylim=(0, 1.1))
    axes[1].set_ylabel("Latest start metric (s)")
    tick_labels = [s.name.upper().replace("_", "\n+") for s in SCENARIOS]
    axes[1].set_xticks(positions, tick_labels, fontsize=8)
    axes[0].legend(frameon=False)
    for ax in axes:
        ax.grid(axis="y", alpha=0.24)
        ax.set_axisbelow(True)
    fig.savefig(dest / "scenario_comparison.png", dpi=220)
    plt.close(fig)

    combined = SCENARIOS[-1]
    fig, axes = plt.subplots(2, 1, figsize=(10.6, 5.7), sharex=True, layout="constrained")
    keys = [resource.resource_id for resource in RESOURCES]
    colors = dict(zip("ABCDEFG", ("#47658a", "#84699a", "#bc863c", "#2d806e", "#6595bb", "#b35f4b", "#679447")))
    furthest = max(entry.run.end for policy in ("retain", "dynamic") for entry in schedules[combined.name, policy])
    for ax, policy in zip(axes, ("retain", "dynamic"), strict=True):
        ax.axvspan(combined.at, combined.recovery, color="#dde3ee", alpha=0.75, label="No communications")
        ax.axvline(HORIZON, ls="--", color="#482a36", label="Start deadline")
        ax.barh(keys.index(combined.failed), furthest-combined.at, left=combined.at, height=0.42,
                color="#e9c4b9", hatch="///", label="Failed resource")
        for entry in schedules[combined.name, policy]:
            run = entry.run
            for key in run.resource_ids:
                y = keys.index(key)
                ax.barh(y, entry.effective_end-run.start, left=run.start, height=0.52,
                        color=colors[run.task_id], edgecolor="white")
                ax.text((entry.effective_end+run.start)/2, y, run.task_id,
                        color="white", ha="center", va="center", fontsize=8)
        ax.set_yticks(range(len(keys)), keys)
        ax.invert_yaxis()
        ax.set_title(policy.capitalize(), loc="left")
    axes[-1].set(xlabel="Time (s)", xlim=(0, furthest+1))
    axes[0].legend(facecolor="white", framealpha=0.97, edgecolor="#e0e4ea", fontsize=8, loc="upper right")
    fig.suptitle("Synthetic services | three disruptions")
    fig.savefig(dest / "combined_timeline.png", dpi=220)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    path = parser.parse_args().output_dir
    figures = path / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    rows, events, schedules = run_experiments()
    write_csv(path / "Problem4_Synthetic_Results.csv", rows)
    write_csv(path / "Problem4_Synthetic_Timelines.csv", events)
    draw(rows, schedules, figures)
    for row in rows:
        print(row["scenario"], row["policy"], f'{row["started_k"]}/{row["tasks_n"]}',
              row["latest_start_s"], row["unstarted"])
    print(f"{len(rows)} scenario-policy results and {len(events)} events verified.")


if __name__ == "__main__":
    main()



