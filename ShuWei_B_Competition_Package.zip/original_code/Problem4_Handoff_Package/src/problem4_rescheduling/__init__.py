"""Non-spatial synthetic service rescheduling."""
