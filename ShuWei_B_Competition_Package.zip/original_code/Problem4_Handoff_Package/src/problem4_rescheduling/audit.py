"""Independent interval checks and time-indexed optimality reference."""

from collections import Counter
from itertools import combinations, pairwise

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_array


def check_schedule(records, tasks, resources, plan, scenario, horizon):
    by_task = {task.task_id: task for task in tasks if task.arrival <= horizon}
    by_resource = {r.resource_id: r.kind for r in resources}
    actual = [record.run for record in records]
    closed = {run.task_id: run for run in plan if run.start < scenario.at}
    executed = {run.task_id: run for run in actual if run.start < scenario.at}
    if closed != executed:
        raise AssertionError("The pre-event plan was changed.")
    if len({run.task_id for run in actual}) != len(actual):
        raise AssertionError("Task started more than once.")
    for record in records:
        run = record.run
        task = by_task[run.task_id]
        if not task.arrival <= run.start <= horizon or run.end - run.start != task.duration:
            raise AssertionError("Release, completion or horizon violation.")
        if len(set(run.resource_ids)) != len(run.resource_ids):
            raise AssertionError("The same resource is duplicated in an allocation.")
        if Counter(by_resource[key] for key in run.resource_ids) != Counter(task.requirements):
            raise AssertionError("Resource qualifications do not meet task requirements.")
        if scenario.recovery is not None and scenario.at <= run.start < scenario.recovery:
            raise AssertionError("Command during communications outage.")
        if scenario.failed in run.resource_ids and run.start >= scenario.at:
            raise AssertionError("Failed resource allocated after its failure.")
        if scenario.failed in run.resource_ids and run.start < scenario.at < run.end:
            expected_end = scenario.at
        else:
            expected_end = run.end
        if record.effective_end != expected_end:
            raise AssertionError("Actual service end does not match the observed failure.")
    for key in by_resource:
        allocated = sorted((run.start, run.end) for run in actual if key in run.resource_ids)
        if any(a[1] > b[0] for a, b in pairwise(allocated)):
            raise AssertionError("Resource time intervals overlap.")
    k, n = len(actual), len(by_task)
    return k, n, horizon if k < n else max((run.start for run in actual), default=0)


def certify(tasks, resources, frozen, decision, horizon):
    """Choose legal time-indexed placements with an independent integer program."""
    eligible = [(r.resource_id, r.kind) for r in resources]
    frozen_ids = {run.task_id for run in frozen}
    pending = [task for task in tasks if task.task_id not in frozen_ids and task.arrival <= horizon]
    frozen_latest = max((run.start for run in frozen), default=0)
    candidates = []
    for j, task in enumerate(pending):
        for selection in combinations(eligible, len(task.requirements)):
            if sorted(kind for _, kind in selection) != sorted(task.requirements):
                continue
            bundle = tuple(key for key, _ in selection)
            for start in range(max(decision, task.arrival), horizon + 1):
                end = start + task.duration
                if any(run.start < end and start < run.end and set(bundle).intersection(run.resource_ids)
                       for run in frozen):
                    continue
                candidates.append((j, bundle, start, end))
    total = len(frozen) + len(pending)
    if not candidates:
        return (len(frozen), total, horizon if pending else frozen_latest), 0

    row_numbers, col_numbers, values = [], [], []
    rows = {}
    upper = []

    def add(row, column, value, bound):
        if row not in rows:
            rows[row] = len(rows)
            upper.append(bound)
        row_numbers.append(rows[row])
        col_numbers.append(column)
        values.append(value)

    n = len(candidates)
    for i, (job, bundle, start, end) in enumerate(candidates):
        add(("task", job), i, 1, 1)
        add(("latest", job), i, start, 0)
        for key in bundle:
            for tick in range(start, end):
                add(("resource", key, tick), i, 1, 1)
    for j in range(len(pending)):
        add(("latest", j), n, -1, 0)
    matrix = coo_array((values, (row_numbers, col_numbers)), shape=(len(rows), n+1)).tocsc()
    result = milp(
        c=np.array([-(horizon+1)]*n + [1.0]),
        integrality=np.array([1]*n + [0]),
        bounds=Bounds([0]*n + [frozen_latest], [1]*n + [horizon]),
        constraints=LinearConstraint(matrix, -np.inf, upper),
        options={"mip_rel_gap": 0.0},
    )
    if result.status != 0:
        raise AssertionError(f"The independent integer program did not certify an optimum: {result.message}")
    if abs(result.fun - result.mip_dual_bound) > 1e-6:
        raise AssertionError("The reference solver returned an open optimality gap.")
    used = result.x[:n]
    if float(np.max(np.abs(used - np.rint(used)))) > 1e-6:
        raise AssertionError("Reference solver returned a fractional task allocation.")
    placements = [candidate for candidate, use in zip(candidates, used, strict=True) if use > 0.5]
    k = len(frozen) + len(placements)
    latest = max((p[2] for p in placements), default=frozen_latest)
    latest = max(latest, frozen_latest)
    if abs(result.fun - (-(horizon+1)*len(placements) + latest)) > 1e-6:
        raise AssertionError("Reference objective and selected placements disagree.")
    return (k, total, horizon if k < total else latest), n
