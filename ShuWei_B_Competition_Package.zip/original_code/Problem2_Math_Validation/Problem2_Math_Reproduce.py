"""Reproduce the abstract-line and warehouse experiments."""

import argparse
from collections import Counter
import csv
from itertools import pairwise
from math import cos, radians, sin, sqrt
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np

from feasible_region.api import Point2D
from problem2_generic import angle_between, jacobian_step_sweep, propagate_covariance
from scheduler_sim.models import EventKind, Resource, Task
from scheduler_sim.reporting import plot_gantt
from scheduler_sim.simulation import simulate


ANGLES = (0, 1, 2, 5, 15, 30, 60, 90, 150, 175, 178, 179, 180)
NOISE = (0.001, 0.01)
RANGES = (3.0, 5.0)
STEPS = (1e-4, 1e-6, 1e-8)
SEED = 271828
DRAWS = 100_000
DET_GATE = 0.01
OUT = Path(__file__).resolve().parent / "outputs" / "problem2_math_validation"


def rms(values):
    return float(np.sqrt(np.mean(np.square(values))))


def angle_experiment():
    z = np.random.Generator(np.random.PCG64(SEED)).standard_normal((DRAWS, 2))
    result = []
    r1, r2 = RANGES
    for angle in ANGLES:
        g = radians(angle)
        c, s = cos(g), sin(g)
        baseline = sqrt(r1*r1 + r2*r2 - 2*r1*r2*c)
        if angle in (0, 180):
            result.append(dict(record="singular_nominal", angle_deg=angle, baseline_u=baseline,
                               range1_u=r1, range2_u=r2, status="coincident_lines"))
            continue
        direction = Point2D(c, s)
        if abs(angle_between(Point2D(1, 0), direction) - g) > 1e-14:
            raise AssertionError("The reused angle routine disagrees with the nominal angle.")
        anchors = -np.array(((r1, 0), (r2*c, r2*s)))
        jacobian = np.array(((r1*c/s, -r2/s), (r1, 0)))

        def solve(offset):
            theta = offset + (0, g)
            normals = np.column_stack((-np.sin(theta), np.cos(theta)))
            right_hand_side = np.einsum("ij,ij->i", normals, anchors)
            return np.linalg.solve(normals, right_hand_side)

        relative_errors = []
        for step, check in jacobian_step_sweep(solve, [0, 0], jacobian, STEPS):
            relative = float(np.linalg.norm(check.absolute_error) / np.linalg.norm(jacobian))
            relative_errors.append(relative)
            result.append(dict(record="finite_difference", angle_deg=angle, baseline_u=baseline,
                               relative_step=step, fd_relative_frobenius_error=relative,
                               fd_max_abs_error_u_per_rad=float(np.max(check.absolute_error)),
                               fd_refinement_max_u_per_rad=float(np.max(check.refinement_change))))
        if min(relative_errors) > 1e-7:
            raise AssertionError(f"No reliable finite difference at {angle} degrees.")

        for sigma in NOISE:
            error = sigma * z
            linear_covariance = propagate_covariance(jacobian, np.eye(2) * sigma**2)
            analytic = sigma * sqrt(r1*r1 + r2*r2) / abs(s)
            if abs(sqrt(float(np.trace(linear_covariance))) - analytic) > 1e-12:
                raise AssertionError("Trace propagation disagrees with the closed form.")
            lin_x, lin_y = (error @ jacobian.T).T
            linear_radius = np.hypot(lin_x, lin_y)
            linear_mc = rms(linear_radius)
            linear_rel_error = (linear_mc - analytic) / analytic
            if abs(linear_rel_error) > 0.015:
                raise AssertionError("Linear Monte Carlo disagrees with the closed form.")
            theta1 = error[:, 0]
            theta2 = g + error[:, 1]
            det = np.sin(theta2 - theta1)
            # The offset-adjusted RHS follows directly from the nominal pivot construction.
            b1, b2 = r1*np.sin(theta1), r2*np.sin(error[:, 1])
            finite = det != 0
            px = np.full(DRAWS, np.nan)
            py = np.full(DRAWS, np.nan)
            px[finite] = ((b1*np.cos(theta2) - b2*np.cos(theta1))[finite] / det[finite])
            py[finite] = ((b1*np.sin(theta2) - b2*np.sin(theta1))[finite] / det[finite])
            radial = np.hypot(px, py)
            valid = np.isfinite(radial)
            keep = valid & (np.abs(det) >= DET_GATE)
            if not np.any(keep):
                raise AssertionError("No trial survived the determinant gate.")
            worst_residual = max(
                float(np.max(np.abs(-np.sin(theta1[keep])*px[keep] + np.cos(theta1[keep])*py[keep] - b1[keep]))),
                float(np.max(np.abs(-np.sin(theta2[keep])*px[keep] + np.cos(theta2[keep])*py[keep] - b2[keep]))),
            )
            if worst_residual > 1e-12:
                raise AssertionError("Computed intersections fail the line equations.")
            pivot_difference = max(
                float(np.linalg.norm(solve(error[i]) - [px[i], py[i]]))
                for i in np.flatnonzero(keep)[:5]
            )
            if pivot_difference > 1e-12:
                raise AssertionError("Vectorized intersections disagree with the independent solve.")
            gated_linear = rms(linear_radius[keep])
            gated_nonlinear = rms(radial[keep])
            result.append(dict(
                record="monte_carlo", status="computed", angle_deg=angle, baseline_u=baseline,
                range1_u=r1, range2_u=r2, normal_condition_2=(1 + abs(c))/abs(s),
                sigma_rad=sigma, seed=SEED, trials=DRAWS, finite_trials=int(np.count_nonzero(valid)),
                det_gate=DET_GATE, gated_trials=int(np.count_nonzero(keep)),
                gate_reject_fraction=1 - np.count_nonzero(keep)/DRAWS,
                analytic_linear_rms_u=analytic, mc_linear_rms_u=linear_mc,
                mc_linear_relative_error=linear_rel_error, min_fd_relative_error=min(relative_errors),
                mc_gated_linear_rms_u=gated_linear, mc_gated_nonlinear_rms_u=gated_nonlinear,
                mc_gated_nonlinear_vs_linear_rel=(gated_nonlinear - gated_linear)/gated_linear,
                mc_nonlinear_median_u=float(np.median(radial[valid])),
                mc_nonlinear_p95_u=float(np.quantile(radial[valid], 0.95)),
                gated_max_line_residual_u=worst_residual,
                independent_solve_max_difference_u=pivot_difference,
            ))
    return result


def warehouse_experiment():
    resources = (Resource("packer-1", "packer"), Resource("packer-2", "packer"),
                 Resource("labeler", "labeler"))
    label = ("packer", "labeler")
    tasks = (
        Task("A", 0, 9, label), Task("B", 0, 4, label), Task("C", 0, 8, ("packer",)),
        Task("D", 0, 2, label), Task("E", 0, 3, ("packer",)), Task("F", 0, 5, label),
    )
    labels = [task.duration for task in tasks if "labeler" in task.requirements]
    lower_bound = sum(labels) - max(labels)
    results = [
        dict(record="warehouse_input", task_id=task.task_id, arrival_tick=task.arrival,
             duration_ticks=task.duration, requires=";".join(task.requirements))
        for task in tasks
    ]
    timeline, schedules = [], []
    kinds = {resource.resource_id: resource.kind for resource in resources}
    for policy in ("fcfs", "spt"):
        schedule = simulate(resources, tasks, policy=policy)
        schedules.append(schedule)
        executions = {run.task_id: run for run in schedule.runs}
        if len(executions) != len(schedule.runs) or set(executions) != {task.task_id for task in tasks}:
            raise AssertionError("Missing or repeated warehouse job.")
        for task in tasks:
            run = executions[task.task_id]
            if run.start < task.arrival or run.end - run.start != task.duration:
                raise AssertionError("Warehouse release or duration violation.")
            if Counter(kinds[key] for key in run.resource_ids) != Counter(task.requirements):
                raise AssertionError("Warehouse resource type mismatch.")
            events = [event for event in schedule.events if event.task_id == task.task_id]
            expected = [
                (EventKind.TASK_ARRIVAL, task.arrival, ()),
                *((EventKind.RESOURCE_ACQUIRED, run.start, (key,)) for key in run.resource_ids),
                (EventKind.TASK_START, run.start, run.resource_ids),
                (EventKind.TASK_FINISH, run.end, run.resource_ids),
                *((EventKind.RESOURCE_RELEASED, run.end, (key,)) for key in run.resource_ids),
            ]
            if [(event.kind, event.time, event.resource_ids) for event in events] != expected:
                raise AssertionError("Invalid warehouse event sequence.")
        for resource in resources:
            runs = sorted((run for run in schedule.runs if resource.resource_id in run.resource_ids),
                          key=lambda run: run.start)
            if any(prev.end > following.start for prev, following in pairwise(runs)):
                raise AssertionError("Warehouse resource allocated to concurrent jobs.")
        for sequence, event in enumerate(schedule.events, 1):
            timeline.append(dict(
                policy=policy, sequence=sequence, time_tick=event.time, event=event.kind.value,
                task_id=event.task_id, resource_ids=";".join(event.resource_ids),
                remaining_ticks=event.remaining,
            ))
        latest = max(run.start for run in schedule.runs)
        if latest < lower_bound or (policy == "spt" and latest != lower_bound):
            raise AssertionError("Warehouse schedule disagrees with the bottleneck bound.")
        results.append(dict(
            record="warehouse_summary", policy=policy, status="attains_proven_bound" if latest == lower_bound else "baseline",
            latest_start_tick=latest, lower_bound_tick=lower_bound, makespan_tick=max(run.end for run in schedule.runs),
            mean_wait_tick=float(np.mean([outcome.waiting_time for outcome in schedule.outcomes])),
            max_wait_tick=schedule.max_waiting_time, completed=schedule.completed_count,
        ))
    return results, timeline, schedules


def write_csv(path, rows):
    columns = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def plot_sensitivity(rows):
    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.5), layout="constrained", sharex=True)
    lines = (
        ("analytic_linear_rms_u", "Analytic linear RMS", "#253f5d", "o"),
        ("mc_gated_linear_rms_u", "Gated linear MC RMS", "#74559a", "^"),
        ("mc_gated_nonlinear_rms_u", "Gated nonlinear MC RMS", "#267264", "s"),
        ("mc_nonlinear_p95_u", "Nonlinear empirical P95", "#9f4e2f", "D"),
    )
    for axis, sigma in zip(axes, NOISE, strict=True):
        points = [row for row in rows if row.get("sigma_rad") == sigma]
        for field, label, color, marker in lines:
            axis.plot([row["angle_deg"] for row in points], [row[field] for row in points],
                      color=color, marker=marker, markersize=4, linewidth=1.2, label=label)
        axis.set(yscale="log", xlabel="Nominal line angle (deg)", title=f"Noise SD = {sigma:g} rad")
        axis.set_xticks((0, 30, 60, 90, 120, 150, 180))
        axis.grid(alpha=0.25)
    axes[0].set_ylabel("Intersection error (u)")
    axes[1].legend(frameon=False, fontsize=8)
    return fig


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    dest = parser.parse_args().output_dir
    figures = dest / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    geometry = angle_experiment()
    warehouse, timeline, schedules = warehouse_experiment()
    write_csv(dest / "Problem2_Numerical_Results.csv", geometry + warehouse)
    write_csv(dest / "Problem2_Synthetic_Timeline.csv", timeline)
    gantt = plot_gantt(schedules)
    gantt.suptitle("Synthetic warehouse | shared packers and labeler")
    gantt.axes[0].get_legend().remove()
    for name, figure in (("line_sensitivity.png", plot_sensitivity(geometry)), ("warehouse_timeline.png", gantt)):
        figure.savefig(figures / name, dpi=240)
        plt.close(figure)
    print("Numerical records:", Counter(row["record"] for row in geometry + warehouse))
    print("Warehouse events:", len(timeline))


if __name__ == "__main__":
    main()
