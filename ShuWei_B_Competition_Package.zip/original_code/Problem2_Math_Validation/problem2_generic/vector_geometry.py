"""Multi-vector geometry using the original point types and angle routine."""

from collections.abc import Iterable
from itertools import combinations

import numpy as np

from .vectors import (
    Point2D, Point3D, add, angle_between, azimuth, cross, dot, elevation,
    horizontal_distance, norm, scale, subtract, unit,
)


def pairwise_angles(directions: Iterable[Point2D | Point3D]) -> np.ndarray:
    """Return the symmetric angle matrix in radians for nonzero, same-dimension vectors."""
    directions = tuple(directions)
    if not directions:
        raise ValueError("Provide at least one direction.")
    result = np.empty((len(directions), len(directions)))
    for index, direction in enumerate(directions):
        result[index, index] = angle_between(direction, direction)
    for i, j in combinations(range(len(directions)), 2):
        result[i, j] = result[j, i] = angle_between(directions[i], directions[j])
    return result


__all__ = [
    "Point2D", "Point3D", "add", "subtract", "scale", "dot", "cross", "norm", "unit",
    "angle_between", "pairwise_angles", "azimuth", "elevation", "horizontal_distance",
]
