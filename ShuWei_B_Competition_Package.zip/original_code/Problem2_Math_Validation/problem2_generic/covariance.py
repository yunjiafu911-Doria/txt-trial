"""Validate covariance matrices and propagate a supplied linear map."""

from dataclasses import dataclass
from fractions import Fraction

import numpy as np

from ._numeric import nonnegative, real_array


@dataclass(frozen=True, slots=True)
class CovarianceCheck:
    symmetric: bool
    positive_semidefinite: bool
    entry_scale: float
    scaled_asymmetry: float
    minimum_scaled_eigenvalue: float
    scaled_tolerance: float


@dataclass(frozen=True, slots=True)
class CovarianceSpectrum:
    check: CovarianceCheck
    scaled_eigenvalues: tuple[float, ...]
    numerical_rank: int
    near_singular: bool


def _covariance(value) -> np.ndarray:
    matrix = real_array(value, "Covariance")
    if matrix.ndim != 2 or matrix.shape[0] == 0 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("Covariance must be a nonempty square matrix.")
    return matrix


def _average(matrix):
    """Symmetrize in binary64 without overflow or premature subnormal rounding."""
    transpose = matrix.T
    with np.errstate(over="ignore"):
        total = matrix + transpose
    return np.where(np.isfinite(total), total*0.5, matrix*0.5 + transpose*0.5)


def _exact_psd(matrix, atol):
    """Test the exact binary inputs by Schur complements of S + atol I."""
    shift = Fraction(atol)
    block = [list(map(Fraction, row)) for row in matrix]
    for i, row in enumerate(block):
        row[i] += shift

    for i, row in enumerate(block):
        pivot = row[i]
        if pivot < 0:
            return False
        if pivot == 0:
            if any(row[i+1:]):
                return False
            continue
        for j in range(i+1, len(block)):
            multiplier = row[j]/pivot
            for k in range(j, len(block)):
                block[j][k] -= multiplier*row[k]
    return True


def _inspect(matrix, atol, rtol):
    largest = float(np.max(np.abs(matrix)))
    scale = largest if largest else 1.0
    with np.errstate(under="ignore", over="ignore"):
        asymmetry = float(np.max(np.abs(matrix - matrix.T) / scale))
        # Opposite extreme values can overflow subtraction before scaling.
        normalized = matrix/scale
        if not np.isfinite(asymmetry):
            asymmetry = float(np.max(np.abs(normalized - normalized.T)))
        if rtol == 0:
            symmetric = bool(np.all(np.abs(matrix - matrix.T) <= atol))
        else:
            symmetric = asymmetry <= rtol + atol/scale

        averaged = _average(matrix)
        eigenvalues = np.linalg.eigvalsh(averaged/scale)

    minimum = float(eigenvalues[0])
    threshold = rtol + atol/scale
    positive = False
    if symmetric:
        # Normalized eigenvalues away from zero give a fast decision. Near the
        # rounding band, the scale can hide negative pivots or corrupt rank.
        shifted_minimum = minimum + atol/scale
        error_band = 32*np.finfo(float).eps*len(matrix)
        if abs(shifted_minimum) > error_band:
            positive = shifted_minimum > 0
        else:
            positive = _exact_psd(averaged, atol)

    check = CovarianceCheck(symmetric, positive, scale, asymmetry, minimum, threshold)
    return check, eigenvalues



def validate_covariance(covariance, *, atol: float = 0.0, rtol: float = 1e-12) -> CovarianceCheck:
    """Check symmetry and PSD of the symmetric part shifted by explicit atol."""
    check, _ = _inspect(_covariance(covariance), nonnegative(atol, "atol"), nonnegative(rtol, "rtol"))
    return check


def covariance_spectrum(covariance, *, atol: float = 0.0, rtol: float = 1e-12) -> CovarianceSpectrum:
    """Diagnose numerical rank from eigenvalues of the scaled symmetric part."""
    check, eigenvalues = _inspect(
        _covariance(covariance), nonnegative(atol, "atol"), nonnegative(rtol, "rtol"),
    )
    if not check.symmetric:
        raise ValueError("Covariance is not symmetric within tolerance.")
    rank = int(np.count_nonzero(np.abs(eigenvalues) > check.scaled_tolerance))
    return CovarianceSpectrum(check, tuple(map(float, eigenvalues)), rank, rank < len(eigenvalues))


def propagate_covariance(linear_map, covariance, *, atol: float = 0.0, rtol: float = 1e-12) -> np.ndarray:
    """Return A Sigma A.T, without projecting an explicit atol override onto PSD."""
    a = real_array(linear_map, "Linear map")
    sigma = _covariance(covariance)
    if a.ndim != 2 or a.shape[0] == 0 or a.shape[1] != sigma.shape[0]:
        raise ValueError("Linear map must be a nonempty (m, n) matrix matching covariance.")
    atol = nonnegative(atol, "atol")
    check, _ = _inspect(sigma, atol, nonnegative(rtol, "rtol"))
    if not check.symmetric:
        raise ValueError("Covariance is not symmetric within tolerance.")
    if not check.positive_semidefinite:
        raise ValueError("Covariance is not positive semidefinite within tolerance.")
    with np.errstate(over="ignore", invalid="ignore", under="ignore"):
        result = (a @ _average(sigma)) @ a.T
    if not np.all(np.isfinite(result)):
        raise OverflowError("Covariance product exceeded binary64 range; rescale the inputs.")
    result = _average(result)
    if atol == 0 and np.any(np.diag(result) < 0):
        # Recompute cancellation-prone contractions from the actual inputs.
        exact_sigma = _average(sigma)
        exact_rows = [list(map(Fraction, row)) for row in a]
        exact_matrix = [list(map(Fraction, row)) for row in exact_sigma]
        projected = [[sum(x*y for x, y in zip(row, column)) for column in zip(*exact_matrix)]
                     for row in exact_rows]
        result = np.array([[float(sum(x*y for x, y in zip(row, column))) for column in exact_rows]
                           for row in projected])
    return result

