"""Shared input conversion for the measurement components."""

from math import isfinite
from numbers import Real

import numpy as np


def nonnegative(value: float, name: str) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite nonnegative real number.")
    try:
        value = float(value)
    except OverflowError as error:
        raise ValueError(f"{name} must be a finite nonnegative real number.") from error
    if not isfinite(value) or value < 0:
        raise ValueError(f"{name} must be a finite nonnegative real number.")
    return value


def real_array(value, name: str) -> np.ndarray:
    result = np.asarray(value)
    if result.dtype.kind not in "fiub":
        raise ValueError(f"{name} must contain real numbers.")
    with np.errstate(over="ignore", invalid="ignore"):
        result = result.astype(np.float64, copy=True)
    if not np.all(np.isfinite(result)):
        raise ValueError(f"{name} must be finite in binary64.")
    return result
