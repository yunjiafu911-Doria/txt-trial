"""Compose forward scalar and vector measurements and compare their derivatives."""

from collections.abc import Callable, Iterable
from operator import index

import numpy as np

from .differentiation import (
    JacobianCheck, _evaluate, _point, check_jacobian, finite_difference_jacobian,
)


def stack_measurements(functions: Iterable[Callable], *, output_sizes: Iterable[int]) -> Callable:
    """Return a forward function with one fixed output block per measurement."""
    functions = tuple(functions)
    sizes = []
    for value in output_sizes:
        if isinstance(value, (bool, np.bool_)):
            raise ValueError("Each output size must be a positive integer.")
        try:
            size = index(value)
        except TypeError as error:
            raise ValueError("Each output size must be a positive integer.") from error
        if size < 1:
            raise ValueError("Each output size must be a positive integer.")
        sizes.append(size)
    if not functions or len(functions) != len(sizes) or not all(map(callable, functions)):
        raise ValueError("Provide one output size for each callable measurement.")
    measurements = tuple(zip(functions, sizes, strict=True))

    def evaluate(point) -> np.ndarray:
        x = _point(point)
        values = []
        for i, (function, size) in enumerate(measurements):
            value = _evaluate(function, x)
            if len(value) != size:
                raise ValueError(f"Measurement {i} returned {len(value)} values, expected {size}.")
            values.append(value)
        return np.concatenate(values)

    return evaluate


def jacobian_step_sweep(
    function, point, analytic, relative_steps: Iterable[float], *,
    atol: float = 1e-8, rtol: float = 1e-6,
) -> tuple[tuple[float, JacobianCheck], ...]:
    """Compare the reference and two estimates at each requested relative step."""
    return tuple(
        (float(step), check_jacobian(function, point, analytic, relative_step=step, atol=atol, rtol=rtol))
        for step in relative_steps
    )


__all__ = [
    "JacobianCheck", "check_jacobian", "finite_difference_jacobian", "stack_measurements",
    "jacobian_step_sweep",
]
