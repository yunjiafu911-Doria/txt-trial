"""Vector geometry and forward measurement checks for synthetic examples."""

from .covariance import CovarianceCheck, CovarianceSpectrum, covariance_spectrum, propagate_covariance, validate_covariance
from .measurement_math import (
    JacobianCheck, check_jacobian, finite_difference_jacobian, jacobian_step_sweep, stack_measurements,
)
from .vector_geometry import (
    Point2D, Point3D, add, angle_between, azimuth, cross, dot, elevation,
    horizontal_distance, norm, pairwise_angles, scale, subtract, unit,
)

__all__ = [
    "Point2D", "Point3D", "add", "subtract", "scale", "dot", "cross", "norm", "unit",
    "angle_between", "pairwise_angles", "azimuth", "elevation", "horizontal_distance",
    "JacobianCheck", "finite_difference_jacobian", "check_jacobian", "stack_measurements", "jacobian_step_sweep",
    "CovarianceCheck", "CovarianceSpectrum", "validate_covariance", "propagate_covariance", "covariance_spectrum",
]
