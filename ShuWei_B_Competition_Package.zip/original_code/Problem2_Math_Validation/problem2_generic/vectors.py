"""Operations on the existing 2D and 3D point records, treated as vectors."""

from fractions import Fraction
from math import atan2, hypot, isfinite
from numbers import Integral, Real
from typing import TypeVar

from geometry import Point2D
from feasible_region.geometry3d.angles import azimuth, elevation, horizontal_distance
from feasible_region.geometry3d.geometry import Point3D

Vector = TypeVar("Vector", Point2D, Point3D)


def _coordinates(vector: Point2D | Point3D) -> tuple[Fraction, ...]:
    if isinstance(vector, Point2D):
        return Fraction(vector.x), Fraction(vector.y)
    if isinstance(vector, Point3D):
        return tuple(map(Fraction, vector.coordinates))
    raise TypeError("Expected a Point2D or Point3D vector.")


def _pair(left: Vector, right: Vector):
    a, b = _coordinates(left), _coordinates(right)
    if len(a) != len(b):
        raise ValueError("Vectors must have the same dimension.")
    return a, b


def _from_components(vector: Vector, components) -> Vector:
    cls = Point2D if isinstance(vector, Point2D) else Point3D
    return cls(*(float(value) for value in components))


def add(left: Vector, right: Vector) -> Vector:
    a, b = _pair(left, right)
    return _from_components(left, (x + y for x, y in zip(a, b)))


def subtract(left: Vector, right: Vector) -> Vector:
    a, b = _pair(left, right)
    return _from_components(left, (x - y for x, y in zip(a, b)))


def scale(vector: Vector, factor: float) -> Vector:
    if isinstance(factor, bool) or not isinstance(factor, Real):
        raise ValueError("Scale factor must be real and finite.")
    if isinstance(factor, Integral):
        exact = Fraction(int(factor))
    else:
        number = float(factor)
        if not isfinite(number):
            raise ValueError("Scale factor must be real and finite.")
        exact = Fraction(number)
    return _from_components(vector, (component * exact for component in _coordinates(vector)))


def dot(left: Vector, right: Vector) -> float:
    a, b = _pair(left, right)
    return float(sum(x * y for x, y in zip(a, b)))


def _cross_components(a, b) -> tuple[Fraction, ...]:
    if len(a) == 2:
        return (a[0] * b[1] - a[1] * b[0],)
    x, y, z = a
    u, v, w = b
    return y * w - z * v, z * u - x * w, x * v - y * u


def cross(left: Point3D, right: Point3D) -> Point3D:
    if not isinstance(left, Point3D) or not isinstance(right, Point3D):
        raise TypeError("Cross product requires two Point3D vectors.")
    a, b = _pair(left, right)
    return _from_components(left, _cross_components(a, b))


def norm(vector: Vector) -> float:
    """Return the Euclidean norm, raising on results outside binary64."""
    result = hypot(*(float(value) for value in _coordinates(vector)))
    if not isfinite(result):
        raise OverflowError("Vector norm exceeds binary64 range.")
    return result


def unit(vector: Vector) -> Vector:
    values = _coordinates(vector)
    largest = max(map(abs, values))
    if largest == 0:
        raise ValueError("A zero vector has no unit direction.")
    normalized = tuple(float(value / largest) for value in values)
    length = hypot(*normalized)
    return _from_components(vector, (value / length for value in normalized))


def angle_between(left: Vector, right: Vector) -> float:
    """Return the unsigned angle in radians in [0, pi]."""
    a, b = _pair(left, right)
    if not any(a) or not any(b):
        raise ValueError("The angle of a zero vector is undefined.")
    inner = sum(x * y for x, y in zip(a, b))
    exterior = _cross_components(a, b)
    magnitude = max(abs(inner), *map(abs, exterior))
    return atan2(hypot(*(float(value / magnitude) for value in exterior)), float(inner / magnitude))


__all__ = [
    "Point2D", "Point3D", "add", "subtract", "scale", "dot", "cross", "norm", "unit",
    "angle_between", "azimuth", "elevation", "horizontal_distance",
]
