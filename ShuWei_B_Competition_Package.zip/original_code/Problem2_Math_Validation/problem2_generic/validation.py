"""Run fixed forward-measurement cases and export their numerical evidence."""

import argparse
import csv
from decimal import Decimal, localcontext
from fractions import Fraction
from math import exp, pi, ulp
from pathlib import Path

import numpy as np

from . import (
    Point2D, Point3D, angle_between, check_jacobian, covariance_spectrum, dot,
    finite_difference_jacobian, jacobian_step_sweep, pairwise_angles, propagate_covariance,
    stack_measurements, unit, validate_covariance,
)


_PI = Decimal("3.141592653589793238462643383279502884197169399375105820974944592307816406286")
_COLUMNS = (
    "case", "quantity", "basis", "reference", "computed", "absolute_error", "relative_error",
    "status", "relative_step", "offset", "refinement_change", "matches", "stable",
    "tolerance", "numerical_rank", "near_singular", "detail",
)


def _number(case, quantity, basis, reference, computed, *, limit=None, **details):
    with localcontext() as context:
        context.prec = 75
        target = Decimal(reference)
        actual = Decimal.from_float(float(computed))
        error = abs(actual - target)
        relative = error / abs(target) if target else None
    if limit is not None and error > Decimal.from_float(limit):
        raise AssertionError(f"{case}/{quantity}: error {error} exceeds {limit}")
    return {
        "case": case, "quantity": quantity, "basis": basis,
        "reference": str(reference), "computed": float(computed), "absolute_error": float(error),
        "relative_error": None if relative is None else float(relative),
        "status": "within_bound" if limit is not None else "measured", **details,
    }


def _rejection(case, operation, message):
    try:
        operation()
    except ValueError as error:
        if message not in str(error):
            raise
        return {
            "case": case, "quantity": "input_status", "basis": "defined_exception",
            "reference": "ValueError", "computed": "ValueError",
            "status": "expected_rejection", "detail": str(error),
        }
    raise AssertionError(f"{case}: missing expected exception")


def _atan_small(value):
    """75-digit alternating-series reference for the small offsets used below."""
    power = result = value
    denom = 1
    while True:
        power *= -value * value
        denom += 2
        update = result + power / denom
        if update == result:
            return result
        result = update


def _vector_cases():
    angle_grid = pairwise_angles((Point3D(1, 0, 0), Point3D(0, 1, 0), Point3D(-1, 0, 0)))
    with localcontext() as context:
        context.prec = 75
        right_angle = _PI / 2
    rows = [
        _number("orthogonal_3d", "angle_rad", "pi_over_two", right_angle,
                angle_grid[0, 1], limit=ulp(pi / 2)),
        _number("opposite_3d", "angle_rad", "pi", _PI, angle_grid[0, 2], limit=ulp(pi)),
        _number("parallel_3d", "angle_rad", "exact", 0, angle_grid[0, 0], limit=0.0),
        _number("integer_dot_3d", "dot_product", "integer_arithmetic", 12,
                dot(Point3D(1, 2, 3), Point3D(4, -5, 6)), limit=0.0),
        _rejection("zero_vector", lambda: unit(Point2D(0, 0)), "zero vector"),
    ]
    stability = []
    for exponent in (12, 27, 53, 80):
        delta = 2.0**-exponent
        with localcontext() as context:
            context.prec = 75
            angle = _atan_small(Decimal.from_float(delta))
            opposite = _PI - angle
        for label, endpoint, exact in (
            ("near_parallel", Point2D(1, delta), angle),
            ("near_antiparallel", Point2D(-1, delta), opposite),
        ):
            value = angle_between(Point2D(1, 0), endpoint)
            stability.append(_number(
                label, "angle_rad", "decimal_arctan_series", exact, value,
                limit=ulp(float(exact)), offset=delta,
                detail="rounded to binary64 pi" if value == pi else "",
            ))
    return rows, stability


def _measurement_cases():
    def scalar(p):
        x, y = p
        return x*x + 3*y

    def vector(p):
        x, y = p
        return [x*y + y*y, 2*x - y]

    stacked = stack_measurements((scalar, vector), output_sizes=(1, 2))
    analytic = [[4, 3], [-0.5, 1], [2, -1]]
    check = check_jacobian(stacked, [2, -0.5], analytic)
    if not check.matches or not check.stable:
        raise AssertionError("Forward measurement Jacobian failed.")
    rows = [
        _number("stacked_polynomial", f"J[{i},{j}]", "hand_differentiation",
                value, check.numerical[i, j], limit=3e-10,
                refinement_change=float(check.refinement_change[i, j]))
        for i, row in enumerate(analytic) for j, value in enumerate(row)
    ]

    x = 0.7
    with localcontext() as context:
        context.prec = 75
        reference = Decimal.from_float(x).exp()
    trials = jacobian_step_sweep(
        lambda p: exp(p[0]), [x], [[float(reference)]],
        (2.0**-exponent for exponent in (3, 6, 10, 14, 18, 22, 26, 32, 40, 48, 51)),
        atol=1e-10, rtol=1e-8,
    )
    stability = [
        _number("scalar_exponential", "derivative", "decimal_exp", reference, check.numerical[0, 0],
                relative_step=step, refinement_change=float(check.refinement_change[0, 0]),
                matches=int(check.matches), stable=int(check.stable))
        for step, check in trials
    ]
    if min(record["absolute_error"] for record in stability) > 1e-9:
        raise AssertionError("Step sweep did not recover the reference at any step.")
    step = 2.0**-60
    stability.append({
        **_rejection("unrepresentable_step",
                     lambda: finite_difference_jacobian(lambda p: exp(p[0]), [x], relative_step=step),
                     "not representable"),
        "relative_step": step,
    })
    return rows, stability


def _covariance_cases():
    sigma = ((4, 2), (2, 1))
    linear_map = ((1, 2), (0, 1), (1, -1))
    output = propagate_covariance(linear_map, sigma)
    rows = []
    for i, u in enumerate(linear_map):
        for j, v in enumerate(linear_map):
            reference = sum(Fraction(u[k] * sigma[k][l] * v[l]) for k in range(2) for l in range(2))
            rows.append(_number("rank_one_propagation", f"Sigma[{i},{j}]", "rational_matrix_contraction",
                                reference.numerator, output[i, j], limit=0.0))
    if covariance_spectrum(output).numerical_rank != 1:
        raise AssertionError("Propagated rank-one structure was not detected.")
    rows.extend((
        _rejection("nonsymmetric_propagation",
                   lambda: propagate_covariance(np.eye(2), [[1, 2], [0, 1]]), "not symmetric"),
        _rejection("indefinite_propagation",
                   lambda: propagate_covariance(np.eye(2), [[1, 0], [0, -1]]), "semidefinite"),
    ))
    stability = []
    for delta in (0.0, 2.0**-20, 2.0**-40, 2.0**-52):
        check = covariance_spectrum([[1, 1 - delta], [1 - delta, 1]])
        expected_rank = 1 + (delta > 1e-12)
        if not check.check.positive_semidefinite or check.numerical_rank != expected_rank:
            raise AssertionError("Correlation matrix rank diagnosis failed.")
        stability.append(_number(
            "correlation_spectrum", "minimum_scaled_eigenvalue", "eigenvectors_(1,1)_(1,-1)",
            Decimal.from_float(delta), check.scaled_eigenvalues[0], limit=4*ulp(1.0),
            offset=delta, tolerance=check.check.scaled_tolerance, numerical_rank=check.numerical_rank,
            near_singular=int(check.near_singular),
            detail=f"structural_rank={1 if delta == 0 else 2}",
        ))
    delta = 2.0**-42
    for tolerance, expected in ((0.0, 0), (delta, 1)):
        check = validate_covariance([[1, 0], [0, -delta]], atol=tolerance, rtol=0)
        stability.append(_number(
            "negative_eigenvalue_at_tolerance", "accepted", "signed_diagonal_vs_atol",
            expected, check.positive_semidefinite, limit=0.0, offset=-delta, tolerance=tolerance,
            detail="Acceptance at a positive tolerance leaves the negative eigenvalue unchanged.",
        ))
    for label, matrix, field in (
        ("asymmetry_underflows_in_scaling", [[1e300, 1e-300], [0, 0]], "symmetric"),
        ("negative_diagonal_underflows_in_scaling", [[1e300, 0], [0, -1e-300]], "positive_semidefinite"),
        ("zero_diagonal_nonzero_row", [[1e300, 1e-300], [1e-300, 0]], "positive_semidefinite"),
    ):
        check = validate_covariance(matrix, rtol=0)
        stability.append(_number(label, field, "unscaled_necessary_condition", 0, getattr(check, field),
                                 limit=0.0, tolerance=0.0))
    return rows, stability


def run_validation(output_dir: str | Path) -> dict[str, int]:
    """Write the primary cases and the sensitivity sweep as two plain CSV files."""
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    primary, stability = [], []
    for cases in (_vector_cases, _measurement_cases, _covariance_cases):
        observed, sensitivity = cases()
        primary.extend(observed)
        stability.extend(sensitivity)
    sets = {"validation_results.csv": primary, "numerical_stability.csv": stability}
    for name, rows in sets.items():
        with (destination / name).open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=_COLUMNS)
            writer.writeheader()
            writer.writerows(rows)
    return {name: len(rows) for name, rows in sets.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/problem2_generic_stage1"))
    for filename, rows in run_validation(parser.parse_args().output_dir).items():
        print(f"{filename}: {rows} data rows")


if __name__ == "__main__":
    main()
