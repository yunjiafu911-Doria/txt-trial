"""Run fixed, abstract forward-geometry and covariance examples."""

import json
from math import atan, pi, ulp
from pathlib import Path
import argparse

import numpy as np

from . import Point2D, Point3D, angle_between, check_jacobian, dot, propagate_covariance, validate_covariance


def demonstration():
    """Return validation figures from fixed inputs with independent references."""
    delta = 2**-27
    angle = angle_between(Point2D(1, 0), Point2D(1, delta))

    def polynomial(p):
        x, y = p
        return np.array([x**2 + 3*y, x*y + y**2])

    analytic = np.array([[4, 3], [-0.5, 1]])
    derivative = check_jacobian(polynomial, [2, -0.5], analytic)
    covariance = np.array([[4, 2], [2, 1]])
    linear_map = np.array([[1, 2], [0, 1], [1, -1]])
    output = propagate_covariance(linear_map, covariance)
    reference = np.array([[16, 4, 4], [4, 1, 1], [4, 1, 1]])
    out_check = validate_covariance(output)
    if not (abs(angle - atan(delta)) <= ulp(delta) and derivative.matches and derivative.stable):
        raise AssertionError("Geometry or Jacobian demonstration failed.")
    if not np.array_equal(output, reference) or not out_check.positive_semidefinite:
        raise AssertionError("Covariance demonstration failed.")
    return {
        "orthogonal_angle_radians": angle_between(Point3D(1, 0, 0), Point3D(0, 1, 0)),
        "orthogonal_reference_radians": pi / 2,
        "near_parallel_angle_radians": angle,
        "near_parallel_reference_radians": atan(delta),
        "integer_dot_product": dot(Point3D(1, 2, 3), Point3D(4, -5, 6)),
        "analytic_jacobian": analytic.tolist(),
        "finite_difference_jacobian": derivative.numerical.tolist(),
        "jacobian_max_absolute_error": float(np.max(derivative.absolute_error)),
        "jacobian_max_refinement_change": float(np.max(derivative.refinement_change)),
        "covariance": output.tolist(),
        "covariance_exact_reference": reference.tolist(),
        "covariance_minimum_scaled_eigenvalue": out_check.minimum_scaled_eigenvalue,
        "covariance_scaled_tolerance": out_check.scaled_tolerance,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Optional JSON result path.")
    args = parser.parse_args()
    result = json.dumps(demonstration(), indent=2, allow_nan=False) + "\n"
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(result, encoding="utf-8")
    else:
        print(result, end="")


if __name__ == "__main__":
    main()
