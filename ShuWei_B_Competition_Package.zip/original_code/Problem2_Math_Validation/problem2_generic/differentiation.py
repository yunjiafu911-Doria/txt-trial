"""Central finite differences at two step sizes for forward measurement functions."""

from dataclasses import dataclass

import numpy as np

from ._numeric import nonnegative, real_array


_DEFAULT_STEP = float(np.cbrt(np.finfo(np.float64).eps))


@dataclass(frozen=True, slots=True)
class JacobianCheck:
    analytic: np.ndarray
    numerical: np.ndarray
    coarse: np.ndarray
    absolute_error: np.ndarray
    refinement_change: np.ndarray
    matches: bool
    stable: bool


def _point(value):
    x = real_array(value, "Point")
    if x.ndim != 1 or x.size == 0:
        raise ValueError("Point must be a nonempty one-dimensional array.")
    return x


def _evaluate(function, point):
    value = real_array(function(point.copy()), "Function output")
    if value.ndim > 1 or value.size == 0:
        raise ValueError("Function must return a scalar or nonempty vector.")
    return np.atleast_1d(value)


def _jacobian(function, x, baseline, relative_step):
    result = np.empty((baseline.size, x.size))
    for col, coordinate in enumerate(x):
        displacement = relative_step * max(1.0, abs(float(coordinate)))
        plus, minus = x.copy(), x.copy()
        with np.errstate(over="ignore", invalid="ignore"):
            plus[col] = coordinate + displacement
            minus[col] = coordinate - displacement
            h_plus, h_minus = plus[col] - coordinate, coordinate - minus[col]
            width = h_plus + h_minus
        if not np.isfinite(width) or h_plus <= 0 or h_minus <= 0:
            raise ValueError(f"Perturbation is not representable in both directions for component {col}.")
        above, below = _evaluate(function, plus), _evaluate(function, minus)
        if above.shape != baseline.shape or below.shape != baseline.shape:
            raise ValueError("Function output shape changed under perturbation.")
        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            # Weighted one-sided slopes account for unequal representable offsets.
            result[:, col] = ((h_minus / width) * ((above - baseline) / h_plus)
                              + (h_plus / width) * ((baseline - below) / h_minus))
    if not np.all(np.isfinite(result)):
        raise ValueError("Finite differences produced a non-finite derivative.")
    return result


def _step(relative_step: float) -> float:
    step = nonnegative(relative_step, "relative_step")
    if step == 0:
        raise ValueError("relative_step must be positive.")
    return step


def finite_difference_jacobian(function, point, *, relative_step: float = _DEFAULT_STEP) -> np.ndarray:
    """Estimate an (m, n) Jacobian with central differences."""
    x = _point(point)
    step = _step(relative_step)
    return _jacobian(function, x, _evaluate(function, x), step)


def check_jacobian(
    function, point, analytic, *, relative_step: float = _DEFAULT_STEP,
    atol: float = 1e-8, rtol: float = 1e-6,
) -> JacobianCheck:
    """Compare to a supplied Jacobian and check agreement between two step sizes."""
    x = _point(point)
    step = _step(relative_step)
    atol, rtol = nonnegative(atol, "atol"), nonnegative(rtol, "rtol")
    baseline = _evaluate(function, x)
    exact = real_array(analytic(x.copy()) if callable(analytic) else analytic, "Analytic Jacobian")
    if exact.shape != (baseline.size, x.size):
        raise ValueError("Analytic Jacobian must have shape (output size, input size).")
    coarse = _jacobian(function, x, baseline, step)
    fine = _jacobian(function, x, baseline, step / 2)
    with np.errstate(over="ignore", invalid="ignore"):
        error = np.abs(fine - exact)
        change = np.abs(fine - coarse)
        reference_bound = atol + rtol * np.abs(exact)
        refinement_bound = atol + rtol * np.maximum(np.abs(coarse), np.abs(fine))
    if not all(np.all(np.isfinite(v)) for v in (error, change, reference_bound, refinement_bound)):
        raise ValueError("Jacobian comparison overflowed; rescale the problem or tolerances.")
    return JacobianCheck(
        exact, fine, coarse, error, change,
        bool(np.all(error <= reference_bound)), bool(np.all(change <= refinement_bound)),
    )
