from fractions import Fraction
from math import inf, nextafter

import numpy as np
import pytest

from problem2_generic import propagate_covariance, validate_covariance
from problem2_generic.demo import demonstration


def test_exact_matrix_propagation_against_independent_integer_contraction():
    sigma = [[2, 1], [1, 3]]
    a = [[1, 2], [-1, 3], [0, 1]]
    exact = [[sum(Fraction(u[i]) * sigma[i][j] * v[j] for i in range(2) for j in range(2))
              for v in a] for u in a]
    np.testing.assert_array_equal(propagate_covariance(a, sigma), np.array(exact, dtype=float))


def test_rank_one_singular_covariance_and_rank_deficient_map():
    sigma = [[4, 2], [2, 1]]
    a = [[1, 2], [0, 1], [1, -1]]
    result = propagate_covariance(a, sigma)
    np.testing.assert_array_equal(result, [[16, 4, 4], [4, 1, 1], [4, 1, 1]])
    assert validate_covariance(sigma).positive_semidefinite
    assert validate_covariance(result).positive_semidefinite
    np.testing.assert_array_equal(propagate_covariance([[1, 1], [2, 2]], np.eye(2)), [[2, 4], [4, 8]])
    assert validate_covariance(np.zeros((2, 2)), rtol=0).positive_semidefinite


def test_positive_semidefinite_boundary_with_explicit_tolerance_and_no_projection():
    delta = 2.0**-42
    source = [[1, 0], [0, -delta]]
    assert not validate_covariance(source, rtol=0).positive_semidefinite
    assert validate_covariance(source, atol=delta, rtol=0).positive_semidefinite
    assert propagate_covariance(np.eye(2), source, atol=delta, rtol=0)[1, 1] == -delta
    with pytest.raises(ValueError, match="semidefinite"):
        propagate_covariance(np.eye(2), source, rtol=0)


def test_symmetry_tolerance_is_independent_of_psd_and_uses_scale():
    value = [[1, 2.0**-44], [0, 1]]
    strict = validate_covariance(value, rtol=0)
    assert not strict.symmetric and not strict.positive_semidefinite
    assert validate_covariance(value).symmetric
    np.testing.assert_array_equal(propagate_covariance(np.eye(2), value), [[1, 2.0**-45], [2.0**-45, 1]])
    with pytest.raises(ValueError, match="symmetric"):
        propagate_covariance(np.eye(2), [[1, 2], [0, 1]])


def test_near_binary64_limits_preserve_subnormal_identity_and_flag_overflow():
    tiny = nextafter(0, inf)
    assert propagate_covariance([[1]], [[tiny]])[0, 0] == tiny
    assert validate_covariance([[1e308, 1e308], [1e308, 1e308]]).positive_semidefinite
    with pytest.raises(OverflowError):
        propagate_covariance([[1e308]], [[1]])


@pytest.mark.parametrize("bad", [[], [1, 2], [[1, 2]], [[1j]], [[np.nan]]])
def test_invalid_covariance_data_is_rejected(bad):
    with pytest.raises(ValueError):
        validate_covariance(bad)


def test_bad_map_shape_and_tolerance():
    with pytest.raises(ValueError, match="matching"):
        propagate_covariance([[1]], np.eye(2))
    with pytest.raises(ValueError, match="nonnegative"):
        validate_covariance(np.eye(2), atol=-1)


def test_fixed_demo_outputs_reference_matched_values():
    result = demonstration()
    assert result["covariance"] == result["covariance_exact_reference"]
    assert result["jacobian_max_absolute_error"] < 3e-10
