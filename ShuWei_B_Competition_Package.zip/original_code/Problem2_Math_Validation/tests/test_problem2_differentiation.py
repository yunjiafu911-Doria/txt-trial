import numpy as np
import pytest

from problem2_generic import check_jacobian, finite_difference_jacobian


def test_polynomial_jacobian_against_hand_differentiation():
    def f(p):
        x, y = p
        return [x*x + 3*y, x*y+y*y]

    check = check_jacobian(f, [2, -0.5], lambda p: [[2*p[0], 3], [p[1], p[0]+2*p[1]]])
    np.testing.assert_allclose(check.numerical, [[4, 3], [-0.5, 1]], atol=3e-10, rtol=0)
    assert check.matches and check.stable
    assert check.coarse.shape == check.refinement_change.shape == (2, 2)


def test_scalar_shape_and_incorrect_reference():
    matrix = finite_difference_jacobian(lambda x: 2*x[0] - 3*x[1], [2, 1])
    np.testing.assert_allclose(matrix, [[2, -3]], atol=3e-10, rtol=0)
    check = check_jacobian(lambda x: x[0]**2, [2], [[3]])
    assert not check.matches
    assert check.stable


def test_truncation_is_visible_with_cubic_and_coarse_steps():
    check = check_jacobian(lambda x: x[0]**3, [0], [[0]], relative_step=0.5, atol=1e-8, rtol=0)
    assert check.coarse[0, 0] == 0.25
    assert check.numerical[0, 0] == 0.0625
    assert check.refinement_change[0, 0] == 0.1875
    assert not check.matches and not check.stable


def test_unequal_representable_steps_for_a_linear_function():
    x, step = 1.0, 11 * 2.0**-55
    assert (x + step) - x != x - (x - step)
    result = finite_difference_jacobian(lambda p: p[0], [x], relative_step=step)
    assert result[0, 0] == 1.0


@pytest.mark.parametrize("step", [0, -1, 1e-30, float("inf")])
def test_invalid_or_unrepresentable_steps_are_reported(step):
    with pytest.raises(ValueError, match="step|representable"):
        finite_difference_jacobian(lambda x: x[0], [1], relative_step=step)


def test_shape_complex_and_finiteness_checks():
    with pytest.raises(ValueError, match="Analytic Jacobian"):
        check_jacobian(lambda x: x[0], [0], [1])
    with pytest.raises(ValueError, match="shape changed"):
        finite_difference_jacobian(lambda p: [0, 1] if p[0] > 0 else 0, [0])
    with pytest.raises(ValueError, match="real"):
        finite_difference_jacobian(lambda p: 1j, [0])
    with pytest.raises(ValueError, match="finite"):
        finite_difference_jacobian(lambda p: p[0], [np.nan])
