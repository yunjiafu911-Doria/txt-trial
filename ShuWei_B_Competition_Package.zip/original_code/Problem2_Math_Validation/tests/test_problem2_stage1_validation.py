import csv
from math import pi

import numpy as np
import pytest

from feasible_region.api import Point2D, Point3D
from problem2_generic import (
    check_jacobian, covariance_spectrum, jacobian_step_sweep, pairwise_angles,
    propagate_covariance, stack_measurements, validate_covariance,
)
from problem2_generic.validation import run_validation


def test_pairwise_angles_share_original_geometry_types():
    directions = (Point3D(1, 0, 0), Point3D(0, 1, 0), Point3D(-1, 0, 0))
    angles = pairwise_angles(iter(directions))
    np.testing.assert_array_equal(angles, [[0, pi / 2, pi], [pi / 2, 0, pi / 2], [pi, pi / 2, 0]])
    np.testing.assert_array_equal(pairwise_angles([Point2D(1, 0)]), [[0]])


@pytest.mark.parametrize("directions, message", [
    ([], "at least one"), ([Point2D(0, 0)], "zero vector"),
    ([Point2D(1, 0), Point3D(1, 0, 0)], "same dimension"),
])
def test_pairwise_angles_rejects_undefined_geometry(directions, message):
    with pytest.raises(ValueError, match=message):
        pairwise_angles(directions)


def test_stack_preserves_row_order_and_isolates_mutations():
    def first(p):
        result = 2 * p[0] - p[1]
        p[0] = 99
        return result

    combined = stack_measurements((first, lambda p: [p[0]**2, p[0] * p[1]]), output_sizes=(1, 2))
    point = np.array([3., 4.])
    np.testing.assert_array_equal(combined(point), [2, 9, 12])
    np.testing.assert_array_equal(point, [3, 4])
    reference = [[2, -1], [6, 0], [4, 3]]
    result = check_jacobian(combined, point, reference)
    assert result.matches and result.stable
    np.testing.assert_allclose(result.numerical, reference, atol=3e-10, rtol=0)


def test_stack_catches_changed_blocks_even_if_total_size_would_be_constant():
    one = lambda p: [1, 2] if p[0] > 0 else 1
    two = lambda p: 3 if p[0] > 0 else [2, 3]
    combined = stack_measurements((one, two), output_sizes=(1, 2))
    with pytest.raises(ValueError, match="Measurement 0 returned 2 values"):
        check_jacobian(combined, [0], [[0], [0], [0]])


@pytest.mark.parametrize("sizes", [(1,), (0, 1), (True, 1), (1.5, 1)])
def test_stack_validates_output_schema(sizes):
    with pytest.raises(ValueError, match="output size"):
        stack_measurements((lambda p: 0, lambda p: 1), output_sizes=sizes)


def test_step_sweep_matches_exact_cubic_truncation():
    steps = (0.5, 0.25, 0.125)
    results = jacobian_step_sweep(lambda p: p[0]**3, [0], [[0]], iter(steps), atol=0, rtol=0)
    assert tuple(step for step, _ in results) == steps
    for step, check in results:
        assert check.coarse[0, 0] == step**2
        assert check.numerical[0, 0] == (step / 2)**2
        assert not check.matches and not check.stable


def test_a_small_positive_eigenvalue_has_tolerance_dependent_numerical_rank():
    delta = 2.0**-42
    covariance = [[1, 0], [0, delta]]
    ordinary = covariance_spectrum(covariance)
    exact_threshold = covariance_spectrum(covariance, rtol=0)
    assert ordinary.scaled_eigenvalues == exact_threshold.scaled_eigenvalues == (delta, 1)
    assert ordinary.check.positive_semidefinite and exact_threshold.check.positive_semidefinite
    assert ordinary.numerical_rank == 1 and ordinary.near_singular
    assert exact_threshold.numerical_rank == 2 and not exact_threshold.near_singular
    zero = covariance_spectrum(np.zeros((2, 2)))
    assert zero.numerical_rank == 0 and zero.near_singular


@pytest.mark.parametrize("matrix, issue", [
    ([[1e300, 1e-300], [0, 0]], "symmetric"),
    ([[1e300, 0], [0, -1e-300]], "semidefinite"),
    ([[1e300, 1e-300], [1e-300, 0]], "semidefinite"),
])
def test_zero_tolerance_does_not_erase_invalid_unscaled_entries(matrix, issue):
    check = validate_covariance(matrix, rtol=0)
    assert not check.positive_semidefinite
    if issue == "symmetric":
        assert not check.symmetric and check.scaled_asymmetry == 0
    with pytest.raises(ValueError, match=issue):
        propagate_covariance(np.eye(2), matrix, rtol=0)


def test_fixed_validation_exports_reproducible_records(tmp_path):
    left, right = tmp_path / "first", tmp_path / "second"
    counts = run_validation(left)
    assert counts == run_validation(right)
    for name, expected in counts.items():
        path = left / name
        assert path.read_bytes() == (right / name).read_bytes()
        with path.open(encoding="utf-8", newline="") as stream:
            rows = list(csv.DictReader(stream))
        assert expected == len(rows)
        assert all(row["basis"] and row["status"] for row in rows)
    with (left / "numerical_stability.csv").open(encoding="utf-8", newline="") as stream:
        observed = list(csv.DictReader(stream))
    assert any(row["status"] == "expected_rejection" for row in observed)
    assert any(row["detail"] == "structural_rank=2" and row["numerical_rank"] == "1" for row in observed)
