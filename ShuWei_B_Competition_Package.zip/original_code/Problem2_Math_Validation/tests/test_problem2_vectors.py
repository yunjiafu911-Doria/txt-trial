from decimal import Decimal, localcontext
from math import inf, nextafter, pi, ulp

import pytest

from geometry import Point2D as OriginalPoint2D
from feasible_region.geometry3d.angles import azimuth as original_azimuth
from feasible_region.geometry3d.geometry import Point3D as OriginalPoint3D
from problem2_generic import (
    Point2D, Point3D, add, angle_between, azimuth, cross, dot, elevation,
    horizontal_distance, norm, scale, subtract, unit,
)


def test_reuses_original_geometry_types_and_direction_angle():
    assert Point2D is OriginalPoint2D
    assert Point3D is OriginalPoint3D
    assert azimuth is original_azimuth
    origin, end = Point3D(0, 0, 0), Point3D(0, 2, 2)
    assert horizontal_distance(origin, end) == 2
    assert azimuth(origin, end) == 90
    assert elevation(origin, end) == 45


def test_vector_arithmetic_and_exact_hand_computed_products():
    a, b = Point2D(3, 4), Point2D(2, -5)
    assert add(a, b) == Point2D(5, -1)
    assert subtract(a, b) == Point2D(1, 9)
    assert scale(a, 2) == Point2D(6, 8)
    assert dot(a, b) == -14
    assert norm(a) == 5
    assert unit(a) == Point2D(0.6, 0.8)

    u, v = Point3D(1, 2, 3), Point3D(4, -5, 6)
    w = cross(u, v)
    assert w == Point3D(27, 6, -13)
    assert dot(u, v) == 12
    assert dot(u, w) == dot(v, w) == 0
    assert add(u, v) == Point3D(5, -3, 9)


@pytest.mark.parametrize("zero,a", [(Point2D(0, 0), Point2D(1, 0)), (Point3D(0, 0, 0), Point3D(1, 0, 0))])
def test_zero_vectors_have_norm_but_no_angle_or_unit_direction(zero, a):
    assert norm(zero) == 0
    assert dot(zero, a) == 0
    with pytest.raises(ValueError, match="zero vector"):
        angle_between(a, zero)
    with pytest.raises(ValueError, match="zero vector"):
        unit(zero)


@pytest.mark.parametrize("sign,expected", [(1, 0), (-1, pi)])
def test_parallel_and_antiparallel_angles(sign, expected):
    a = Point3D(1, 2, 3)
    assert angle_between(a, scale(a, sign * 2)) == expected


def test_near_collinear_angle_against_independent_decimal_series():
    eps = 2.0**-27
    with localcontext() as ctx:
        ctx.prec = 75
        x = Decimal.from_float(eps)
        # Alternating arctan series with omitted remainder smaller than 1e-75.
        ref = sum((-1)**k * x**(2*k+1) / (2*k+1) for k in range(6))
    a, b = Point2D(1, 0), Point2D(1, eps)
    assert abs(angle_between(a, b) - float(ref)) <= ulp(float(ref))
    assert abs((pi - angle_between(a, Point2D(-1, eps))) - float(ref)) <= ulp(pi)
    assert angle_between(a, Point2D(0, 1)) == pi / 2


def test_near_cancellation_and_floating_range():
    y = nextafter(1.0, inf)
    a, b = Point2D(1, 1), Point2D(1, y)
    expected = (y - 1) / (1 + y)
    assert abs(angle_between(a, b) - expected) <= ulp(expected)
    assert dot(Point3D(1e308, 1e308, 1), Point3D(1e308, -1e308, 3)) == 3
    huge = Point2D(1.5e308, 1.5e308)
    assert norm(unit(huge)) == pytest.approx(1)
    with pytest.raises(OverflowError):
        norm(huge)
    assert angle_between(huge, Point2D(-1e-308, 1e-308)) == pi / 2


def test_dimension_and_factor_validation():
    with pytest.raises(ValueError, match="same dimension"):
        dot(Point2D(1, 2), Point3D(1, 2, 3))
    with pytest.raises(TypeError, match="Point3D"):
        cross(Point2D(1, 2), Point2D(2, 1))
    with pytest.raises(ValueError, match="finite"):
        scale(Point2D(1, 1), float("nan"))
