from fractions import Fraction
from math import inf, nextafter

import numpy as np
import pytest

from problem2_generic import covariance_spectrum, propagate_covariance, validate_covariance


@pytest.mark.parametrize("rtol", [0, 1e-12])
def test_scale_cannot_hide_negative_two_by_two_minor(rtol):
    covariance = [[1e300, 2], [2, 1e-300]]
    assert Fraction(covariance[0][0])*Fraction(covariance[1][1]) - 4 < 0
    assert not validate_covariance(covariance, rtol=rtol).positive_semidefinite
    with pytest.raises(ValueError, match="semidefinite"):
        propagate_covariance([[-2e-300, 1]], covariance, rtol=rtol)


def test_indefinite_three_by_three_with_positive_pairwise_minors_is_rejected():
    # Congruence of the correlation matrix with every off-diagonal equal to -3/4.
    # Its all-ones vector has eigenvalue -1/2 even though each 2x2 block is PSD.
    covariance = [[1e300, -7.5e149, -.75],
                  [-7.5e149, 1., -7.5e-151],
                  [-.75, -7.5e-151, 1e-300]]
    assert not validate_covariance(covariance).positive_semidefinite


def test_extreme_legal_covariance_preserves_small_positive_variance():
    covariance = [[1e300, .5], [.5, 1e-300]]
    assert validate_covariance(covariance, rtol=0).positive_semidefinite
    assert propagate_covariance([[0, 1]], covariance).item() == 1e-300


def test_distinguishes_near_singular_psd_from_negative_eigenvalue():
    positive_edge = nextafter(1., 0.)
    negative_edge = nextafter(1., inf)
    spectrum = covariance_spectrum([[1., positive_edge], [positive_edge, 1.]])
    assert spectrum.check.positive_semidefinite and spectrum.near_singular
    assert not validate_covariance([[1., negative_edge], [negative_edge, 1.]]).positive_semidefinite


def test_default_rejects_negative_diagonal_even_with_global_scale_disparity():
    covariance = [[1e300, 0], [0, -1e-300]]
    assert not validate_covariance(covariance).positive_semidefinite
    with pytest.raises(ValueError, match="semidefinite"):
        propagate_covariance(np.eye(2), covariance)


def test_strict_mode_detects_scaled_away_asymmetry():
    covariance = [[1e300, 1e-300], [0., 1e-300]]
    assert not validate_covariance(covariance, rtol=0).symmetric
    with pytest.raises(ValueError, match="symmetric"):
        propagate_covariance(np.eye(2), covariance, rtol=0)




def test_exact_recomputation_recovers_cancellation_prone_nonnegative_variance():
    covariance = np.array([[9., 21.], [21., 49.]])
    scale = .3
    linear_map = np.array([[scale, -scale*3/7]])
    exact = float((3*Fraction(scale) + 7*Fraction(float(linear_map[0, 1])))**2)
    assert exact > 0
    naive = float(((linear_map @ covariance) @ linear_map.T)[0, 0])
    propagated = propagate_covariance(linear_map, covariance).item()
    assert propagated >= 0
    if naive < 0:
        assert propagated == exact


