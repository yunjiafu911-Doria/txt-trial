"""Compare FCFS and SPT on one synthetic warehouse scenario."""

import argparse
from pathlib import Path

from .models import DispatchPolicy
from .reporting import plot_gantt, write_event_log, write_metrics
from .simulation import simulate
from .workload import warehouse_workload


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--tasks", type=int, default=16, help="Number of synthetic tasks.")
    parser.add_argument("--horizon", type=int, default=42, help="Inclusive simulation cutoff in ticks.")
    parser.add_argument("--output-dir", type=Path, default=Path("schedule_output"))
    args = parser.parse_args()

    resources, tasks, outages = warehouse_workload(args.seed, args.tasks)
    schedules = tuple(
        simulate(resources, tasks, policy=policy, outages=outages, horizon=args.horizon)
        for policy in DispatchPolicy
    )

    import matplotlib

    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    args.output_dir.mkdir(parents=True, exist_ok=True)
    print(f"Synthetic warehouse | seed {args.seed} | horizon {args.horizon}")
    for schedule in schedules:
        write_event_log(schedule, args.output_dir / f"{schedule.policy.value}_events.csv")
        print(
            f"{schedule.policy.value.upper():<4}  "
            f"complete {schedule.completed_count}/{len(schedule.outcomes)} "
            f"({schedule.completion_rate:.1%})  |  "
            f"max wait {schedule.max_waiting_time} ticks"
        )

    write_metrics(schedules, args.output_dir / "metrics.csv")
    figure = plot_gantt(schedules)
    figure.savefig(args.output_dir / "resource_gantt.png", dpi=160)
    plt.close(figure)
    print(f"Artifacts: {args.output_dir.resolve()}")


if __name__ == "__main__":
    main()
