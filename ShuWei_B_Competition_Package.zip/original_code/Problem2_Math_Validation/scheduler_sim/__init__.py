"""Teaching simulator for scheduling tasks that share several resource types."""
