"""Write simulation tables and draw resource timelines."""

import csv
import json
from collections.abc import Sequence
from pathlib import Path
from typing import TYPE_CHECKING

from .models import Schedule

if TYPE_CHECKING:
    from matplotlib.figure import Figure


def write_event_log(schedule: Schedule, path: str | Path) -> None:
    """Write the full trace in execution order, including same-time events."""
    with Path(path).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(("sequence", "time", "event", "task_id", "resource_ids", "remaining"))
        for sequence, event in enumerate(schedule.events, start=1):
            writer.writerow((
                sequence, event.time, event.kind.value, event.task_id,
                json.dumps(event.resource_ids, ensure_ascii=False), event.remaining,
            ))


def write_metrics(schedules: Sequence[Schedule], path: str | Path) -> None:
    with Path(path).open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow((
            "policy", "end_time", "arrived", "completed", "completion_rate", "max_waiting_time",
        ))
        for schedule in schedules:
            writer.writerow((
                schedule.policy.value, schedule.end_time, len(schedule.outcomes),
                schedule.completed_count, f"{schedule.completion_rate:.6f}", schedule.max_waiting_time,
            ))


def plot_gantt(schedules: Sequence[Schedule]) -> "Figure":
    """Plot actual working intervals and downtime on separate resource tracks."""
    from matplotlib import pyplot as plt
    from matplotlib.patches import Patch
    from matplotlib.ticker import MaxNLocator

    if not schedules:
        raise ValueError("At least one schedule is needed to draw a Gantt chart.")

    task_ids = sorted({outcome.task_id for schedule in schedules for outcome in schedule.outcomes})
    palette = plt.get_cmap("tab20")
    task_colors = {task_id: palette(i % palette.N) for i, task_id in enumerate(task_ids)}
    fig, axes = plt.subplots(
        len(schedules), 1, squeeze=False, sharex=True, figsize=(11, 2.9 * len(schedules)),
        layout="constrained",
    )

    for ax, schedule in zip(axes[:, 0], schedules):
        resource_ids = [resource.resource_id for resource in schedule.resources]
        positions = {resource_id: i for i, resource_id in enumerate(resource_ids)}
        for outage in schedule.outages:
            clipped_end = min(outage.end, schedule.end_time)
            if outage.start < clipped_end:
                ax.barh(
                    positions[outage.resource_id], clipped_end - outage.start,
                    left=outage.start, height=0.72, color="#e5e9ee",
                    edgecolor="#728095", linewidth=0.7, hatch="///",
                )

        for run in schedule.runs:
            width = run.end - run.start
            for resource_id in run.resource_ids:
                row = positions[resource_id]
                ax.barh(
                    row, width, left=run.start, height=0.54,
                    color=task_colors[run.task_id], edgecolor="white", linewidth=0.7,
                )
                if width >= 2:
                    ax.text(
                        run.start + width / 2, row, run.task_id,
                        ha="center", va="center", fontsize=8, color="#10243b",
                        bbox={"facecolor": "white", "alpha": 0.75, "edgecolor": "none", "pad": 1.2},
                    )

        ax.set_yticks(range(len(resource_ids)), labels=resource_ids)
        ax.set_ylim(max(1, len(resource_ids)) - 0.5, -0.5)
        ax.set_title(
            f"{schedule.policy.value.upper()}  |  {schedule.completed_count}/{len(schedule.outcomes)}"
            f" complete  |  max wait {schedule.max_waiting_time}",
            loc="left",
        )
        ax.grid(axis="x", color="#e5e9ee")
        ax.set_axisbelow(True)

    last_tick = max(schedule.end_time for schedule in schedules)
    axes[-1, 0].set(xlabel="Simulation time (ticks)", xlim=(0, max(1, last_tick)))
    axes[-1, 0].xaxis.set_major_locator(MaxNLocator(integer=True))
    axes[0, 0].legend(
        handles=[Patch(facecolor="#e5e9ee", edgecolor="#728095", hatch="///", label="Resource offline")],
        loc="lower right", bbox_to_anchor=(1, 1.015), borderaxespad=0,
    )
    return fig
