"""Deterministic event processing and dispatch for tasks with joint resource needs."""

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from heapq import heappop, heappush
from itertools import count

from .models import (
    DispatchPolicy,
    Event,
    EventKind,
    Outage,
    Resource,
    Schedule,
    Task,
    TaskOutcome,
    TaskRun,
    _require_tick,
)


_EVENT_PRIORITY = {
    EventKind.TASK_FINISH: 0,
    EventKind.RESOURCE_RECOVERY: 1,
    EventKind.RESOURCE_FAILURE: 2,
    EventKind.TASK_ARRIVAL: 3,
}


@dataclass(slots=True)
class _ActiveRun:
    start: int
    completion: Event


@dataclass(slots=True)
class _TaskState:
    task: Task
    remaining: int
    queued_at: int | None
    first_start: int | None = None
    finished_at: int | None = None
    waiting_time: int = 0
    active: _ActiveRun | None = None


def simulate(
    resources: Iterable[Resource],
    tasks: Iterable[Task],
    *,
    policy: DispatchPolicy | str = DispatchPolicy.FCFS,
    outages: Iterable[Outage] = (),
    horizon: int | None = None,
) -> Schedule:
    """Run a scenario until the event queue is empty or the inclusive horizon."""
    policy = DispatchPolicy(policy)
    if horizon is not None:
        _require_tick(horizon, "horizon")

    resource_list = tuple(sorted(resources, key=lambda resource: resource.resource_id))
    task_list = tuple(sorted(tasks, key=lambda task: (task.arrival, task.task_id)))
    outage_list = tuple(sorted(outages, key=lambda outage: (outage.start, outage.resource_id)))
    _validate_scenario(resource_list, task_list, outage_list)
    return _Simulation(resource_list, task_list, policy, outage_list).run(horizon)


def _validate_scenario(
    resources: tuple[Resource, ...], tasks: tuple[Task, ...], outages: tuple[Outage, ...]
) -> None:
    resource_ids = {resource.resource_id for resource in resources}
    if len(resource_ids) != len(resources):
        raise ValueError("Duplicate resource ID.")
    if len({task.task_id for task in tasks}) != len(tasks):
        raise ValueError("Duplicate task ID.")

    capacity = Counter(resource.kind for resource in resources)
    for task in tasks:
        for kind, required in Counter(task.requirements).items():
            if required > capacity[kind]:
                raise ValueError(f"Task {task.task_id!r} requires {required} resources of kind {kind!r}.")

    previous_end: dict[str, int] = {}
    for outage in outages:
        resource_id = outage.resource_id
        if resource_id not in resource_ids:
            raise ValueError(f"Outage refers to unknown resource {resource_id!r}.")
        if outage.start < previous_end.get(resource_id, 0):
            raise ValueError(f"Overlapping outages for resource {resource_id!r}.")
        previous_end[resource_id] = outage.end


class _Simulation:
    def __init__(
        self,
        resources: tuple[Resource, ...],
        tasks: tuple[Task, ...],
        policy: DispatchPolicy,
        outages: tuple[Outage, ...],
    ) -> None:
        self.resources = resources
        self.tasks = {task.task_id: task for task in tasks}
        self.policy = policy
        self.outages = outages
        self.states: dict[str, _TaskState] = {}
        self.owners: dict[str, str] = {}
        self.offline: set[str] = set()
        self.events: list[Event] = []
        self.runs: list[TaskRun] = []
        self.queue: list[tuple[int, int, int, Event]] = []
        self.sequence = count()

        for task in tasks:
            self._enqueue(Event(task.arrival, EventKind.TASK_ARRIVAL, task.task_id))
        for outage in outages:
            ids = (outage.resource_id,)
            self._enqueue(Event(outage.start, EventKind.RESOURCE_FAILURE, resource_ids=ids))
            self._enqueue(Event(outage.end, EventKind.RESOURCE_RECOVERY, resource_ids=ids))

    def _enqueue(self, event: Event) -> None:
        heappush(self.queue, (event.time, _EVENT_PRIORITY[event.kind], next(self.sequence), event))

    def run(self, horizon: int | None) -> Schedule:
        now = 0
        while self.queue and (horizon is None or self.queue[0][0] <= horizon):
            now = self.queue[0][0]
            while self.queue and self.queue[0][0] == now:
                self._apply(heappop(self.queue)[3])
            self._dispatch(now)

        return self._summarize(now if horizon is None else horizon)

    def _apply(self, event: Event) -> None:
        now = event.time
        match event.kind:
            case EventKind.TASK_ARRIVAL:
                assert event.task_id is not None
                task = self.tasks[event.task_id]
                self.states[task.task_id] = _TaskState(task, task.duration, now)
                self.events.append(event)
            case EventKind.TASK_FINISH:
                assert event.task_id is not None
                state = self.states[event.task_id]
                # Pausing can leave old completion events in the heap.
                if state.active is not None and state.active.completion is event:
                    state.finished_at = now
                    self._stop(state, now, EventKind.TASK_FINISH)
            case EventKind.RESOURCE_FAILURE:
                (resource_id,) = event.resource_ids
                self.offline.add(resource_id)
                task_id = self.owners.get(resource_id)
                self.events.append(Event(now, event.kind, task_id, event.resource_ids))
                if task_id is not None:
                    state = self.states[task_id]
                    state.queued_at = now
                    self._stop(state, now, EventKind.TASK_PAUSE)
            case EventKind.RESOURCE_RECOVERY:
                self.offline.remove(event.resource_ids[0])
                self.events.append(event)

    def _dispatch(self, now: int) -> None:
        waiting = sorted(
            (state for state in self.states.values() if state.queued_at is not None),
            key=self._dispatch_key,
        )
        available: dict[str, list[str]] = {}
        for resource in self.resources:
            resource_id = resource.resource_id
            if resource_id not in self.offline and resource_id not in self.owners:
                available.setdefault(resource.kind, []).append(resource_id)

        for state in waiting:
            requirements = Counter(state.task.requirements)
            if any(len(available.get(kind, ())) < needed for kind, needed in requirements.items()):
                continue
            chosen = []
            for kind, needed in requirements.items():
                chosen.extend(available[kind][:needed])
                del available[kind][:needed]
            self._start(state, now, tuple(sorted(chosen)))

    def _dispatch_key(self, state: _TaskState) -> tuple[int, int, str]:
        task = state.task
        primary = task.arrival if self.policy is DispatchPolicy.FCFS else task.duration
        return primary, task.arrival, task.task_id

    def _start(self, state: _TaskState, now: int, resource_ids: tuple[str, ...]) -> None:
        assert state.queued_at is not None
        task_id = state.task.task_id
        for resource_id in resource_ids:
            self.owners[resource_id] = task_id
            self.events.append(Event(now, EventKind.RESOURCE_ACQUIRED, task_id, (resource_id,)))
        if state.first_start is None:
            state.first_start = now
            kind = EventKind.TASK_START
        else:
            kind = EventKind.TASK_RESUME

        state.waiting_time += now - state.queued_at
        state.queued_at = None
        self.events.append(Event(now, kind, task_id, resource_ids, state.remaining))
        completion = Event(now + state.remaining, EventKind.TASK_FINISH, task_id, resource_ids)
        state.active = _ActiveRun(now, completion)
        self._enqueue(completion)

    def _stop(self, state: _TaskState, now: int, kind: EventKind) -> None:
        assert state.active is not None
        task_id = state.task.task_id
        resource_ids = state.active.completion.resource_ids
        self.runs.append(TaskRun(task_id, resource_ids, state.active.start, now))
        state.remaining -= now - state.active.start
        state.active = None
        self.events.append(Event(now, kind, task_id, resource_ids, state.remaining))
        for resource_id in resource_ids:
            del self.owners[resource_id]
            self.events.append(Event(now, EventKind.RESOURCE_RELEASED, task_id, (resource_id,)))

    def _summarize(self, end_time: int) -> Schedule:
        runs = self.runs.copy()
        outcomes = []
        for state in self.states.values():
            waiting_time = state.waiting_time
            remaining = state.remaining
            if state.queued_at is not None:
                waiting_time += end_time - state.queued_at
            if state.active is not None:
                elapsed = end_time - state.active.start
                remaining -= elapsed
                if elapsed > 0:
                    runs.append(TaskRun(
                        state.task.task_id, state.active.completion.resource_ids,
                        state.active.start, end_time,
                    ))

            outcomes.append(TaskOutcome(
                state.task.task_id, state.task.arrival, state.first_start,
                state.finished_at, waiting_time, remaining,
            ))
        return Schedule(
            self.policy, end_time, self.resources, tuple(self.events),
            tuple(sorted(runs, key=lambda run: (run.start, run.task_id))),
            self.outages, tuple(outcomes),
        )
