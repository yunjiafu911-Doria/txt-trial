"""Inputs and outputs for the discrete-event simulator."""

from dataclasses import dataclass
from enum import Enum


class DispatchPolicy(str, Enum):
    FCFS = "fcfs"
    SPT = "spt"


class EventKind(str, Enum):
    TASK_ARRIVAL = "task_arrival"
    RESOURCE_ACQUIRED = "resource_acquired"
    TASK_START = "task_start"
    TASK_FINISH = "task_finish"
    RESOURCE_RELEASED = "resource_released"
    RESOURCE_FAILURE = "resource_failure"
    RESOURCE_RECOVERY = "resource_recovery"
    TASK_PAUSE = "task_pause"
    TASK_RESUME = "task_resume"


def _require_name(value: str, name: str) -> None:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} must be a nonempty string.")


def _require_tick(value: int, name: str, *, minimum: int = 0) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer of at least {minimum}.")


@dataclass(frozen=True, slots=True)
class Resource:
    resource_id: str
    kind: str

    def __post_init__(self) -> None:
        _require_name(self.resource_id, "resource_id")
        _require_name(self.kind, "kind")


@dataclass(frozen=True, slots=True)
class Task:
    task_id: str
    arrival: int
    duration: int
    requirements: tuple[str, ...]

    def __post_init__(self) -> None:
        _require_name(self.task_id, "task_id")
        _require_tick(self.arrival, "arrival")
        _require_tick(self.duration, "duration", minimum=1)
        if isinstance(self.requirements, str):
            raise ValueError("requirements must be a collection of resource kinds.")
        requirements = tuple(self.requirements)
        if not requirements:
            raise ValueError("A task must require at least one resource.")
        for kind in requirements:
            _require_name(kind, "required resource kind")
        object.__setattr__(self, "requirements", requirements)


@dataclass(frozen=True, slots=True)
class Outage:
    """One resource is unavailable over the half-open interval [start, end)."""

    resource_id: str
    start: int
    end: int

    def __post_init__(self) -> None:
        _require_name(self.resource_id, "resource_id")
        _require_tick(self.start, "outage start")
        _require_tick(self.end, "outage end", minimum=self.start + 1)


@dataclass(frozen=True, slots=True)
class Event:
    time: int
    kind: EventKind
    task_id: str | None = None
    resource_ids: tuple[str, ...] = ()
    remaining: int | None = None


@dataclass(frozen=True, slots=True)
class TaskRun:
    task_id: str
    resource_ids: tuple[str, ...]
    start: int
    end: int


@dataclass(frozen=True, slots=True)
class TaskOutcome:
    task_id: str
    arrival: int
    first_start: int | None
    finished_at: int | None
    waiting_time: int
    remaining: int


@dataclass(frozen=True, slots=True)
class Schedule:
    policy: DispatchPolicy
    end_time: int
    resources: tuple[Resource, ...]
    events: tuple[Event, ...]
    runs: tuple[TaskRun, ...]
    outages: tuple[Outage, ...]
    outcomes: tuple[TaskOutcome, ...]

    @property
    def completed_count(self) -> int:
        return sum(outcome.finished_at is not None for outcome in self.outcomes)

    @property
    def completion_rate(self) -> float:
        """Fraction of tasks that arrived by the cutoff and finished by it."""
        return self.completed_count / len(self.outcomes) if self.outcomes else 0.0

    @property
    def max_waiting_time(self) -> int:
        """Maximum accrued queue time, including waits after an interruption."""
        return max((outcome.waiting_time for outcome in self.outcomes), default=0)
