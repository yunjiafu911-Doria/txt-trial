"""Generate synthetic warehouse tasks and outages from a fixed random seed."""

from random import Random

from .models import Outage, Resource, Task, _require_tick


def warehouse_workload(
    seed: int, task_count: int = 16
) -> tuple[tuple[Resource, ...], tuple[Task, ...], tuple[Outage, ...]]:
    """Return the same scenario for a given seed and task count."""
    _require_tick(task_count, "task_count")
    rng = Random(seed)
    resources = (
        Resource("Robot 1", "robot"),
        Resource("Robot 2", "robot"),
        Resource("Scanner", "scanner"),
        Resource("Packing bench", "bench"),
    )
    job_templates = (
        (("robot",), 2, 7),
        (("robot", "scanner"), 3, 8),
        (("robot", "bench"), 4, 9),
        (("bench",), 2, 6),
    )

    tasks = []
    arrival = 0
    for number in range(1, task_count + 1):
        requirements, low, high = rng.choice(job_templates)
        tasks.append(Task(f"T{number:02}", arrival, rng.randint(low, high), requirements))
        arrival += rng.randint(0, 3)

    robot_down = rng.randint(6, 10)
    bench_down = rng.randint(13, 20)
    outages = (
        Outage("Robot 1", robot_down, robot_down + rng.randint(3, 6)),
        Outage("Packing bench", bench_down, bench_down + rng.randint(4, 7)),
    )
    return resources, tuple(tasks), outages
