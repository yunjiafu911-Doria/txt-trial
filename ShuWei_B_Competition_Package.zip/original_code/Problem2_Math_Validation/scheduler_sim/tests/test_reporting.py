import csv
import json

import matplotlib

from scheduler_sim.models import DispatchPolicy, EventKind, Outage, Resource, Task
from scheduler_sim.reporting import plot_gantt, write_event_log, write_metrics
from scheduler_sim.simulation import simulate


def test_logs_metrics_and_resource_gantt(tmp_path):
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    resource_id = "robot,1"
    resources = [Resource(resource_id, "worker")]
    tasks = [Task("A", 0, 3, ("worker",))]
    schedules = tuple(
        simulate(resources, tasks, policy=policy, outages=[Outage(resource_id, 1, 3)])
        for policy in DispatchPolicy
    )
    log_path = tmp_path / "events.csv"
    write_event_log(schedules[0], log_path)
    with log_path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    assert [int(row["sequence"]) for row in rows] == list(range(1, len(rows) + 1))
    assert [row["event"] for row in rows] == [event.kind.value for event in schedules[0].events]
    failure = next(row for row in rows if row["event"] == EventKind.RESOURCE_FAILURE.value)
    assert json.loads(failure["resource_ids"]) == [resource_id]

    metrics_path = tmp_path / "metrics.csv"
    write_metrics(schedules, metrics_path)
    with metrics_path.open(newline="", encoding="utf-8") as stream:
        metrics = list(csv.DictReader(stream))
    assert [row["policy"] for row in metrics] == ["fcfs", "spt"]
    assert all(float(row["completion_rate"]) == 1 for row in metrics)
    assert all(int(row["max_waiting_time"]) == 2 for row in metrics)

    figure = plot_gantt(schedules)
    try:
        assert len(figure.axes) == 2
        assert all(len(ax.patches) == 3 for ax in figure.axes)
        png_path = tmp_path / "gantt.png"
        figure.savefig(png_path)
        assert png_path.read_bytes().startswith(b"\x89PNG\r\n\x1a\n")
    finally:
        plt.close(figure)
