import pytest

from scheduler_sim.models import DispatchPolicy, EventKind, Outage, Resource, Task
from scheduler_sim.simulation import simulate
from scheduler_sim.workload import warehouse_workload


def started(schedule):
    return [event.task_id for event in schedule.events if event.kind is EventKind.TASK_START]


def test_policies_choose_different_feasible_tasks_and_report_cutoff_metrics():
    resources = [Resource("R", "worker")]
    tasks = [
        Task("C", 1, 1, ("worker",)),
        Task("B", 0, 2, ("worker",)),
        Task("A", 0, 5, ("worker",)),
    ]
    fcfs = simulate(resources, tasks, horizon=4)
    spt = simulate(resources, tasks, policy=DispatchPolicy.SPT, horizon=4)
    assert started(fcfs) == ["A"]
    assert started(spt) == ["B", "C", "A"]
    assert fcfs.completion_rate == 0
    assert spt.completion_rate == 2 / 3
    assert fcfs.max_waiting_time == 4
    assert spt.max_waiting_time == 3


def test_task_acquires_all_required_resources_together_and_skips_blocked_tasks():
    resources = [Resource("R2", "robot"), Resource("S", "station"), Resource("R1", "robot")]
    tasks = [
        Task("station-job", 0, 4, ("station",)),
        Task("joint-job", 1, 2, ("robot", "robot", "station")),
        Task("move", 2, 1, ("robot",)),
    ]
    schedule = simulate(resources, tasks)
    assert started(schedule) == ["station-job", "move", "joint-job"]
    assert [(run.task_id, run.start, run.resource_ids) for run in schedule.runs] == [
        ("station-job", 0, ("S",)), ("move", 2, ("R1",)), ("joint-job", 4, ("R1", "R2", "S")),
    ]
    acquisition = [
        event for event in schedule.events
        if event.kind is EventKind.RESOURCE_ACQUIRED and event.task_id == "joint-job"
    ]
    assert len(acquisition) == 3
    assert {event.time for event in acquisition} == {4}
    assert schedule.completion_rate == 1


def test_fault_releases_the_full_bundle_and_resumes_with_a_substitute():
    resources = [Resource("A", "robot"), Resource("B", "robot"), Resource("S", "station")]
    tasks = [Task("job", 0, 7, ("robot", "station"))]
    schedule = simulate(resources, tasks, outages=[Outage("A", 2, 8)])
    assert [(run.start, run.end, run.resource_ids) for run in schedule.runs] == [
        (0, 2, ("A", "S")), (2, 7, ("B", "S")),
    ]
    events_at_two = [event for event in schedule.events if event.time == 2]
    assert [(event.kind, event.resource_ids) for event in events_at_two] == [
        (EventKind.RESOURCE_FAILURE, ("A",)),
        (EventKind.TASK_PAUSE, ("A", "S")),
        (EventKind.RESOURCE_RELEASED, ("A",)),
        (EventKind.RESOURCE_RELEASED, ("S",)),
        (EventKind.RESOURCE_ACQUIRED, ("B",)),
        (EventKind.RESOURCE_ACQUIRED, ("S",)),
        (EventKind.TASK_RESUME, ("B", "S")),
    ]
    assert events_at_two[-1].remaining == 5
    assert sum(event.kind is EventKind.TASK_FINISH for event in schedule.events) == 1
    assert schedule.outcomes[0].waiting_time == 0


def test_paused_task_waits_and_original_completion_is_ignored():
    schedule = simulate(
        [Resource("A", "robot")], [Task("job", 0, 7, ("robot",))],
        outages=[Outage("A", 2, 5)],
    )
    outcome, = schedule.outcomes
    assert outcome.finished_at == 10
    assert outcome.remaining == 0
    assert outcome.waiting_time == 3
    assert schedule.max_waiting_time == 3
    assert all(event.time != 7 for event in schedule.events)


def test_same_tick_completion_recovery_failure_and_arrival_precede_dispatch():
    schedule = simulate(
        [Resource("A", "robot"), Resource("B", "robot")],
        [Task("first", 0, 2, ("robot",)), Task("second", 2, 1, ("robot",))],
        outages=[Outage("A", 2, 4), Outage("B", 0, 2)],
    )
    assert [event.kind for event in schedule.events if event.time == 2] == [
        EventKind.TASK_FINISH, EventKind.RESOURCE_RELEASED, EventKind.RESOURCE_RECOVERY,
        EventKind.RESOURCE_FAILURE, EventKind.TASK_ARRIVAL, EventKind.RESOURCE_ACQUIRED,
        EventKind.TASK_START,
    ]
    assert schedule.runs[1].resource_ids == ("B",)


def test_adjacent_outages_leave_no_gap_to_dispatch():
    schedule = simulate(
        [Resource("A", "robot")], [Task("job", 1, 2, ("robot",))],
        outages=[Outage("A", 1, 2), Outage("A", 2, 4)],
    )
    assert schedule.outcomes[0].first_start == 4
    assert schedule.outcomes[0].waiting_time == 3


def test_cutoff_counts_accrued_wait_and_excludes_future_arrivals():
    schedule = simulate(
        [Resource("R", "worker")],
        [Task("A", 0, 8, ("worker",)), Task("B", 3, 2, ("worker",)), Task("C", 5, 1, ("worker",))],
        outages=[Outage("R", 2, 6)], horizon=4,
    )
    assert [(job.task_id, job.waiting_time, job.remaining) for job in schedule.outcomes] == [
        ("A", 2, 6), ("B", 1, 2),
    ]
    assert schedule.completion_rate == 0
    assert schedule.max_waiting_time == 2
    assert all(event.time <= 4 for event in schedule.events)


def test_cutoff_clips_active_run_without_emitting_a_completion():
    schedule = simulate([Resource("R", "worker")], [Task("A", 0, 5, ("worker",))], horizon=3)
    assert (schedule.runs[0].start, schedule.runs[0].end) == (0, 3)
    assert schedule.outcomes[0].remaining == 2
    assert schedule.outcomes[0].finished_at is None
    assert all(event.kind is not EventKind.TASK_FINISH for event in schedule.events)


def test_empty_schedule_has_defined_metrics():
    schedule = simulate([], [], horizon=7)
    assert schedule.end_time == 7
    assert schedule.completion_rate == 0
    assert schedule.max_waiting_time == 0


@pytest.mark.parametrize(
    ("extra", "message"),
    [
        ([Outage("missing", 1, 3)], "unknown resource"),
        ([Outage("R", 1, 4), Outage("R", 3, 6)], "Overlapping outages"),
    ],
)
def test_invalid_outages(extra, message):
    with pytest.raises(ValueError, match=message):
        simulate([Resource("R", "worker")], [], outages=extra)


def test_input_validation_rejects_impossible_requirements_and_duplicate_ids():
    with pytest.raises(ValueError, match="requires 2"):
        simulate([Resource("R", "worker")], [Task("A", 0, 1, ("worker", "worker"))])
    with pytest.raises(ValueError, match="Duplicate resource ID"):
        simulate([Resource("R", "worker"), Resource("R", "robot")], [])
    with pytest.raises(ValueError, match="Duplicate task ID"):
        task = Task("A", 0, 1, ("worker",))
        simulate([Resource("R", "worker")], [task, task])


@pytest.mark.parametrize("duration", [0, -1, 1.5, True])
def test_task_requires_positive_integer_duration(duration):
    with pytest.raises(ValueError, match="duration"):
        Task("A", 0, duration, ("worker",))


@pytest.mark.parametrize("policy", list(DispatchPolicy))
def test_reproducible_workload_and_schedule_respect_resource_capacity(policy):
    resources, tasks, outages = warehouse_workload(42)
    assert (resources, tasks, outages) == warehouse_workload(42)
    assert (resources, tasks, outages) != warehouse_workload(43)
    schedule = simulate(resources, tasks, policy=policy, outages=outages)
    assert schedule == simulate(reversed(resources), reversed(tasks), policy=policy, outages=reversed(outages))
    assert schedule.completed_count == len(tasks)
    assert [e.time for e in schedule.events] == sorted(e.time for e in schedule.events)
    for resource in resources:
        runs = [run for run in schedule.runs if resource.resource_id in run.resource_ids]
        assert all(first.end <= second.start for first, second in zip(runs, runs[1:]))
        for outage in outages:
            if outage.resource_id == resource.resource_id:
                assert all(run.end <= outage.start or run.start >= outage.end for run in runs)
    for task in tasks:
        assert sum(run.end - run.start for run in schedule.runs if run.task_id == task.task_id) == task.duration
