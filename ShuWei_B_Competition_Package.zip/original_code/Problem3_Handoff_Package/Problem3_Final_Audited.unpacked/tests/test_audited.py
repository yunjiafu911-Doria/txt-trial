import csv
from math import atan, degrees, erf, isclose, pi, sqrt
from pathlib import Path
import sys

import numpy as np
import pytest

# The tests also run when collected from the enclosing workspace.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.experiment import CASES, analyze_case, fd_error, paired_difference, run, wilson
from src.model import Case, analytic, angle_errors, circular_summary, sample_errors, wrap_deg, wrapped_coverage
from src.reference import numeric_coverage


def test_degrees_radians_and_angle_sign():
    case = Case("units", 10, 0, 1, 1, 0, 0, 3)
    linear, _, nonlinear = angle_errors(case, 0, np.array([-1, 1]), 2, 0)
    np.testing.assert_allclose(linear, [degrees(0.1)+2, -degrees(0.1)+2], rtol=0, atol=1e-14)
    np.testing.assert_allclose(nonlinear, [degrees(atan(0.1))+2, -degrees(atan(0.1))+2], rtol=0, atol=1e-14)
    assert isclose(analytic(case)["linear_sd_deg"], 18/pi, rel_tol=1e-15)


def test_independent_angle_variances_add_before_square_root():
    case = Case("angle_only", 18, -83, 0, 0, 3, 4, 5)
    formula = analytic(case)
    assert (formula["position_var_deg2"], formula["offset_var_deg2"], formula["control_var_deg2"]) == (0, 9, 16)
    assert formula["linear_sd_deg"] == 5
    assert formula["linear_normal_coverage"] == erf(1/sqrt(2))


@pytest.mark.parametrize(("value", "expected"), [
    (-540, -180), (-360, 0), (-180, -180), (-181, 179), (0, 0),
    (179, 179), (180, -180), (181, -179), (360, 0), (540, -180),
])
def test_periodic_wrapping(value, expected):
    assert wrap_deg(value) == expected


def test_wrap_preserves_binary64_values_on_both_sides_of_cut():
    below = np.nextafter(180., 0.)
    above = np.nextafter(180., np.inf)
    assert wrap_deg(below) == below
    assert wrap_deg(above) == above - 360
    assert wrap_deg(-below) == -below
    assert wrap_deg(-above) == 360 - above
    assert -180 <= wrap_deg(1e300) < 180
    with pytest.raises(ValueError, match="finite"):
        wrap_deg(np.inf)


def test_wrap_last_non_linear_gives_different_event():
    case = Case("seam", 10, 0, 1, 1, 0, 0, 3)
    _, _, raw = angle_errors(case, 20, 0, -179, 0)
    assert raw == -359
    assert wrap_deg(raw) == 1
    assert wrapped_coverage(30, 720) == 1/6


def test_coincident_direction_is_explicitly_undefined():
    case = Case("coincident", 10, 0, 1, 1, 0, 0, 3)
    with pytest.raises(ValueError, match="coincident"):
        angle_errors(case, 10, 0)


def test_zero_fixture_does_not_divide_by_variance():
    case = next(case for case in CASES if case.name == "Zero")
    row, sensitivity = analyze_case(case, sample_errors(case, np.random.default_rng(111), 40))
    assert row["linear_sd_deg"] == row["mc_nonlinear_sd_deg"] == 0
    assert row["linear_wrapped_coverage"] == row["mc_nonlinear_coverage"] == 1
    assert all(item["linear_variance_share"] is None for item in sensitivity)


def test_tiny_angle_has_nonzero_circular_dispersion():
    delta = 1e-10
    resultant, center, sd = circular_summary(np.array([-delta, delta]))
    assert resultant == 1
    assert center == 0
    assert sd == pytest.approx(delta, rel=1e-15)


def test_tiny_position_errors_retain_the_expected_scale():
    case = next(case for case in CASES if case.name == "Tiny")
    row, _ = analyze_case(case, sample_errors(case, np.random.default_rng(31), 30_000))
    assert row["mc_nonlinear_sd_deg"] == pytest.approx(row["linear_sd_deg"], rel=0.03)
    assert abs(row["paired_delta"]) < 0.001


def test_independent_draws_have_small_pairwise_fisher_statistics():
    case = CASES[0]
    n = 40_000
    errors = sample_errors(case, np.random.default_rng(718), n)
    sample_correlations = np.corrcoef(errors)[np.triu_indices(4, k=1)]
    # Five approximate standard errors for Fisher z under independent bivariate normals.
    assert np.max(np.abs(np.arctanh(sample_correlations))) < 5/sqrt(n-3)


def test_analytic_gradient_and_hessian_against_global_coordinates():
    angle = next(case for case in CASES if case.name == "Oblique")
    j, h = fd_error(angle)
    assert j < 1e-9
    assert h < 1e-9
    assert analytic(angle)["quadratic_mean_deg"] > 0


def test_quadrature_has_independent_right_half_plane_answer():
    case = Case("sign", 10, 0, 7, 5, 0, 0, 90)
    probability, mass, _ = numeric_coverage(case)
    # |angle|<=90 iff the perturbed horizontal component is nonnegative.
    exact = (1 + erf(10/(sqrt(2)*7)))/2
    assert mass == pytest.approx(1.0, abs=1e-10)
    assert probability == pytest.approx(exact, abs=1e-10)


def test_large_position_error_fails_first_order_probability_model():
    case = next(case for case in CASES if case.name == "Wide_position")
    expected, _, _ = numeric_coverage(case)
    assert abs(expected - analytic(case)["linear_wrapped_coverage"]) > 0.04


def test_monte_carlo_wilson_contains_known_normal_fixture_reference():
    case = next(case for case in CASES if case.name == "Angle_only")
    row, _ = analyze_case(case, sample_errors(case, np.random.default_rng(17), 45_000))
    expected_probability = erf(1/sqrt(2))
    assert row["mc_coverage_low95"] <= expected_probability <= row["mc_coverage_high95"]
    assert row["mc_sd_low95_deg"] <= 5 <= row["mc_sd_high95_deg"]


def test_intervals_have_boundary_and_pairing_semantics():
    assert wilson(0, 100)[0] == 0
    assert wilson(100, 100)[1] == 1
    a = np.array([True, False, True, False])
    b = np.array([False, False, False, True])
    difference, _, low, high, wins, losses = paired_difference(a, b)
    assert (difference, wins, losses) == (0.25, 2, 1)
    assert low < difference < high
    _, _, low, high, _, _ = paired_difference(a, a)
    assert low < 0 < high


def test_csv_is_generated_from_arguments_and_reproduces_fixed_seed(tmp_path):
    case = Case("custom", 11, -30, 1, 0.6, 1, 2, 7)
    left, right, changed = (tmp_path/name for name in ("a", "b", "c"))
    rows, _ = run(left, size=8000, seed=123, cases=(case,), plots=False)
    run(right, size=8000, seed=123, cases=(case,), plots=False)
    run(changed, size=8000, seed=124, cases=(case,), plots=False)
    name = "Problem3_Numerical_Results.csv"
    assert (left/name).read_bytes() == (right/name).read_bytes()
    with (left/name).open(encoding="utf-8", newline="") as stream:
        row, = csv.DictReader(stream)
    with (changed/name).open(encoding="utf-8", newline="") as stream:
        other, = csv.DictReader(stream)
    assert (row["name"], row["seed"], row["samples"]) == ("custom", "123", "8000")
    assert float(row["mc_nonlinear_sd_deg"]) == rows[0]["mc_nonlinear_sd_deg"]
    assert row["linear_sd_deg"] == other["linear_sd_deg"]
    assert row["mc_nonlinear_sd_deg"] != other["mc_nonlinear_sd_deg"]
    with (left/"Problem3_Sensitivity.csv").open(encoding="utf-8", newline="") as stream:
        sensitivity = list(csv.DictReader(stream))
    assert len(sensitivity) == 3
    assert sum(float(item["linear_variance_share"]) for item in sensitivity) == pytest.approx(1.0)
