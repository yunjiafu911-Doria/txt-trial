from math import erf, radians, sqrt, tan

import numpy as np
import pytest
from scipy.integrate import quad
from scipy.special import ndtr
from scipy.stats import norm

from src.model import Case, analytic
from src.reference import numeric_coverage


@pytest.mark.parametrize("bearing,sx,sy", [(0, 1, 1e-7), (90, 1e-7, 1), (180, 1, 1e-7)])
@pytest.mark.parametrize("tolerance", [5, 3e-7])
def test_narrow_projected_peak_against_cartesian_conditioning(bearing, sx, sy, tolerance):
    case = Case("narrow", 10, bearing, sx, sy, 0, 0, tolerance)
    # Condition on longitudinal standard normal Z. The other coordinate is
    # independent and has SD 1e-7 in these exact cardinal cases.
    scale = tan(radians(tolerance))/(sqrt(2)*1e-7)
    expected = quad(lambda z: norm.pdf(z)*erf((10-z)*scale), -12, 10,
                    points=[0, 8, 9.9999], epsabs=1e-13)[0]
    probability, mass, error = numeric_coverage(case)
    assert probability == pytest.approx(expected, abs=1e-11)
    assert mass == pytest.approx(1, abs=1e-11)
    assert 0 <= error < 1e-10


def test_tiny_oblique_case_preserves_probability_with_additive_noise():
    case = Case("tiny", 12, 37, 1e-10, 2e-10, 2e-10, 4e-10, 1e-9)
    probability, mass, _ = numeric_coverage(case)
    # Second-order terms are O((sigma/distance)^2) in this small-error limit.
    assert probability == pytest.approx(analytic(case)["linear_wrapped_coverage"], abs=1e-9)
    assert mass == pytest.approx(1, abs=1e-11)


@pytest.mark.parametrize("bearing,sx,sy", [(90, 0, 3), (180, 3, 0), (270, 0, 3)])
def test_rank_one_along_direction_has_atom_at_zero(bearing, sx, sy):
    case = Case("atom", 2, bearing, sx, sy, 0, 0, 0)
    coverage, mass, _ = numeric_coverage(case)
    assert coverage == pytest.approx(ndtr(2/3), abs=1e-12)
    assert mass == pytest.approx(1, abs=1e-12)


def test_rank_one_transverse_direction_reduces_to_normal_interval():
    tau = 17
    case = Case("rank_one_cross", 2, 90, 3, 0, 0, 0, tau)
    coverage, mass, _ = numeric_coverage(case)
    assert coverage == pytest.approx(erf(2*tan(radians(tau))/(sqrt(2)*3)), abs=1e-12)
    assert mass == pytest.approx(1, abs=1e-12)


@pytest.mark.parametrize("tau,expected", [(0, 0), (180, 1)])
def test_continuous_probability_endpoints(tau, expected):
    assert numeric_coverage(Case("endpoint", 3, 55, 2, 1, 0, 0, tau))[0] == expected


def test_subnormal_angular_noise_keeps_cdf_limits_finite():
    case = Case("underflow", 1, 0, 0, 0, np.nextafter(0., 1.), 0, 5)
    assert numeric_coverage(case) == (1.0, 1.0, 0.0)


def test_unrepresentable_scale_ratio_fails_with_clear_error():
    case = Case("overflow", 1e300, 0, 1e-300, 1, 0, 0, 10)
    with pytest.raises(ValueError, match="Whitened mean"):
        numeric_coverage(case)

