"""Forward angular errors for an abstract two-dimensional measurement."""

from dataclasses import dataclass
from math import cos, erf, floor, hypot, isfinite, radians, sin, sqrt

import numpy as np
from scipy.special import ndtr


@dataclass(frozen=True)
class Case:
    name: str
    distance: float
    bearing_deg: float
    sx: float
    sy: float
    offset_sd_deg: float
    control_sd_deg: float
    tolerance_deg: float

    def __post_init__(self):
        values = (self.distance, self.bearing_deg, self.sx, self.sy,
                  self.offset_sd_deg, self.control_sd_deg, self.tolerance_deg)
        if not all(map(isfinite, values)):
            raise ValueError("Inputs must be finite.")
        if (self.distance <= 0 or min(values[2:]) < 0 or self.tolerance_deg > 180):
            raise ValueError("Distance must be positive, deviations nonnegative and tolerance in [0,180].")

    @property
    def direction(self):
        return np.array(_direction_deg(self.bearing_deg))


def _direction_deg(angle):
    if angle % 90 == 0:
        return ((1.0, 0.0), (0.0, 1.0), (-1.0, 0.0), (0.0, -1.0))[int(angle % 360 / 90)]
    return cos(radians(angle)), sin(radians(angle))


def wrap_deg(value):
    """Return angles in [-180, 180), preserving values adjacent to the cut."""
    angle = np.asarray(value, dtype=float)
    if not np.all(np.isfinite(angle)):
        raise ValueError("Angles must be finite.")
    remainder = np.fmod(angle, 360.0)
    return np.where(remainder >= 180, remainder - 360,
                    np.where(remainder < -180, remainder + 360, remainder))


def angle_errors(case, dx, dy, offset=0.0, control=0.0):
    dx, dy = np.asarray(dx), np.asarray(dy)
    ux, uy = case.direction
    parallel = ux*dx + uy*dy
    transverse = -uy*dx + ux*dy
    longitudinal = case.distance - parallel
    if np.any((longitudinal == 0) & (transverse == 0)):
        raise ValueError("Direction is undefined at coincident points.")
    additive = np.asarray(offset) + np.asarray(control)
    position_rad = np.arctan2(-transverse, longitudinal)
    linear_rad = -transverse / case.distance
    quadratic_rad = linear_rad - (parallel / case.distance) * (transverse / case.distance)
    return (np.degrees(linear_rad) + additive, np.degrees(quadratic_rad) + additive,
            np.degrees(position_rad) + additive)


def derivatives(case):
    """Gradients and Hessian in radians with respect to global x,y."""
    u = case.direction
    v = np.array((-u[1], u[0]))
    jacobian = -v / case.distance
    hessian = -(np.outer(u, v) + np.outer(v, u)) / case.distance**2
    return jacobian, hessian


def normal_coverage(tau, sd):
    if sd == 0:
        return 1.0
    return erf(tau / (sqrt(2) * sd))


def wrapped_coverage(tau, sd, mean=0.0):
    """Coverage of a normal angle on the circle, summing shifted intervals."""
    if tau == 180:
        return 1.0
    mean = float(wrap_deg(mean))
    if sd == 0:
        return float(abs(mean) <= tau)
    if sd >= 720:
        # The first nonconstant Fourier coefficient is at most exp(-8*pi**2).
        return tau / 180
    periods = 1 + floor((abs(mean) + tau + 10*sd) / 360)
    shifts = 360.0 * np.arange(-periods, periods + 1)
    with np.errstate(over="ignore"):
        lo, hi = (shifts - tau - mean) / sd, (shifts + tau - mean) / sd
    mass = np.where(lo > 0, ndtr(-lo) - ndtr(-hi), ndtr(hi) - ndtr(lo))
    return float(np.sum(mass))


def analytic(case):
    u = case.direction
    v = np.array((-u[1], u[0]))
    variances = np.square((case.sx, case.sy))
    jacobian, _ = derivatives(case)
    position = float(np.square(np.degrees(jacobian)) @ variances)
    offset = case.offset_sd_deg**2
    control = case.control_sd_deg**2
    total = position + offset + control
    covariance = float((u*v) @ variances)
    var_a = float(np.square(u) @ variances)
    var_b = float(np.square(v) @ variances)
    correction = float(np.degrees(1)**2 * (var_a*var_b + covariance**2) / case.distance**4)
    sd = sqrt(total)
    return {
        "position_var_deg2": position, "offset_var_deg2": offset, "control_var_deg2": control,
        "linear_sd_deg": sd, "linear_normal_coverage": normal_coverage(case.tolerance_deg, sd),
        "linear_wrapped_coverage": wrapped_coverage(case.tolerance_deg, sd),
        "quadratic_mean_deg": float(np.degrees(-covariance/case.distance**2)),
        "quadratic_sd_deg": sqrt(total + correction),
    }


def sample_errors(case, generator, size):
    return tuple(generator.normal(0, sd, size) for sd in
                 (case.sx, case.sy, case.offset_sd_deg, case.control_sd_deg))


def coverage_mask(angle_deg, tolerance_deg):
    return np.abs(wrap_deg(angle_deg)) <= tolerance_deg


def circular_summary(angle_deg):
    angle = np.radians(angle_deg)
    sine, cosine = float(np.sin(angle).mean()), float(np.cos(angle).mean())
    resultant = min(1.0, hypot(sine, cosine))
    center = np.arctan2(sine, cosine)
    if resultant == 0:
        return resultant, None, None
    if resultant > 0.5:
        # 1-R computed through a small-angle identity to avoid subtracting nearly equal values.
        gap = float(2*np.mean(np.square(np.sin((angle - center)/2))))
        dispersion = -2*np.log1p(-gap)
    else:
        dispersion = -2*np.log(resultant)
    return resultant, float(wrap_deg(np.degrees(center))), float(np.degrees(np.sqrt(dispersion)))


