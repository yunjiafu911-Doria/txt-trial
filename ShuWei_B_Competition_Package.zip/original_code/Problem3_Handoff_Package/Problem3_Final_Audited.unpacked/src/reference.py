"""Independent global-vector and projected-normal checks."""

from math import asin, atan2, cos, degrees, exp, hypot, isfinite, pi, remainder, sin, sqrt

import numpy as np
from scipy.integrate import quad
from scipy.special import ndtr

from .model import _direction_deg, wrapped_coverage


_TAIL_RADIUS = 12.0
_TAIL_BOUND = exp(-0.5 * _TAIL_RADIUS**2)
_ABS_ERROR = 1e-12
_MASS_ERROR = 1e-9


def global_angle(case, dx, dy, offset=0.0, control=0.0):
    """Signed angle between nominal and perturbed global vectors."""
    ux, uy = case.direction
    x, y = case.distance*ux - dx, case.distance*uy - dy
    return np.degrees(np.arctan2(ux*y - uy*x, ux*x + uy*y)) + offset + control


def _coverage_edges(tolerance, angular_sd):
    """Locate the step boundaries and the shoulders of a narrow smoothing kernel."""
    shifts = (0.0,) if angular_sd == 0 else (-8*angular_sd, -angular_sd, 0.0, angular_sd, 8*angular_sd)
    return {remainder(sign*tolerance + shift, 360.0)
            for sign in (-1, 1) for shift in shifts}


def _integrate(integrand, limit, points):
    points = sorted({point for point in points if -limit < point < limit})
    result = quad(integrand, -limit, limit, points=points, epsabs=_ABS_ERROR,
                  epsrel=_ABS_ERROR, limit=len(points)+50, full_output=True)
    if len(result) != 3 or not all(map(isfinite, result[:2])):
        raise ArithmeticError("Projected normal quadrature did not converge.")
    return result[:2]


def _regular_measure(case):
    """Map an isotropic projected normal's angle to the physical bearing."""
    ux, uy = map(float, case.direction)
    largest_sd = max(case.sx, case.sy)
    sx, sy = case.sx / largest_sd, case.sy / largest_sd
    cross = hypot(ux*sy, uy*sx)
    if cross == 0:
        raise ValueError("Position scale ratio exceeds the floating-point range.")
    along = sx*sy/cross
    shear = ux*uy*(sy*sy - sx*sx)/cross
    forward_sd = largest_sd * along
    if forward_sd == 0:
        raise ValueError("Position scale ratio exceeds the floating-point range.")
    mean = case.distance / forward_sd
    if not isfinite(mean):
        raise ValueError("Whitened mean exceeds the floating-point range.")

    scale = max(1.0, mean)
    # Outside these rays the whitened perturbation must have radius at least 12.
    truncated = mean >= 2*_TAIL_RADIUS
    limit = scale*asin(_TAIL_RADIUS/mean) if truncated else scale*pi
    origin_term = exp(-0.5 * mean**2) / scale if not truncated else 0.0

    def density(value):
        theta = value/scale
        along_mean = mean*cos(theta)
        transverse = mean*sin(theta)
        return max(0.0, origin_term + sqrt(2*pi)*(along_mean/scale)
                   *exp(-0.5*transverse**2)*ndtr(along_mean))/(2*pi)

    def angle(value):
        theta = value/scale
        return degrees(atan2(cross*sin(theta), along*cos(theta) + shear*sin(theta)))

    def boundary(beta):
        c, s = _direction_deg(beta)
        # Scale before atan2 to retain tiny positive/negative physical angles.
        return scale*atan2(along*s, cross*c - shear*s)

    return density, angle, boundary, limit, _TAIL_BOUND if truncated else 0.0


def _singular_measure(case):
    """A single noisy Cartesian coordinate gives a one-dimensional normal integral."""
    ux, uy = map(float, case.direction)
    scale = max(case.distance, case.sx, case.sy)
    nominal = case.distance/scale
    along = (ux*case.sx + uy*case.sy)/scale
    cross = (uy*case.sx - ux*case.sy)/scale
    if nominal == 0:
        raise ValueError("Position scale ratio exceeds the floating-point range.")

    def density(value):
        return exp(-0.5*value*value)/sqrt(2*pi)

    def angle(value):
        return degrees(atan2(cross*value, nominal - along*value))

    def boundary(beta):
        c, s = _direction_deg(beta)
        denominator = cross*c + along*s
        return nominal*s/denominator if denominator else 0.0

    reversal = nominal/along if along else 0.0
    return (density, angle, boundary, _TAIL_RADIUS, 2*ndtr(-_TAIL_RADIUS), reversal)


def numeric_coverage(case):
    """Return coverage, integrated mass, and an absolute error estimate.

    The nondegenerate quadrature uses angular coordinates in the whitened frame,
    scaled to resolve the projected normal peak. Rank-one position noise uses
    a scalar Gaussian integral. The error estimate includes any discarded tail.
    """
    tau = case.tolerance_deg
    angular_sd = hypot(case.offset_sd_deg, case.control_sd_deg)
    if not isfinite(angular_sd):
        raise ValueError("Combined angular standard deviation exceeds floating-point range.")
    if tau == 180 or case.sx == case.sy == 0:
        return wrapped_coverage(tau, angular_sd), 1.0, 0.0

    points = [-8.0, -4.0, -1.0, 0.0, 1.0, 4.0, 8.0]
    if min(case.sx, case.sy) > 0:
        density, angle, boundary, limit, omitted_tail = _regular_measure(case)
    else:
        density, angle, boundary, limit, omitted_tail, reversal = _singular_measure(case)
        points.append(reversal)

    mass, mass_error = _integrate(density, limit, points)
    if abs(mass - 1.0) > _MASS_ERROR:
        raise ArithmeticError("Projected normal failed the probability mass check.")
    if tau == 0 and (angular_sd > 0 or min(case.sx, case.sy) > 0):
        return 0.0, mass, mass_error + omitted_tail
    if angular_sd >= 720:
        # Same uniform approximation as wrapped_coverage, with the leading harmonic bound.
        return tau/180.0, mass, mass_error + omitted_tail + 4*exp(-8*pi*pi)

    points.extend(boundary(beta) for beta in _coverage_edges(tau, angular_sd))

    def integrand(value):
        return density(value)*wrapped_coverage(tau, angular_sd, angle(value))

    coverage, error = _integrate(integrand, limit, points)
    error += mass_error + omitted_tail
    if not isfinite(coverage) or not -error <= coverage <= 1.0 + error:
        raise ArithmeticError("Integrated coverage is outside the probability range.")
    return min(1.0, max(0.0, coverage)), mass, error



