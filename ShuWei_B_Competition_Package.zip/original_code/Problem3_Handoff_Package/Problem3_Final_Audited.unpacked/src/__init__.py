"""Audited synthetic direction-measurement examples."""
