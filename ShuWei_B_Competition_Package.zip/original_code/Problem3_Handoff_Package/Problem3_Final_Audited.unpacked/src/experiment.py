"""Reproduce the original fixtures and the expanded synthetic audit."""

import argparse
import csv
from dataclasses import asdict
from math import sqrt
from pathlib import Path

import numpy as np
from scipy.stats import beta

from .model import Case, analytic, angle_errors, circular_summary, coverage_mask, derivatives, sample_errors, wrap_deg
from .reference import global_angle, numeric_coverage


SEED = 20261121
SAMPLES = 180_000
Z95 = 1.959963984540054
CASES = (
    *(Case(f"S{i}", 25, 0, scale, scale, 0.5, 0.4, 3) for i, scale in
      enumerate((0.4, 0.8, 1.2, 1.6), start=1)),
    Case("Zero", 12, 37, 0, 0, 0, 0, 0),
    Case("Tiny", 12, 37, 1e-10, 2e-10, 2e-10, 4e-10, 1e-9),
    Case("Angle_only", 18, -83, 0, 0, 3, 4, 5),
    Case("Oblique", 13, 37, 1.8, 0.4, 0.65, 0.25, 7),
    Case("Wide_position", 12, -151, 9, 9, 1.1, 0.7, 90),
    Case("Wrap_heavy", 17, 173, 0.4, 0.4, 128, 70, 25),
)


def wilson(k, n):
    p = k / n
    z2 = Z95**2
    bound = Z95*sqrt(p*(1-p)/n + z2/(4*n*n))
    center = p + z2/(2*n)
    den = 1 + z2/n
    return 0.0 if not k else (center-bound)/den, 1.0 if k == n else (center+bound)/den


def paired_difference(observed, reference):
    n = len(observed)
    wins = int(np.count_nonzero(observed & ~reference))
    losses = int(np.count_nonzero(reference & ~observed))
    difference = (wins - losses) / n
    se = sqrt(max(0.0, (wins + losses)/n - difference**2) / (n-1))

    def interval(k):
        # Two 97.5% Clopper-Pearson intervals give at least 95% joint coverage.
        lo = beta.ppf(0.0125, k, n-k+1) if k else 0.0
        hi = beta.ppf(0.9875, k+1, n-k) if k < n else 1.0
        return float(lo), float(hi)

    win_limits, loss_limits = interval(wins), interval(losses)
    return difference, se, win_limits[0]-loss_limits[1], win_limits[1]-loss_limits[0], wins, losses


def sd_interval(samples):
    sd = float(np.std(samples, ddof=1))
    if not sd:
        return sd, 0.0, 0.0
    normalized = (samples - np.mean(samples))/sd
    squared = normalized**2
    se = sd*float(np.std(squared, ddof=1))/(2*sqrt(len(samples)))
    return sd, max(0.0, sd-Z95*se), sd+Z95*se


def fd_error(case):
    jacobian, hessian = derivatives(case)
    h = 1e-4 * case.distance
    a, b = np.eye(2)*h

    def at(vector):
        return float(np.radians(global_angle(case, *vector)))

    origin = at([0, 0])
    j = np.array([(at(v)-at(-v))/(2*h) for v in (a, b)])
    xx, yy = ((at(v)-2*origin+at(-v))/h**2 for v in (a, b))
    xy = (at(a+b)-at(a-b)-at(-a+b)+at(-a-b))/(4*h*h)
    return float(np.max(np.abs(j-jacobian))), float(np.max(np.abs(np.array([[xx, xy], [xy, yy]])-hessian)))


def analyze_case(case, errors):
    formula = analytic(case)
    linear, quadratic, raw = angle_errors(case, *errors)
    nonlinear = wrap_deg(raw)
    n = len(nonlinear)
    linear_hit = coverage_mask(linear, case.tolerance_deg)
    nonlinear_hit = np.abs(nonlinear) <= case.tolerance_deg
    k = int(nonlinear_hit.sum())
    cov_lo, cov_hi = wilson(k, n)
    sd, sd_lo, sd_hi = sd_interval(nonlinear)
    circ_r, circ_mean, circ_sd = circular_summary(nonlinear)
    comparison = paired_difference(nonlinear_hit, linear_hit)
    sample = tuple(values[:4096] for values in errors)
    cross_check = float(np.max(np.abs(wrap_deg(raw[:4096] - global_angle(case, *sample)))))
    j_error, h_error = fd_error(case)
    reference, density_mass, quadrature_error = numeric_coverage(case)
    if density_mass is not None and abs(density_mass - 1) > 1e-8:
        raise AssertionError(f"Projected density is not normalized: {case.name}")
    if cross_check > 1e-10:
        raise AssertionError(f"Independent angle implementation disagrees: {case.name}")
    stds = (case.sx, case.sy, case.offset_sd_deg, case.control_sd_deg)
    active = [values for values, scale in zip(errors, stds, strict=True) if scale]
    if len(active) > 1:
        correlation = np.corrcoef(active)
        off_diagonal = float(np.max(np.abs(correlation - np.eye(len(active)))))
    else:
        off_diagonal = None
    row = {
        **asdict(case), "samples": n, **formula,
        "mc_linear_raw_sd_deg": float(np.std(linear, ddof=1)),
        "mc_linear_wrapped_sd_deg": float(np.std(wrap_deg(linear), ddof=1)),
        "mc_quadratic_raw_sd_deg": float(np.std(quadratic, ddof=1)),
        "mc_nonlinear_sd_deg": sd, "mc_sd_low95_deg": sd_lo, "mc_sd_high95_deg": sd_hi,
        "mc_nonlinear_mean_deg": float(nonlinear.mean()),
        "mc_circular_mean_deg": circ_mean, "mc_circular_sd_deg": circ_sd, "mc_resultant": circ_r,
        "mc_linear_raw_coverage": float(np.mean(np.abs(linear) <= case.tolerance_deg)),
        "mc_linear_wrapped_coverage": float(np.mean(linear_hit)),
        "mc_nonlinear_raw_coverage": float(np.mean(np.abs(raw) <= case.tolerance_deg)),
        "mc_nonlinear_coverage": k/n, "mc_coverage_low95": cov_lo, "mc_coverage_high95": cov_hi,
        "mc_vs_analytic_wrapped": k/n - formula["linear_wrapped_coverage"],
        "paired_delta": comparison[0], "paired_se": comparison[1],
        "paired_low95": comparison[2], "paired_high95": comparison[3],
        "paired_wins": comparison[4], "paired_losses": comparison[5],
        "wrapped_fraction": float(np.mean(raw != nonlinear)),
        "reference_coverage": reference, "reference_density_mass": density_mass,
        "reference_quad_error_estimate": quadrature_error,
        "reference_minus_linear": None if reference is None else reference - formula["linear_wrapped_coverage"],
        "reference_minus_mc": None if reference is None else reference - k/n,
        "reference_in_wilson95": None if reference is None else int(cov_lo <= reference <= cov_hi),
        "fd_jacobian_max_abs": j_error, "fd_hessian_max_abs": h_error,
        "global_crosscheck_max_deg": cross_check, "max_abs_noise_correlation": off_diagonal,
    }
    position = angle_errors(case, *errors[:2])[2]
    without = (errors[2]+errors[3], position+errors[3], position+errors[2])
    sensitivity = []
    total = formula["linear_sd_deg"]**2
    for source, ablated in zip(("position", "offset", "control"), without, strict=True):
        component = formula[f"{source}_var_deg2"]
        removed = wrap_deg(ablated)
        sensitivity.append({
            "case": case.name, "source": source, "linear_component_var_deg2": component,
            "linear_variance_share": component/total if total else None,
            "sd_if_source_removed_deg": float(np.std(removed, ddof=1)),
            "nonlinear_coverage_if_removed": float(np.mean(np.abs(removed) <= case.tolerance_deg)),
            "coverage_change_if_removed": float(np.mean(np.abs(removed) <= case.tolerance_deg)) - k/n,
        })
    return row, sensitivity


def write_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows(rows)


def figures(destination, rows, sensitivity):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    x = np.arange(len(rows))
    labels = [row["name"].replace("_", "\n") for row in rows]
    fig, axes = plt.subplots(2, 1, figsize=(10.2, 7.2), sharex=True, layout="constrained")
    ax = axes[0]
    measured = np.array([row["mc_nonlinear_coverage"] for row in rows])
    interval = np.array([[row["mc_coverage_low95"], row["mc_coverage_high95"]] for row in rows])
    ax.errorbar(x+0.13, measured, yerr=np.maximum(0, np.stack((measured-interval[:, 0], interval[:, 1]-measured))),
                fmt="o", color="#216c5d", label="Wrapped MC (Wilson 95%)", capsize=3)
    ax.scatter(x-0.13, [row["linear_wrapped_coverage"] for row in rows], marker="s",
               color="#9d4b32", label="First-order wrapped normal")
    ax.scatter(x, [row["reference_coverage"] if row["reference_coverage"] is not None else np.nan for row in rows],
               marker="x", color="#283756", label="Deterministic reference")
    ax.set(title="Synthetic angular-error validation", ylabel="Within tolerance (probability)", ylim=(-0.04, 1.05))
    ax.legend(frameon=False, fontsize=8)
    ax = axes[1]
    w = 0.36
    ax.bar(x-w/2, [row["linear_sd_deg"] for row in rows], width=w, label="First-order unwrapped",
           color="#b87b65")
    ax.bar(x+w/2, [row["mc_nonlinear_sd_deg"] for row in rows], width=w, label="Wrapped nonlinear MC",
           color="#669f94")
    ax.set(ylabel="Ordinary standard deviation (deg)", xlabel="Synthetic fixture")
    ax.set_yscale("symlog", linthresh=0.2)
    ax.legend(frameon=False, fontsize=8)
    ax.set_xticks(x, labels, fontsize=8)
    for ax in axes:
        ax.grid(axis="y", alpha=0.25)
        ax.set_axisbelow(True)
    fig.savefig(destination / "synthetic_coverage_and_sd.png", dpi=220)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10.2, 4.15), layout="constrained")
    base = np.zeros(len(rows))
    for source, color in (("position", "#345779"), ("offset", "#b26542"), ("control", "#42917b")):
        values = np.array([row["linear_variance_share"] or 0 for row in sensitivity if row["source"] == source])
        ax.bar(x, values, bottom=base, color=color, label=source.capitalize())
        base += values
    ax.set(title="Synthetic first-order variance decomposition", ylabel="Fraction of linear variance",
           xlabel="Synthetic fixture", ylim=(0, 1.03))
    ax.set_xticks(x, labels, fontsize=8)
    ax.legend(frameon=False, ncol=3, loc="upper center", bbox_to_anchor=(0.5, -0.22))
    ax.grid(axis="y", alpha=0.25)
    ax.set_axisbelow(True)
    fig.savefig(destination / "synthetic_variance_contributions.png", dpi=220)
    plt.close(fig)


def run(output_dir, *, size=SAMPLES, seed=SEED, cases=CASES, plots=True):
    if size < 2:
        raise ValueError("At least two samples are required.")
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.Generator(np.random.PCG64(seed))
    rows, sensitivity = [], []
    for stream, case in enumerate(cases, start=1):
        row, components = analyze_case(case, sample_errors(case, rng, size))
        rows.append({"case_index": stream, "seed": seed, **row})
        sensitivity.extend(components)
    write_csv(output / "Problem3_Numerical_Results.csv", rows)
    write_csv(output / "Problem3_Sensitivity.csv", sensitivity)
    if plots:
        destination = output / "figures"
        destination.mkdir(exist_ok=True)
        figures(destination, rows, sensitivity)
    return rows, sensitivity


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=Path("."))
    parser.add_argument("--samples", type=int, default=SAMPLES)
    parser.add_argument("--seed", type=int, default=SEED)
    args = parser.parse_args()
    rows, sensitivity = run(args.output_dir, size=args.samples, seed=args.seed)
    print(f"Computed {len(rows)} synthetic cases and {len(sensitivity)} source comparisons.")


if __name__ == "__main__":
    main()
