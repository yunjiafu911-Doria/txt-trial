"""Synthetic non-operational uncertainty propagation demonstration.
This does not solve any UAV navigation, positioning, or deployment parameter task.
"""
from __future__ import annotations
import argparse
import csv
import math
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parent
DEG=180.0/math.pi
# Independent synthetic demonstration values; NOT the original contest's parameters.
D=25.0
ZERO_STD_DEG=0.5
CONTROL_STD_DEG=0.4
TOLERANCE_DEG=3.0
COORD_STDS=(0.4,0.8,1.2,1.6)
N=180_000
SEED=20261121


def analytic_components(coord_std):
    position_var=(DEG*coord_std/D)**2
    zero_var=ZERO_STD_DEG**2
    control_var=CONTROL_STD_DEG**2
    total_std=math.sqrt(position_var+zero_var+control_var)
    coverage=math.erf(TOLERANCE_DEG/(math.sqrt(2)*total_std))
    total_var=total_std**2
    return total_std, coverage, (position_var/total_var,zero_var/total_var,control_var/total_var)


def main(output_dir=None):
    destination = Path(output_dir) if output_dir is not None else ROOT / 'historical_rerun'
    figures = destination / 'figures'
    figures.mkdir(parents=True, exist_ok=True)
    rng=np.random.default_rng(SEED)
    rows=[]
    contribution=[]
    for j, sigma in enumerate(COORD_STDS):
        dx=rng.normal(0,sigma,N)
        dy=rng.normal(0,sigma,N)
        e0=rng.normal(0,ZERO_STD_DEG,N)
        ec=rng.normal(0,CONTROL_STD_DEG,N)
        linear=-dy/D*DEG+e0+ec
        nonlinear=np.degrees(np.arctan2(-dy,D-dx))+e0+ec
        total_std,pred,parts=analytic_components(sigma)
        lin_cover=float(np.mean(np.abs(linear)<=TOLERANCE_DEG))
        nonlin_cover=float(np.mean(np.abs(nonlinear)<=TOLERANCE_DEG))
        # Conservative 95% binomial half-width using p=0.5
        half_width=1.96*0.5/math.sqrt(N)
        rows.append(dict(case=f'S{j+1}',sensor_range_units=D,coord_std_units=sigma,
                         zero_std_deg=ZERO_STD_DEG,control_std_deg=CONTROL_STD_DEG,
                         tolerance_deg=TOLERANCE_DEG,linear_pred_total_std_deg=total_std,
                         analytic_coverage=pred,mc_linear_coverage=lin_cover,
                         mc_nonlinear_coverage=nonlin_cover,
                         diff_mc_linear_minus_analytic=lin_cover-pred,
                         diff_mc_nonlinear_minus_analytic=nonlin_cover-pred,
                         conservative_mc_95ci_half_width=half_width,
                         samples=N,random_seed=SEED))
        contribution.append(dict(case=f'S{j+1}',coord_std_units=sigma,
                                 position_variance_share=parts[0],
                                 zero_variance_share=parts[1],
                                 control_variance_share=parts[2]))
    for filename,data in [('Problem3_Synthetic_Numerical_Results.csv',rows),('Problem3_Synthetic_Sensitivity.csv',contribution)]:
        with (destination/filename).open('w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=list(data[0].keys()))
            w.writeheader();w.writerows(data)
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        xs=[r['coord_std_units'] for r in rows]
        plt.figure(figsize=(6.7,4.2))
        plt.plot(xs,[r['analytic_coverage'] for r in rows],marker='o',label='Linear analytic')
        plt.plot(xs,[r['mc_nonlinear_coverage'] for r in rows],marker='x',linestyle='--',label='Exact-angle Monte Carlo')
        plt.xlabel('Position uncertainty standard deviation (synthetic units)')
        plt.ylabel('Probability within angular tolerance')
        plt.title('Generic sensor uncertainty: synthetic validation')
        plt.legend();plt.grid(alpha=0.25);plt.tight_layout()
        plt.savefig(figures/'synthetic_coverage.png',dpi=160)
        plt.close()
        plt.figure(figsize=(6.7,4.2))
        plt.stackplot(xs,[r['position_variance_share'] for r in contribution],
                      [r['zero_variance_share'] for r in contribution],
                      [r['control_variance_share'] for r in contribution],
                      labels=['Position','Offset','Control'])
        plt.xlabel('Position uncertainty standard deviation (synthetic units)')
        plt.ylabel('Share of linearized variance')
        plt.ylim(0,1);plt.legend(loc='upper left');plt.tight_layout()
        plt.savefig(figures/'synthetic_variance_contributions.png',dpi=160)
        plt.close()
    except ImportError:
        pass
    for r in rows:
        print(r['case'], 'analytic=',round(r['analytic_coverage'],6),
              'MClinear=',round(r['mc_linear_coverage'],6),
              'MCnonlinear=',round(r['mc_nonlinear_coverage'],6))
    print('max linear MC absolute coverage difference:',max(abs(r['diff_mc_linear_minus_analytic']) for r in rows))
    print('max nonlinear MC absolute coverage difference:',max(abs(r['diff_mc_nonlinear_minus_analytic']) for r in rows))

if __name__=='__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path)
    main(parser.parse_args().output_dir)

