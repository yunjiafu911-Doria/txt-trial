import hashlib
from pathlib import Path

from reproduce import main


def test_separate_destination_preserves_bundled_tables_and_plots(tmp_path):
    root = Path(__file__).resolve().parents[1]
    archived = tuple(root.glob("*.csv")) + tuple((root / "figures").glob("*.png"))
    assert len(archived) == 4
    before = {path: hashlib.sha256(path.read_bytes()).digest() for path in archived}

    destination = tmp_path / "separate" / "rerun"
    main(destination)
    assert len(list(destination.glob("*.csv"))) == 2
    assert len(list((destination / "figures").glob("*.png"))) == 2
    assert {path: hashlib.sha256(path.read_bytes()).digest() for path in archived} == before

