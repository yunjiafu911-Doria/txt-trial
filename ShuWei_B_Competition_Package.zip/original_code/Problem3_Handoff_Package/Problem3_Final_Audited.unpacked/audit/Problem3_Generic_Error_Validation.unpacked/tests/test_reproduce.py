import math
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from reproduce import analytic_components,COORD_STDS

def test_probabilities_in_01():
    for s in COORD_STDS:
        sd,p,parts=analytic_components(s)
        assert sd>0 and 0<p<1
        assert abs(sum(parts)-1)<1e-12

def test_more_noise_less_coverage():
    probs=[analytic_components(s)[1] for s in COORD_STDS]
    assert all(a>b for a,b in zip(probs,probs[1:]))

def test_variance_contributions():
    a=analytic_components(COORD_STDS[0])[2]
    b=analytic_components(COORD_STDS[-1])[2]
    assert b[0]>a[0]

def test_zero_position_noise_limit():
    sd,coverage,parts=analytic_components(0)
    assert math.isclose(sd,math.hypot(0.5,0.4))
    assert parts[0]==0
